"""SilverWood networking: REST client + background worker.
Two transports, same protocol: Firebase Realtime Database (online, works worldwide) or the host PC's
own server (server.py, LAN/VPN, unlimited size). The server speaks the same REST dialect.

No bpy in here: the worker thread never touches Blender data.
main -> worker : Worker.outbox (multi-path write dicts), Worker.presence
worker -> main : Worker.inbox  (tuples, first item is the message type)
"""
import json
import logging
import queue
import re
import threading
import time
import urllib.error
import urllib.parse
import urllib.request

log = logging.getLogger("SilverWood.net")

ALPHABET = "ABCDEFGHJKMNPQRSTUVWXYZ23456789"
COLORS = ["#FF8800", "#9B6BD6", "#4DB6AC", "#E5484D", "#F2C94C", "#5AA9E6", "#C678DD", "#7BC96F"]
SV = {".sv": "timestamp"}
CHUNK_BYTES = 1_000_000
STALE_MS = 20000
KINDS = {"create", "delete", "transform", "rename", "visibility", "parent", "mesh", "data", "props"}
ID_RE = re.compile(r"[0-9a-f]{32}")
UID_RE = re.compile(r"[0-9a-f]{12}")
KEY_RE = re.compile(r"[0-9]{13}-[0-9a-f]{4}[0-9]{5}")


class Incomplete(Exception):
    """Mesh chunks not all uploaded yet; retry next poll."""


class SessionError(Exception):
    """Permanent failure (bad session ID, closed session). Not retried."""


class RemoteError(Exception):
    def __init__(self, code, body):
        super().__init__(f"HTTP {code}: {body}")
        self.code, self.body = code, str(body)


class Client:
    def __init__(self, base, token="", uid="", cid=""):
        base = base.strip().rstrip("/")
        if not base.startswith(("http://", "https://")):
            raise ValueError("Address must start with http:// or https://")
        self.base, self.token, self.uid, self.cid = base, token, uid, cid

    def call(self, method, path, data=None, timeout=10, **query):
        if self.token:
            query["auth"] = self.token
        if self.uid:
            query["uid"] = self.uid
        if self.cid:
            query["cid"] = self.cid
        url = f"{self.base}/{path}.json" + ("?" + urllib.parse.urlencode(query) if query else "")
        body = None if data is None else json.dumps(data).encode()
        req = urllib.request.Request(url, body, {"Content-Type": "application/json"}, method=method)
        try:
            with urllib.request.urlopen(req, timeout=timeout) as r:
                return json.loads(r.read() or b"null")
        except urllib.error.HTTPError as e:
            raise RemoteError(e.code, e.read()[:200].decode("utf-8", "replace")) from None


def merge(out, path, val):
    """Add one (path, value) write to a multi-path PATCH dict without path conflicts.

    Firebase rejects a multi-path update holding both 'a/b' and 'a/b/c', so a later
    write is folded into an ancestor, or replaces descendants.
    """
    for p in [p for p in out if p.startswith(path + "/")]:
        del out[p]
    parts = path.split("/")
    for n in range(1, len(parts)):
        pre = "/".join(parts[:n])
        if isinstance(out.get(pre), dict):
            d = out[pre]
            for k in parts[n:-1]:
                d = d.setdefault(k, {})
            d[parts[-1]] = val
            return
    out[path] = val


class Worker(threading.Thread):
    def __init__(self, fb, mode, sid, uid, user, project, local=False, color=None):
        super().__init__(name="SilverWood-net", daemon=True)
        self.fb, self.mode, self.sid, self.uid, self.user, self.project = fb, mode, sid, uid, user, project
        self.local, self.inc_since, self.pref_color = local, 0.0, color
        self.inbox, self.outbox = queue.Queue(), queue.Queue()
        self.stop_ev = threading.Event()
        self.status, self.err, self.latency, self.fails = "connecting", "", 0, 0
        self.offset = 0.0
        self.pending = {}
        self.presence, self.presence_v, self.sent_v, self.last_pres = {}, 0, -1, 0.0
        self.color, self.host = COLORS[0], ""
        self.polled, self.seen, self.members = 0, {}, {}
        self.resync, self.created = False, False
        self.role = "edit"
        self.pfp_b64, self.pfp_ver, self.pfp_sent, self.pfp_seen = "", 0, 0, {}

    def now_ms(self):
        return int(time.time() * 1000 + self.offset)

    def p(self, sub=""):
        return f"sessions/{self.sid}" + (f"/{sub}" if sub else "")

    def mark_ok(self):
        self.status, self.fails, self.err = "connected", 0, ""

    def mark_fail(self, e):
        self.fails += 1
        code = getattr(e, "code", 0)
        denied = code in (401, 403)
        self.status = "error" if denied or self.fails >= 4 else "connecting"
        msg = ("Wrong code (host rejected it)" if self.local else "Permission denied: check Firebase rules / token") if denied else f"{type(e).__name__}: {e}"
        if msg != self.err:
            self.inbox.put(("error", msg))
        self.err = msg
        log.warning("network: %s", msg)
        return min(30.0, 0.5 * 2 ** self.fails)

    def setup(self):
        fb = self.fb
        if self.mode == "create" and not self.created:
            old = fb.call("GET", self.p("members")) if not self.local else None
            live = isinstance(old, dict) and any(isinstance(m, dict) and time.time() * 1000 - (m.get("last_seen") or 0) < 30000
                                                 for m in old.values())
            if not live:
                fb.call("PUT", self.p(), {"host": self.uid, "created": SV, "status": "active",
                                          "metadata": {"project_name": self.project, "version": 1}})
            self.created = True
        elif self.mode == "join":
            if not isinstance(fb.call("GET", self.p("metadata")), dict):
                raise SessionError("Session not found")
            if fb.call("GET", self.p("status")) != "active":
                raise SessionError("Session is not active")
        self.host = fb.call("GET", self.p("host")) or self.uid
        members = fb.call("GET", self.p("members"))
        used = {m.get("color") for m in members.values() if isinstance(m, dict)} if isinstance(members, dict) else set()
        self.color = self.pref_color or next((c for c in COLORS if c not in used), COLORS[sum(map(ord, self.uid)) % len(COLORS)])
        me = {"username": self.user, "status": "online", "color": self.color, "last_seen": SV, "activity": "Idle"}
        if self.local:
            if self.pfp_ver and self.pfp_b64:
                fb.call("PUT", self.p(f"pfps/{self.uid}"), self.pfp_b64, timeout=15)
                self.pfp_sent = self.pfp_ver
            me["pv"] = self.pfp_ver
        t1 = time.time()
        fb.call("PUT", self.p(f"members/{self.uid}"), me)
        t2 = time.time()
        srv = fb.call("GET", self.p(f"members/{self.uid}/last_seen"))
        self.offset = srv - (t1 + t2) / 2 * 1000
        self.polled = self.now_ms()
        self.inbox.put(("joined", self.host, self.color))
        self.snapshot()

    def snapshot(self):
        ts = self.now_ms()
        objs = self.fb.call("GET", self.p("objects"))
        objs = objs if isinstance(objs, dict) else {}
        for i, st in objs.items():
            if isinstance(st, dict) and ID_RE.fullmatch(i):
                st["mesh"] = self.fetch_mesh(i, st)
        self.inbox.put(("snapshot", ts, objs))

    def fetch_mesh(self, i, d):
        """Reassemble a mesh stored as meshes/<id>/<version>/<n> string chunks (version + count come from d)."""
        ver, n = d.get("mv"), d.get("mn")
        if not (isinstance(ver, str) and ver.isdigit() and isinstance(n, int) and 0 < n <= 2000):
            return None
        raw = self.fb.call("GET", self.p(f"meshes/{i}/{ver}"))
        parts = [raw.get(str(k)) for k in range(n)] if isinstance(raw, dict) else list(raw or [])[:n]
        if len(parts) < n or not all(isinstance(x, str) for x in parts):
            raise Incomplete(i)
        try:
            m = json.loads("".join(parts))
        except ValueError:
            raise Incomplete(i) from None
        return m if isinstance(m, dict) else None

    def do_flush(self):
        if self.role == "view":
            try:
                while True:
                    self.outbox.get_nowait()
            except queue.Empty:
                pass
            self.pending.clear()
            return
        try:
            while True:
                for path, val in self.outbox.get_nowait().items():
                    merge(self.pending, path, val)
        except queue.Empty:
            pass
        while self.pending:
            chunk, size = {}, 0
            for path, val in self.pending.items():
                n = len(json.dumps(val))
                if chunk and size + n > CHUNK_BYTES:
                    break
                chunk[path], size = val, size + n
            try:
                self.fb.call("PATCH", self.p(), chunk, timeout=30)
            except RemoteError as e:
                if e.code == 403 and "view-only" in e.body:
                    self.role = "view"
                    self.pending.clear()
                    return
                if e.code != 400:
                    raise
                self.inbox.put(("error", f"Dropped a rejected write ({size // 1024} KB): {e}"[:120]))
            for path in chunk:
                del self.pending[path]
            self.inbox.put(("sent", time.time()))

    def valid(self, ev):
        return (isinstance(ev, dict) and isinstance(ev.get("id"), str) and ID_RE.fullmatch(ev["id"])
                and ev.get("k") in KINDS and isinstance(ev.get("ts"), (int, float))
                and isinstance(ev.get("u"), str) and len(ev["u"]) <= 32)

    def do_events(self):
        if self.resync:
            self.do_flush()
            self.snapshot()
            self.resync = False
        t = self.now_ms()
        if t - self.polled > 240000:
            self.resync = True
        evs = self.fb.call("GET", self.p("events"), orderBy='"$key"',
                           startAt=json.dumps(f"{max(0, self.polled - 8000):013d}"))
        waiting = False
        for key in sorted(evs) if isinstance(evs, dict) else ():
            ev = evs[key]
            if key in self.seen or not KEY_RE.fullmatch(key) or not self.valid(ev) or ev["ts"] > t + 60000:
                continue
            if ev["u"] != self.uid:
                if ev["k"] in ("create", "mesh"):
                    try:
                        ev["mesh"] = self.fetch_mesh(ev["id"], ev)
                    except Incomplete:
                        self.inc_since = self.inc_since or time.time()
                        if time.time() - self.inc_since < 30:
                            waiting = True
                            break
                        ev["mesh"] = None
                self.inbox.put(("event", ev))
            self.seen[key] = ev["ts"]
        if not waiting:
            self.inc_since = 0.0
            self.polled = t
        self.seen = {k: v for k, v in self.seen.items() if v >= t - 30000}

    def do_members(self):
        if self.local and self.pfp_sent != self.pfp_ver:
            self.fb.call("PUT", self.p(f"pfps/{self.uid}"), self.pfp_b64 or None, timeout=15)
            self.pfp_sent = self.pfp_ver
            self.presence_v += 1
        v, data = self.presence_v, dict(self.presence)
        if v != self.sent_v or time.time() - self.last_pres > 4:
            data.update(username=self.user, color=self.color, status="online", last_seen=SV)
            if self.local:
                data["pv"] = self.pfp_ver
            self.fb.call("PATCH", self.p(f"members/{self.uid}"), data)
            self.sent_v, self.last_pres = v, time.time()
        t0 = time.time()
        m = self.fb.call("GET", self.p("members"))
        self.latency = int((time.time() - t0) * 1000)
        self.members = m if isinstance(m, dict) else {}
        if self.local:
            for uid, d in self.members.items():
                if uid == self.uid or not isinstance(d, dict) or not UID_RE.fullmatch(uid):
                    continue
                pv = d.get("pv") if isinstance(d.get("pv"), int) and not isinstance(d.get("pv"), bool) else 0
                if self.pfp_seen.get(uid) != pv:
                    b = self.fb.call("GET", self.p(f"pfps/{uid}"), timeout=15) if pv else None
                    self.pfp_seen[uid] = pv
                    self.inbox.put(("pfp", uid, b if isinstance(b, str) and len(b) <= 40000 else None))
        self.inbox.put(("members", self.members, self.now_ms()))

    def do_perms(self):
        """Host-PC modes: who may edit. The server refuses writes from view-only users anyway."""
        p = self.fb.call("GET", self.p("perms"))
        p = {k: v for k, v in p.items() if v in ("view", "edit")} if isinstance(p, dict) else {}
        r = "edit" if self.uid == self.host else (p.get(self.uid) or p.get("_default") or "edit")
        self.role = "view" if r == "view" else "edit"
        self.inbox.put(("perms", p))

    @staticmethod
    def banned_msg(e):
        if isinstance(e, RemoteError) and e.code == 403:
            if "kicked" in e.body:
                return "You were removed from the session by the host"
            if "locked" in e.body:
                return "The host locked the session: nobody new can join"

    def do_gc(self):
        """Host only: prune events older than 5 min and members silent for 60 s."""
        if self.host != self.uid:
            return
        old = self.fb.call("GET", self.p("events"), orderBy='"$key"',
                           endAt=json.dumps(f"{self.now_ms() - 300000:013d}~"))
        dead = {f"members/{u}": None for u, m in self.members.items() if u != self.uid and isinstance(m, dict)
                and self.now_ms() - (m.get("last_seen") or 0) > 60000}
        upd = {f"events/{k}": None for k in old} if isinstance(old, dict) else {}
        upd.update(dead)
        if upd:
            self.fb.call("PATCH", self.p(), upd)

    def fatal(self, msg):
        self.status = "error"
        self.inbox.put(("fatal", msg))

    def run(self):
        while not self.stop_ev.is_set():
            try:
                self.setup()
                break
            except SessionError as e:
                return self.fatal(str(e))
            except Exception as e:
                bm = self.banned_msg(e)
                if bm:
                    return self.fatal(bm)
                if self.mode == "join" and getattr(e, "code", 0) in (401, 403):
                    return self.fatal("Wrong code" if self.local else "Permission denied: check Firebase rules / token")
                delay = self.mark_fail(e)
                if self.mode == "join" and self.fails >= 3:
                    return self.fatal("Cannot reach host: check the code, firewall and port forwarding" if self.local
                                      else "Cannot reach the database: check internet and database URL")
                self.stop_ev.wait(delay)
        else:
            return
        self.mark_ok()
        fast = self.local
        tasks = [("do_flush", .03 if fast else .1), ("do_events", .06 if fast else .25),
                 ("do_members", .06 if fast else .25), ("do_gc", 60.0)] + ([("do_perms", 1.0)] if self.local else [])
        nxt = {n: time.time() + (60 if n == "do_gc" else 0) for n, _ in tasks}
        while not self.stop_ev.is_set():
            now = time.time()
            for name, period in tasks:
                if now < nxt[name]:
                    continue
                try:
                    getattr(self, name)()
                    self.mark_ok()
                    nxt[name] = now + period
                except Exception as e:
                    bm = self.banned_msg(e)
                    if bm:
                        return self.fatal(bm)
                    delay = self.mark_fail(e)
                    nxt = {n: now + delay for n in nxt}
                    break
            self.stop_ev.wait(0.02)
        self.cleanup()

    def cleanup(self):
        """Leave: flush, then remove own member; online: hand host over, last one out deletes the session.
        (Local host: its server just shuts down.)"""
        if self.local and self.mode == "create":
            return
        try:
            self.do_flush()
            m = self.fb.call("GET", self.p("members"), timeout=4)
            now = self.now_ms()
            others = [u for u, d in (m or {}).items() if u != self.uid and isinstance(d, dict)
                      and now - (d.get("last_seen") or 0) < STALE_MS]
            if self.local or others:
                self.fb.call("DELETE", self.p(f"members/{self.uid}"), timeout=4)
                if self.local:
                    self.fb.call("DELETE", self.p(f"pfps/{self.uid}"), timeout=4)
                if others and self.host == self.uid and not self.local:
                    self.fb.call("PUT", self.p("host"), others[0], timeout=4)
            else:
                self.fb.call("DELETE", self.p(), timeout=4)
        except Exception as e:
            log.warning("cleanup failed: %s", e)


if __name__ == "__main__":
    w = {}
    merge(w, "objects/a", {"x": 1})
    merge(w, "objects/a/m", [1])
    merge(w, "objects/b/m", [2])
    merge(w, "objects/b", None)
    merge(w, "events/k", {"id": 1})
    assert w == {"objects/a": {"x": 1, "m": [1]}, "objects/b": None, "events/k": {"id": 1}}, w
    print("net.merge ok")
