# SilverWood - Blender Co Op Addon

Real-time multi-user scene sync for Blender 4.4+ / 5.x. Online mode (Firebase, works worldwide) or local mode (host PC is the server). Pure Python stdlib.

## Install
Blender -> Edit -> Preferences -> Add-ons -> (v) -> **Install from Disk...** -> `SilverWood.zip`. Enable it, allow network access.
Preferences -> SilverWood: set **Username**; optionally **Host Port** (default 8765) and **Advertised IPv4** (see Connecting).
3D Viewport -> **N** -> **SilverWood** tab.

## Use
Three ways to host, one Join box (it detects which code you pasted):

| Button | Reaches | Storage | Needs |
|---|---|---|---|
| **Host Worldwide** (recommended) | anywhere on the internet | host PC RAM, unlimited | host installs `cloudflared` once (or has OpenSSH) |
| **Host via Firebase** | anywhere | Firebase (small scenes) | Firebase rules (below) |
| **Host on LAN / VPN** | same Wi-Fi or VPN | host PC RAM, unlimited | nothing |

1. Host presses a host button, waits for the code, **Copy Code**, sends it. (Worldwide shows "Starting tunnel..." for a few seconds.)
2. Everyone else installs the add-on, opens the **same .blend**, pastes the code, **Join Session**. Joiners need nothing else.
3. **New Code** (when not in a session) rotates the file's secret.

### Host Worldwide setup (host only, once): click **One-Click Setup**
It is in the welcome screen (opens on startup, also **About / Setup** in the panel) and in the Session panel. It installs `cloudflared` for you
(Windows: winget, macOS: brew; Windows may ask permission) and works immediately, no Blender restart. Details of what it does:
Your PC runs the server; a free public HTTPS tunnel points at it, so no router or VPN setup. The add-on starts the tunnel itself:
1. `cloudflared` found on PATH -> Cloudflare quick tunnel (no account). Windows: `winget install Cloudflare.cloudflared`, then **restart Blender**.
2. Otherwise `ssh` to localhost.run (OpenSSH is built into Windows 10+/macOS/Linux, no account).
The code is long (32+ characters): paste it, don't type it. Traffic is HTTPS and protected by the file secret.
Quick tunnels are free best-effort services: they can drop, and the address changes each time you host. Host closing Blender ends the session.

## Firebase mode setup (one time)
Uses your Firebase Realtime Database (URL in add-on preferences, prefilled). Rules must allow the session paths:
```json
{ "rules": { "sessions": { "$sid": { ".read": true, ".write": true } } } }
```
Anyone who knows the 8-char code can read/write that session (40-bit secret, not listable). For stricter access use Firebase Auth and paste a token in *Auth Token*.
Online sessions stay alive while anyone is in them; when the host leaves, host passes to someone else; last one out deletes the session.
Big meshes are stored as ~500 KB string chunks (`meshes/<id>/<version>/<n>`), so no single value hits Firebase size limits.

## Local mode connecting
Code holds host IPv4 + port + secret. Same Wi-Fi works as is (allow Blender through the firewall). Over the internet use a VPN
and put the VPN IPv4 in **Advertised IPv4**, or forward the TCP port and put your public IP there (plain HTTP).

## Data layout (kept in host RAM)
```
sessions/{CODE}/   (local mode uses CODE = main)
  host, created, status:"active", metadata/{project_name, version}
  members/{UID}/{username, status, color, last_seen, activity, sel:[ids], cur:[x,y,z]}
  objects/{OBJECT_UUID}/{type, name, m:[16], hide, par, mpi, mesh:{v,f}}    current state for late joiners
  meshes/{id}/{version}/{n}: mesh JSON string chunks
  events/{ms13}-{uid4}{seq5}/{id, k, ts, u, ...}                           ordered change log
```
The server speaks a small Firebase-REST dialect (`server.py`), so the sync protocol is the same one the cloud version used.

## How it works
- Change detection: depsgraph handler marks the scene dirty; a 0.1 s timer diffs against a cached snapshot, one event per changed property.
- One worker thread per client (events polled 0.5 s, presence 1 s, writes batched 0.15 s, <=4 MB per request).
  Blender data is only touched on the main thread; remote events are applied in a 25 ms/tick budget.
- **Conflicts: last-writer-wins** per object per property group, ordered by (server-adjusted ms, user id).
- Dedupe: event keys, 8 s overlap window, per-property stamps. Failed requests retry with backoff; >4 min offline triggers a full resync.
- Host prunes events older than 5 min and members silent for 60 s.

## Your color
Click your own swatch under **Online Members** to pick a color; everyone sees it (member list, selection boxes, cursor, camera gizmo). It is remembered for next time. Other people's swatches are read-only.

## Welcome screen
Opens on startup (toggle in preferences) and from **About / Setup**. Page 0: logo, **Welcome, <your name>** (with your picture if you set one), One-Click Setup, **Account**, Info, Close. Info pages: hosting, joining, what is shared, account and menu, tips, about. Use the buttons or Left/Right arrows; Esc closes.

## Account, picture and the viewport menu
**Account** (welcome screen) or the **cube icon at the bottom left of the 3D viewport** (click its arrow, then *Settings* / *Account*) opens the GPU settings menu. The sidebar has a **Settings Menu** button too.
- **Display name**: changes only your SilverWood name (the add-on preference *Username*). It never touches your PC / Windows name. Blank = PC login name. Applies live, also inside a running session.
- **Profile picture**: *Choose Picture* (png/jpg/bmp/tga/webp), centre-cropped to 64x64. Shown next to your name in other people's viewports.
  **Only when the host runs the session on their PC** (Host Worldwide or Host on LAN / VPN). Firebase sessions never carry or show pictures.
- **General**: camera opacity for all users, hide profile pictures, hide usernames, welcome screen on/off, reset per-user opacity. These are local view settings: they only change what *you* see.
- **Users**: per-user camera opacity (overrides the global slider for that person, remembered by username). On a hosting PC, the host also gets **Can edit / View only** and **Kick** per user.
- **Host** (hosting PC only): lock the session (nobody new joins), make everyone view-only by default, clear the kick list.

### Host tools: how they are enforced
Moderation lives in the host's own server (`server.py`), not in the other users' add-ons, so a joiner cannot skip it with the normal add-on.
- **View-only**: the server refuses every write from that user except their own presence/picture. Their client stops sending, and local edits are rolled back to the host's state about a second later.
- **Kick**: the user's next request is refused and they are disconnected with a message. Rejoining with a new session id from the same install is refused too (per-install id), until you press *Clear kick list* or end the session. A joiner on the host's own PC is never blocked by this. **New Code** locks out everyone with the old code.
- Identity is a per-join id plus a per-install id, and the session code is still a shared secret. This is for friends, not a defence against someone who modifies the add-on.
- Not available in Firebase mode: there is no server of yours there to enforce anything, so the Host tab says so.

## Smoothness
Remote cameras and remote object moves (location/rotation/scale) are eased at ~60 Hz with frame-rate-independent smoothing, and on your own server / tunnel the add-on polls every 0.2 s (Firebase mode stays at 0.5 s to save requests). Mesh edits still appear in one step when the editor leaves Edit Mode.

## Synced
Mesh + Empty objects: create, delete, duplicate (Shift-D gets a new UUID), rename, location/rotation/scale, `hide_viewport`,
parenting, mesh geometry (on leaving Edit Mode, up to 50k verts). Presence: remote selections, 3D cursors, name labels, colors, and each user's viewport camera (Blender-style camera with an arrow along their look direction, in their color).

## Known limitations
- **Tunnel hosting is untested against real cloudflared/localhost.run** (only against a fake tunnel tool); host, worker, auth, 25 MB payload and code encoding are tested (`test_net.py`).
  Expect small Blender-API fixes on first run; logs print as `[SilverWood]` in the console.
- Worldwide/LAN mode: session lives in host RAM; host leaving ends it. Online mode has host handover.
- No collections or curves. Objects land in the scene root.
- Weights and shape-key coordinates are resent whole (like meshes), only for meshes up to 50k verts (shape keys: ~450k floats total); bigger ones sync names/settings only.
- Rig and material sync is new and untested inside Blender: expect small API fixes (see the `[SilverWood]` console log).
- Eye-icon hide is per user; `hide_viewport` is synced. Whole mesh is resent on geometry edits. Alt-D linked data becomes independent remotely.
- Polling, ~0.5 s latency. Single scene. Loading another .blend leaves the session.
- Anyone with the code has full access to the session unless the host restricts them; rotate with New Code.
- Pictures are square tiles (no round mask) and only sent to a hosting PC. Per-user opacity is remembered by username.
- The viewport menu is drawn with GPU/blf and needs the 3D viewport: it is not available in other editors.
- Panel colors follow your Blender theme (UI API can't restyle panels); user colors appear in swatches and viewport overlays.

## Test it
1. `python3 test_net.py`
2. Two Blender instances (same PC works: host code uses your LAN IP). A: Host Session, copy code. B: paste, Join.
3. Move/rename/delete/duplicate in A, watch B. Select in A, see boxes in B. Edit a mesh in A, leave Edit Mode, see it in B.

## Live cursors
Other members' mouse cursors show anywhere in the Blender UI (name tag, plus profile picture on LAN/worldwide sessions, ring while the mouse button is held). When someone switches workspace, their cursor fades with "<name> is switching to the <workspace> workspace". Open the same workspace to watch them live.
Cursor options (on/off, switch messages, opacity, size) are in the SilverWood menu under the Cursors tab.
Custom cursor: choose a transparent image under Account (top-left corner = pointer tip); toggles for pictures, names and custom cursors are in the Cursors tab.

## What is synced
Objects (mesh, empty, light, camera, text, armature): name, transform, visibility, parent, object settings, light/camera/text/armature data, modifiers, bones and pose, animation keyframes, reference-image empties (by image name, the image must exist in both files). Scene: render, Eevee/Cycles, color management, units, frame range, active camera, world color. Rigging and skinning: vertex groups and weights, shape keys (settings, values, coordinates), object and bone constraints, bone and pose-bone settings (B-Bone, inherit, IK limits, custom shapes), bone collections, object drivers.
Materials: slots and the material itself (viewport settings and the full shader node tree: nodes, values, links, colour ramps; images by name, the image must exist in both files).
Joining a session never overwrites the host: your scene settings are only sent once you change them after joining.
Not synced: group nodes, shape-key and armature-data animation, the current frame.

## Keys & Clicks display (for classes)
SilverWood panel -> **Keys & Clicks** (or Preferences). Both switches are **off** by default.
- **Show Keys & Clicks Display**: draws a small mouse (buttons and scroll wheel light up) plus the key text, e.g. `Ctrl + J`, in a corner of every 3D viewport. Others' inputs appear with their name.
- **Share My Keys & Clicks**: everyone in the session sees what you press. Everything you press in Blender is shown, so switch it off when you are not presenting.
- All of this is also in the in-viewport **Settings menu -> Keys** tab (toggles for showing other people's mouse and keys, corner buttons, size/opacity/time/position sliders).
- Move it with **Corner** + **X/Y**; also **Size**, **Opacity** and **Key Text Time**. Works without a session too (just shows your own).

## Leaving a session
**Leave Session** asks for confirmation. If you only joined, pressing *Yes, Leave* disconnects and then clears the scene (all objects, collections and unused data) so you don't keep other people's models. Hosts keep their scene.

## Updates (0.4.0+)
On startup SilverWood checks for a newer version (Preferences -> SilverWood -> *Check for Updates on Startup*). If one exists you get a toast in the viewport, a status-bar message, a banner in the panel, and the welcome screen shows `0.4.0 -> new version` with a **Download Update** button. Download progress shows in all of those, then **Install Update** installs it (restart Blender afterwards).
Update source: built in, the SilverWood releases `index.json` on GitHub Pages (*Update URL* in preferences is prefilled; blank also uses it). You can point it at another extension-repo `index.json`.
