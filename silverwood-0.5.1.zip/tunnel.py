"""One-click worldwide reachability for 'Host on This PC': open a public HTTPS tunnel to the local server.

Tries, in order: `cloudflared` (Cloudflare quick tunnel, if installed) then `ssh` to localhost.run (OpenSSH ships with Windows 10+/macOS/Linux).
Neither needs an account. Only the HOST needs this; joiners just paste the code.
"""
import os
import re
import shutil
import subprocess
import sys
import threading
import time
import types

CF_RE = re.compile(r"https://[a-z0-9-]+\.trycloudflare\.com")
LHR_RE = re.compile(r"https://[a-z0-9]+\.lhr\.life")


NO_WINDOW = subprocess.CREATE_NO_WINDOW if sys.platform == "win32" else 0
SETUP = types.SimpleNamespace(state="idle", msg="")


def find_cloudflared():
    """PATH first, then the spots winget/brew install to (so no Blender restart is needed after setup)."""
    p = shutil.which("cloudflared")
    if p:
        return p
    for c in (r"%ProgramFiles(x86)%\cloudflared\cloudflared.exe", r"%ProgramFiles%\cloudflared\cloudflared.exe",
              r"%LOCALAPPDATA%\Microsoft\WinGet\Links\cloudflared.exe",
              "/opt/homebrew/bin/cloudflared", "/usr/local/bin/cloudflared"):
        c = os.path.expandvars(c)
        if os.path.isfile(c):
            return c
    return ""


_cache = [0.0, None]


def tool_status():
    """(text, ready) for the UI. Cached 2 s: the panel/splash call this every redraw."""
    if time.time() - _cache[0] > 2:
        if find_cloudflared():
            r = ("Tunnel tool: cloudflared ready", True)
        elif shutil.which("ssh"):
            r = ("Tunnel tool: OpenSSH fallback ready", True)
        else:
            r = ("Tunnel tool: none found (run One-Click Setup)", False)
        _cache[:] = [time.time(), r]
    return _cache[1]


def setup():
    """One-click: make sure a tunnel tool exists. Runs in a background thread; progress in SETUP."""
    if SETUP.state == "running":
        return
    SETUP.state, SETUP.msg = "running", "Checking..."
    _cache[0] = 0.0
    threading.Thread(target=_setup, daemon=True, name="SilverWood-setup").start()


def _setup():
    def end(state, msg):
        SETUP.state, SETUP.msg = state, msg
        _cache[0] = 0.0
    try:
        if find_cloudflared():
            return end("done", "cloudflared is ready")
        cmd = None
        if sys.platform == "win32" and shutil.which("winget"):
            cmd = ["winget", "install", "--id", "Cloudflare.cloudflared", "-e", "--silent",
                   "--accept-source-agreements", "--accept-package-agreements"]
        elif sys.platform == "darwin" and shutil.which("brew"):
            cmd = ["brew", "install", "cloudflared"]
        if cmd:
            SETUP.msg = "Installing cloudflared (Windows may ask permission)..."
            subprocess.run(cmd, capture_output=True, text=True, timeout=900, stdin=subprocess.DEVNULL,
                           creationflags=NO_WINDOW)
            if find_cloudflared():
                return end("done", "cloudflared installed. Ready to host")
        if shutil.which("ssh"):
            return end("done", "Using OpenSSH fallback (already installed). Ready to host")
        end("error", "No tunnel tool. Get cloudflared: github.com/cloudflare/cloudflared/releases")
    except Exception as e:
        end("error", f"Setup failed: {e}"[:110])


def candidates(port):
    out = []
    cf = find_cloudflared()
    if cf:
        out.append(([cf, "tunnel", "--url", f"http://127.0.0.1:{port}", "--no-autoupdate"], CF_RE))
    ssh = shutil.which("ssh")
    if ssh:
        out.append(([ssh, "-T", "-o", "StrictHostKeyChecking=accept-new", "-o", "ServerAliveInterval=30",
                     "-o", "ExitOnForwardFailure=yes", "-R", f"80:127.0.0.1:{port}", "nokey@localhost.run"], LHR_RE))
    return out


def start(port, cmds=None):
    """Returns state with .url (set when the tunnel is up), .err (set if every method failed), .proc."""
    st = types.SimpleNamespace(proc=None, url="", err="", stop=False)

    def run():
        for cmd, rx in (cmds if cmds is not None else candidates(port)):
            if st.stop:
                return
            flags = NO_WINDOW
            try:
                st.proc = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True,
                                           stdin=subprocess.DEVNULL, creationflags=flags)
            except OSError:
                continue
            for line in st.proc.stdout:
                m = rx.search(line)
                if m and not st.url:
                    st.url = m.group(0)
            if st.url or st.stop:
                return
        st.err = ("No tunnel tool found. Install cloudflared (winget install Cloudflare.cloudflared) "
                  "or OpenSSH, then restart Blender.")

    threading.Thread(target=run, daemon=True, name="SilverWood-tunnel").start()
    return st


def stop(st):
    st.stop = True
    if st.proc and st.proc.poll() is None:
        st.proc.terminate()
