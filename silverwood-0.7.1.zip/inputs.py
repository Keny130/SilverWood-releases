"""SilverWood keys & clicks display: a small mouse + key text on screen, shared with the session (great for classes).

Capture:  ui.SW_OT_track feeds every window event to feed().
Share:    presence field "inp" = [seq, button_mask, key_text]  (see wire / on_remote).
Draw:     draw() runs as a viewport POST_PIXEL handler.
Both toggles are OFF by default (Preferences / SilverWood panel -> Keys & Clicks).
"""
import math
import sys
import time
import types

import blf
import bpy
import gpu
from gpu_extras.batch import batch_for_shader

L, M, R, WU, WD = 1, 2, 4, 8, 16
HOLD = 0.3
_BTN = {'LEFTMOUSE': L, 'MIDDLEMOUSE': M, 'RIGHTMOUSE': R}
_BTN_NAME = {L: "LMB", M: "MMB", R: "RMB"}
_MODS = {'LEFT_CTRL', 'RIGHT_CTRL', 'LEFT_SHIFT', 'RIGHT_SHIFT', 'LEFT_ALT', 'RIGHT_ALT', 'OSKEY'}
_SKIP = ('TIMER', 'NDOF', 'MOUSEMOVE', 'INBETWEEN', 'WINDOW', 'ACTIONZONE', 'TEXTINPUT', 'EVT_', 'TRACKPAD',
         'MOUSEROTATE', 'MOUSESMART', 'WHEELIN', 'WHEELOUT', 'NONE', 'PEN', 'ERASER', 'XR_', 'MOUSE_')
_NAMES = {
    "ZERO": "0", "ONE": "1", "TWO": "2", "THREE": "3", "FOUR": "4", "FIVE": "5", "SIX": "6", "SEVEN": "7",
    "EIGHT": "8", "NINE": "9", "RET": "Enter", "NUMPAD_ENTER": "Num Enter", "SPACE": "Space",
    "BACK_SPACE": "Backspace", "DEL": "Del", "ESC": "Esc", "TAB": "Tab", "PERIOD": ".", "COMMA": ",",
    "MINUS": "-", "EQUAL": "=", "SLASH": "/", "BACK_SLASH": "\\", "SEMI_COLON": ";", "QUOTE": "'",
    "ACCENT_GRAVE": "`", "LEFT_BRACKET": "[", "RIGHT_BRACKET": "]", "PLUS": "+", "ASTERIX": "*",
    "LEFT_ARROW": "Left", "RIGHT_ARROW": "Right", "UP_ARROW": "Up", "DOWN_ARROW": "Down",
    "PAGE_UP": "PgUp", "PAGE_DOWN": "PgDn", "HOME": "Home", "END": "End", "INSERT": "Ins",
    "CAPS_LOCK": "Caps", "LINE_FEED": "Enter",
}

ME = types.SimpleNamespace(down=0, hold={}, seq=0, text="", text_t=0.0)
REMOTE = {}  # uid -> SimpleNamespace(name, col, seq, mask, text, text_t, last)


def _prefs():
    return bpy.context.preferences.addons[__package__].preferences


def _redraw():
    for w in bpy.context.window_manager.windows:
        for a in w.screen.areas:
            if a.type == "VIEW_3D":
                a.tag_redraw()


def key_name(t):
    if t in _NAMES:
        return _NAMES[t]
    if t.startswith("NUMPAD_"):
        s = t[7:]
        return "Num " + _NAMES.get(s, s)
    if len(t) <= 1 or (t[0] == "F" and t[1:].isdigit()):  # empty type happens for some text/IME events
        return t
    return t.replace("_", " ").title()


def _mods(ev):
    out = []
    if ev.ctrl:
        out.append("Ctrl")
    if ev.shift:
        out.append("Shift")
    if ev.alt:
        out.append("Alt")
    if ev.oskey:
        out.append("Cmd" if sys.platform == "darwin" else "Win")
    return out


def mask(now):
    m = ME.down
    for b, t in ME.hold.items():
        if now < t:
            m |= b
    return m


def _key(txt, now):
    ME.text, ME.text_t = txt[:40], now
    ME.seq += 1


def feed(ev):
    """Called for every window event (from the SilverWood track modal)."""
    t, v = ev.type, ev.value
    if t.startswith(_SKIP):
        return
    try:
        p = _prefs()
        if not (p.input_show or p.input_share):
            return
    except Exception:
        return
    now = time.time()
    if t in _BTN:
        b = _BTN[t]
        if v == 'PRESS':
            ME.down |= b
            ME.hold[b] = now + HOLD
            ME.seq += 1
            mt = _mods(ev)
            if mt:
                _key(" + ".join(mt + [_BTN_NAME[b]]), now)
        elif v == 'RELEASE':
            ME.down &= ~b
        else:
            return
    elif t in ('WHEELUPMOUSE', 'WHEELDOWNMOUSE'):
        ME.hold[WU if t == 'WHEELUPMOUSE' else WD] = now + 0.25
        ME.seq += 1
        mt = _mods(ev)
        if mt:
            _key(" + ".join(mt + ["Wheel"]), now)
    elif v == 'PRESS' and not ev.is_repeat and t:
        parts = _mods(ev)
        if t not in _MODS or not parts:
            parts.append(key_name(t))
        _key(" + ".join(parts), now)
    else:
        return
    _redraw()


def wire(key_time):
    """What this user sends to everyone: [seq, button mask, key text]."""
    now = time.time()
    return [ME.seq, mask(now), ME.text if now - ME.text_t < key_time else ""]


def on_remote(uid, name, col, inp, now):
    ok = (isinstance(inp, list) and len(inp) == 3 and isinstance(inp[0], int) and isinstance(inp[1], int)
          and isinstance(inp[2], str) and not isinstance(inp[0], bool) and not isinstance(inp[1], bool))
    if not ok or (inp[0] == 0 and inp[1] == 0 and not inp[2]):
        REMOTE.pop(uid, None)
        return
    r = REMOTE.get(uid)
    if r is None:
        r = REMOTE[uid] = types.SimpleNamespace(name=name, col=col, seq=-1, mask=0, text="", text_t=0.0, last=0.0)
    r.name, r.col = name[:32], col
    seq, m, text = inp[0], inp[1] & 31, inp[2][:40]
    if seq != r.seq and r.seq != -1:
        r.last = now
        if text:
            r.text, r.text_t = text, now
    r.seq, r.mask = seq, m
    if m:
        r.last = now


def prune(keep):
    for u in [u for u in REMOTE if u not in keep]:
        del REMOTE[u]


def clear():
    REMOTE.clear()


# ---------------------------------------------------------------- drawing

def _fill(pts, col):
    if len(pts) < 3:
        return
    sh = gpu.shader.from_builtin('UNIFORM_COLOR')
    sh.bind()
    sh.uniform_float("color", col)
    batch_for_shader(sh, 'TRI_FAN', {"pos": pts}).draw(sh)


def _line(pts, col, width):
    try:
        sh = gpu.shader.from_builtin('POLYLINE_UNIFORM_COLOR')
        sh.bind()
        sh.uniform_float("viewportSize", gpu.state.viewport_get()[2:])
        sh.uniform_float("lineWidth", width)
    except Exception:
        sh = gpu.shader.from_builtin('UNIFORM_COLOR')
        sh.bind()
        gpu.state.line_width_set(width)
    sh.uniform_float("color", col)
    batch_for_shader(sh, 'LINE_STRIP', {"pos": pts}).draw(sh)


def _arc(cx, cy, r, a0, a1, n=8):
    return [(cx + r * math.cos(math.radians(a0 + (a1 - a0) * i / n)),
             cy + r * math.sin(math.radians(a0 + (a1 - a0) * i / n))) for i in range(n + 1)]


def _rr(x, y, w, h, rt, rb, n=8):
    """Rounded rectangle, counter-clockwise; rt/rb = top/bottom corner radius."""
    return (_arc(x + rb, y + rb, rb, 180, 270, n) + _arc(x + w - rb, y + rb, rb, 270, 360, n)
            + _arc(x + w - rt, y + h - rt, rt, 0, 90, n) + _arc(x + rt, y + h - rt, rt, 90, 180, n))


def _clip(poly, axis, val, keep_ge):
    out, n = [], len(poly)
    for i in range(n):
        a, b = poly[i], poly[(i + 1) % n]
        ia = a[axis] >= val if keep_ge else a[axis] <= val
        ib = b[axis] >= val if keep_ge else b[axis] <= val
        if ia:
            out.append(a)
        if ia != ib and b[axis] != a[axis]:
            t = (val - a[axis]) / (b[axis] - a[axis])
            out.append((a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t))
    return out


ACCENT = (1.0, 0.53, 0.0)


def _mouse(x, y, w, h, m, col, a, sc):
    """Egg-shaped mouse with a cable, a capsule scroll wheel and split buttons. (x, y) = bottom-left."""
    rt = w * 0.5
    body = _rr(x, y, w, h, rt, w * 0.34)
    cx, ys = x + w / 2, y + h * 0.52
    top = _clip(body, 1, ys, True)
    ww, gap = w * 0.17, w * 0.035
    lx, rx = cx - ww / 2 - gap, cx + ww / 2 + gap
    _fill(body, (0.05, 0.05, 0.07, 0.62 * a))
    if m & L:
        _fill(_clip(top, 0, lx, False), (*col, 0.92 * a))
    if m & R:
        _fill(_clip(top, 0, rx, True), (*col, 0.92 * a))
    wy0, wy1 = ys + h * 0.09, ys + h * 0.40
    wheel = _rr(cx - ww / 2, wy0, ww, wy1 - wy0, ww / 2, ww / 2, 5)
    if m & M:
        _fill(wheel, (*col, 0.92 * a))
    if m & WU:
        _fill(_clip(wheel, 1, (wy0 + wy1) / 2, True), (*col, 0.92 * a))
    if m & WD:
        _fill(_clip(wheel, 1, (wy0 + wy1) / 2, False), (*col, 0.92 * a))
    lc = (*ACCENT, a)
    _line(body + [body[0]], lc, 2.2 * sc)
    _line([(x, ys), (x + w, ys)], lc, 1.6 * sc)
    for px in (lx, rx):
        _line([(px, ys), (px, y + h - rt + math.sqrt(max(0.0, rt * rt - (px - cx) ** 2)))], lc, 1.6 * sc)
    _line(wheel + [wheel[0]], lc, 1.6 * sc)
    c = h * 0.2
    _line([(cx, y + h), (cx, y + h + c * 0.4), (cx + c * 0.3, y + h + c * 0.75), (cx + c * 0.3, y + h + c)], lc, 2.0 * sc)


def _items(p, own_name, own_col, now):
    kt = p.input_key_time
    out = []
    if p.input_own:
        t = ME.text if now - ME.text_t < kt else ""
        m = mask(now)
        out.append(("", own_col, m, t, 1.0 if (m or t) else 0.55))
    if p.input_others:
        for r in REMOTE.values():
            if r.mask or now - r.last < 4.0:
                out.append((r.name, r.col, r.mask, r.text if now - r.text_t < kt else "", 1.0))
    return out


def draw(own_name, own_col):
    r = bpy.context.region
    if r is None:
        return
    try:
        p = _prefs()
    except Exception:
        return
    if not p.input_show:
        return
    now = time.time()
    items = _items(p, own_name, own_col, now)
    if not items:
        return
    s = p.input_scale
    W, H = 56 * s, 80 * s
    cable, lab, gap = H * 0.2, (16 * s), 12 * s
    item_h = H + cable + lab
    right, bottom = p.input_corner in ('BR', 'TR'), p.input_corner in ('BL', 'BR')
    gpu.state.blend_set('ALPHA')
    for i, (name, col, m, text, idle) in enumerate(items):
        a = p.input_opacity * idle
        y = p.input_y + i * (item_h + gap) if bottom else r.height - p.input_y - item_h - i * (item_h + gap)
        blf.size(0, 20 * s)
        tw = blf.dimensions(0, text)[0] if text else 0
        pw = tw + 26 * s if text else 0
        mx = r.width - p.input_x - W if right else p.input_x
        _mouse(mx, y + lab, W, H, m, col, a, s)
        if name:
            blf.size(0, 12 * s)
            blf.color(0, 0.9, 0.9, 0.95, a)
            blf.position(0, mx + (W - blf.dimensions(0, name)[0]) / 2, y + 3 * s, 0)
            blf.draw(0, name)
        if text:
            ph = 34 * s
            px = mx - 10 * s - pw if right else mx + W + 10 * s
            py = y + lab + H * 0.5 - ph / 2
            pill = _rr(px, py, pw, ph, ph / 2, ph / 2, 6)
            _fill(pill, (0.05, 0.05, 0.07, 0.85 * a))
            _line(pill + [pill[0]], (*ACCENT, a), 2.0 * s)
            blf.size(0, 20 * s)
            blf.color(0, 1, 1, 1, a)
            blf.position(0, px + 13 * s, py + (ph - 14 * s) / 2, 0)
            blf.draw(0, text)
    gpu.state.blend_set('NONE')


def _tick():
    try:
        p = _prefs()
        if p.input_show:
            now = time.time()
            live = (mask(now) or now - ME.text_t < p.input_key_time + 0.2
                    or any(rr.mask or now - rr.last < 4.2 for rr in REMOTE.values()))
            if live:
                _redraw()
            return 0.08 if live else 0.4
    except Exception:
        pass
    return 0.5


def register():
    bpy.app.timers.register(_tick, first_interval=1.0, persistent=True)


def unregister():
    if bpy.app.timers.is_registered(_tick):
        bpy.app.timers.unregister(_tick)
    REMOTE.clear()
