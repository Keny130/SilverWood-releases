"""SilverWood asset sync: image textures and fonts travel as their original file bytes (PNG, JPG, EXR, TTF...).

Sender: scan() finds new or changed images/fonts and returns upload records. Receiver: apply() writes the bytes to a
cache file, loads them into the *same* datablock (so material nodes already pointing at it keep working) and packs it.
Pure helpers at the top (no bpy) are used by the network thread.
"""
import base64
import hashlib
import os
import re
import struct
import tempfile
import time
import zlib

import bpy
import numpy as np

PART = 600_000          # bytes per base64 chunk (before encoding)
MAX_BYTES = 200 * 1024 * 1024
MAX_CHUNKS = 400
SIGS = ((b"\x89PNG", "png"), (b"\xff\xd8\xff", "jpg"), (b"v/1\x01", "exr"), (b"#?RADIANCE", "hdr"), (b"#?RGBE", "hdr"),
        (b"II*\x00", "tif"), (b"MM\x00*", "tif"), (b"BM", "bmp"), (b"DDS ", "dds"), (b"GIF8", "gif"),
        (b"\x00\x01\x00\x00", "ttf"), (b"OTTO", "otf"), (b"true", "ttf"), (b"wOFF", "woff"))
EXTS = {"png", "jpg", "exr", "hdr", "tif", "bmp", "dds", "gif", "tga", "webp", "ttf", "otf", "woff", "ttc"}
SKIP_IMAGES = {"Render Result", "Viewer Node"}


def aid(kind, name):
    return hashlib.md5(f"{kind}:{name}".encode()).hexdigest()


def sniff(b, hint=""):
    for sig, ext in SIGS:
        if b.startswith(sig):
            return ext
    if b[:4] == b"RIFF" and b[8:12] == b"WEBP":
        return "webp"
    h = os.path.splitext(hint)[1].lower().lstrip(".")
    return h if h in EXTS else "png"


def cache_dir():
    d = os.path.join(tempfile.gettempdir(), "silverwood_cache")
    os.makedirs(d, exist_ok=True)
    return d


def chunks(b):
    return [base64.b64encode(b[k:k + PART]).decode("ascii") for k in range(0, len(b), PART)]


def join(parts, sha):
    """base64 chunks -> bytes, or None when the data does not match its checksum."""
    try:
        b = b"".join(base64.b64decode(p) for p in parts)
    except Exception:
        return None
    return b if hashlib.sha1(b).hexdigest() == sha else None


# ---------------------------------------------------------------- sender
def _read(path):
    p = bpy.path.abspath(path)
    if p and os.path.isfile(p) and os.path.getsize(p) <= MAX_BYTES:
        with open(p, "rb") as f:
            return f.read()
    return None


def _image_bytes(im):
    if im.packed_file is not None:
        return bytes(im.packed_file.data)
    if im.source == "FILE" and not im.is_dirty:
        b = _read(im.filepath)
        if b is not None:
            return b
    w, h = im.size
    if w == 0 or h == 0:
        return None
    # generated / painted / missing file: encode the pixel buffer ourselves (Image.copy() would lose generated pixels)
    px = np.empty(w * h * 4, "f4")
    im.pixels.foreach_get(px)
    if im.is_float:  # ponytail: float images made in Blender are stored as 16-bit PNG, so HDR range is clipped to 0-1
        a16 = (np.clip(px, 0, 1) * 65535 + .5).astype(">u2").reshape(h, w * 4)[::-1]
        return _png(w, h, 16, a16.view("u1").reshape(h, w * 8))
    a8 = (np.clip(px, 0, 1) * 255 + .5).astype("u1").reshape(h, w * 4)[::-1]
    return _png(w, h, 8, a8)


def _png(w, h, depth, rows):
    """Minimal RGBA PNG writer; rows is (h, bytes per row) already bottom-up flipped."""
    raw = np.concatenate([np.zeros((h, 1), "u1"), rows], 1).tobytes()

    def chunk(t, d):
        return struct.pack(">I", len(d)) + t + d + struct.pack(">I", zlib.crc32(t + d))
    return (b"\x89PNG\r\n\x1a\n" + chunk(b"IHDR", struct.pack(">IIBBBBB", w, h, depth, 6, 0, 0, 0))
            + chunk(b"IDAT", zlib.compress(raw, 6)) + chunk(b"IEND", b""))


def _font_bytes(vf):
    if vf.packed_file is not None:
        return bytes(vf.packed_file.data)
    return _read(vf.filepath) if vf.filepath and not vf.filepath.startswith("<") else None


def painting():
    """The image being texture-painted right now, or None."""
    try:
        c = bpy.context
        ob = c.object
        if ob is None or ob.mode != "TEXTURE_PAINT":
            return None
        ip = c.tool_settings.image_paint
        if ip.mode == "IMAGE":
            return ip.canvas
        m = ob.active_material
        return m.texture_paint_images[m.paint_active_slot]
    except Exception:
        return None


def scan(S):
    """Find images/fonts that changed since the last pass. Returns [(kind, name, bytes, meta)] to upload."""
    out = []
    paint = painting()
    for im in bpy.data.images:
        n = im.name
        if im.type not in ("IMAGE", "MULTILAYER", "UV_TEST") or n in SKIP_IMAGES or n.startswith(".sw_") or im.get("sw_ph") or (im.users == 0 and not im.use_fake_user):
            continue
        fp = (im.source, im.filepath, tuple(im.size), len(im.packed_file.data) if im.packed_file else -1, im.is_dirty,
              im.colorspace_settings.name, im.alpha_mode,
              # ponytail: while painting, resend the canvas every 3 s (10 s if big); the finished state goes out when you leave paint mode
              int(time.time() // (3 if im.size[0] * im.size[1] <= 4_000_000 else 10)) if im is paint else 0)
        if S.asset_fp.get(("i", n)) == fp:
            continue
        S.asset_fp[("i", n)] = fp
        if im.source not in ("FILE", "GENERATED"):
            continue  # sequences, movies, tiles: not synced
        try:
            b = _image_bytes(im)
        except (RuntimeError, OSError):
            b = None
        if b is None or len(b) > MAX_BYTES:
            continue
        meta = {"cs": im.colorspace_settings.name, "am": im.alpha_mode}
        out.append(("i", n, b, meta, sniff(b, im.filepath)))
    for vf in bpy.data.fonts:
        n = vf.name
        if vf.filepath.startswith("<") or vf.get("sw_ph") or (vf.users == 0 and not vf.use_fake_user):
            continue
        fp = (vf.filepath, len(vf.packed_file.data) if vf.packed_file else -1)
        if S.asset_fp.get(("f", n)) == fp:
            continue
        S.asset_fp[("f", n)] = fp
        try:
            b = _font_bytes(vf)
        except OSError:
            b = None
        if b is not None and len(b) <= MAX_BYTES:
            out.append(("f", n, b, {}, sniff(b, vf.filepath)))
    return out


# ---------------------------------------------------------------- receiver
def placeholder(name):
    """Stand-in for an image that has not arrived yet; gets filled in place when the real data comes."""
    im = bpy.data.images.new(name[:63], 4, 4)
    im["sw_ph"] = 1
    return im


def apply(S, ev, data):
    """Load downloaded bytes into the datablock called ev['name']."""
    kind, name, sha = ev.get("ak"), str(ev.get("name", ""))[:63], ev.get("sha")
    ext = ev.get("ext") if ev.get("ext") in EXTS else "bin"
    if not name or not isinstance(sha, str) or not re.fullmatch(r"[0-9a-f]{40}", sha):
        return
    key = (kind, name)
    if S.asset_sha.get(key) == sha:
        return
    path = os.path.join(cache_dir(), f"{sha}.{ext}")
    if not os.path.exists(path):
        with open(path, "wb") as f:
            f.write(data)
    if kind == "i":
        im = bpy.data.images.get(name)
        if im is None:
            im = bpy.data.images.load(path, check_existing=False)
            im.name = name
        else:
            im.source = "FILE"
            im.filepath = path
            im.reload()
        im.pack()
        if "sw_ph" in im:
            del im["sw_ph"]
        for attr, val in (("alpha_mode", ev.get("am")),):
            try:
                if isinstance(val, str):
                    setattr(im, attr, val)
            except (TypeError, ValueError):
                pass
        try:
            if isinstance(ev.get("cs"), str):
                im.colorspace_settings.name = ev["cs"]
        except (TypeError, ValueError):
            pass
        S.asset_fp[("i", name)] = (im.source, im.filepath, tuple(im.size), len(im.packed_file.data) if im.packed_file else -1,
                                   im.is_dirty, im.colorspace_settings.name, im.alpha_mode)
    elif kind == "f":
        vf = bpy.data.fonts.get(name)
        if vf is None:
            vf = bpy.data.fonts.load(path, check_existing=False)
            vf.name = name
        else:
            vf.filepath = path
        vf.pack()
        S.asset_fp[("f", name)] = (vf.filepath, len(vf.packed_file.data) if vf.packed_file else -1)
        refont()
    S.asset_sha[key] = sha


def refont():
    """Re-point text objects whose font arrived after the text did."""
    for cu in bpy.data.curves:
        want = cu.get("sw_fonts")
        if not isinstance(cu, bpy.types.TextCurve) or not want:
            continue
        for attr, n in zip(("font", "font_bold", "font_italic", "font_bold_italic"), want):
            vf = bpy.data.fonts.get(n) if n else None
            if vf is not None and getattr(cu, attr) is not vf:
                setattr(cu, attr, vf)
