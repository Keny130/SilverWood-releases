import bpy
import numpy as np

from . import assets

R = {"find": None}
MAT_CACHE = {}
ID = "sw_id"
SCENE_ID = "f" * 30 + "01"
MAX_KEYS = 6000
SKIP = {"rna_type", "name", "name_full", "users", "session_uid", "is_evaluated", "original", "id_data", "tag", "is_runtime_data",
        "use_fake_user", "library", "override_library", "asset_data", "is_embedded_data", "is_missing", "use_extra_user",
        "preview", "location", "rotation_euler", "rotation_quaternion", "rotation_axis_angle", "rotation_mode", "scale",
        "delta_location", "delta_rotation_euler", "delta_rotation_quaternion", "delta_scale", "dimensions", "hide_viewport",
        "parent_type", "parent_bone", "active_material_index", "active_shape_key_index", "frame_current", "frame_current_final",
        "frame_float", "frame_subframe", "filepath", "threads", "threads_mode", "use_persistent_data", "device", "is_dirty",
        "select", "is_active", "show_expanded", "is_override_data", "body", "body_format"}
PATHS = {'FILE_PATH', 'DIR_PATH', 'FILE_NAME', 'BYTE_STRING'}
DD_TYPES = {"LIGHT", "CAMERA", "FONT", "ARMATURE"}
MOD_TYPES = {"MESH", "FONT"}


class Defer(Exception):
    pass


def _alen(p):
    return getattr(p, "array_length", 0)


def _flat(v):
    for x in v:
        if hasattr(x, "__len__"):
            yield from _flat(x)
        else:
            yield x


def _val(st, p):
    v = getattr(st, p.identifier)
    if p.type == 'ENUM':
        return sorted(v) if p.is_enum_flag else v
    if p.type == 'FLOAT':
        return [round(x, 5) for x in _flat(v)] if _alen(p) else round(v, 5)
    return list(_flat(v)) if _alen(p) else v


def dump(st, ptr=False):
    out = {}
    for p in st.bl_rna.properties:
        k, t = p.identifier, p.type
        if k in SKIP or p.is_readonly and t != 'POINTER' or p.is_hidden or t == 'COLLECTION':
            continue
        try:
            if t == 'POINTER':
                if not ptr or not p.fixed_type or p.is_readonly:
                    continue
                v = getattr(st, k)
                if isinstance(v, bpy.types.Object):
                    s = v.get(ID)
                    if isinstance(s, str):
                        out[k] = {"@o": s}
                elif isinstance(v, bpy.types.Image):
                    out[k] = {"@i": v.name}
                elif v is None and p.fixed_type.identifier in {"Object", "Image"}:
                    out[k] = {"@n": 1}
            elif t == 'STRING' and p.subtype in PATHS or sum(1 for d in getattr(p, "array_dimensions", ()) if d) > 1:
                continue
            else:
                out[k] = _val(st, p)
        except (AttributeError, TypeError, RuntimeError, ValueError):
            pass
    return out


def load(st, d, ptr=False):
    if not isinstance(d, dict):
        return
    props = st.bl_rna.properties
    for k, v in d.items():
        p = props.get(k)
        if p is None or k in SKIP or p.is_readonly:
            continue
        try:
            if p.type == 'POINTER':
                if not ptr or not isinstance(v, dict):
                    continue
                if isinstance(v.get("@o"), str):
                    tgt = R["find"](v["@o"])
                    if tgt is None:
                        continue
                elif "@i" in v:
                    tgt = bpy.data.images.get(str(v["@i"])) or assets.placeholder(str(v["@i"]))
                elif "@n" in v:
                    tgt = None
                else:
                    continue
                if getattr(st, k) is not tgt:
                    setattr(st, k, tgt)
                continue
            if p.type == 'ENUM' and p.is_enum_flag:
                v = sorted(v) if isinstance(v, list) else []
            elif _alen(p) and not isinstance(v, list):
                continue
            if _val(st, p) != v:
                setattr(st, k, set(v) if p.type == 'ENUM' and p.is_enum_flag else v)
        except (TypeError, ValueError, AttributeError, RuntimeError, OverflowError):
            pass


def _set(st, k, v, nd=5):
    try:
        cur = getattr(st, k)
        cur = [round(x, nd) for x in cur] if hasattr(cur, "__len__") and not isinstance(cur, str) else cur
        if cur != v:
            setattr(st, k, v)
    except (TypeError, ValueError, AttributeError, RuntimeError):
        pass


def g_o(o):
    v = dump(o)
    if o.type == "EMPTY" and isinstance(o.data, bpy.types.Image):
        v["_img"] = o.data.name
    return v


def a_o(o, v):
    load(o, v)
    img = v.get("_img") if isinstance(v, dict) else None
    if isinstance(img, str) and o.type == "EMPTY":
        im = bpy.data.images.get(img[:63]) or assets.placeholder(img)
        if o.data is not im:
            o.data = im


def g_dd(o):
    v = dump(o.data)
    if o.type == "CAMERA":
        v["dof"] = dump(o.data.dof, True)
    return v


def a_dd(o, v):
    load(o.data, v)
    if o.type == "CAMERA" and isinstance(v, dict):
        load(o.data.dof, v.get("dof"), True)


def g_mod(o):
    return [[m.name, m.type, dump(m, True)] for m in o.modifiers]


def a_mod(o, v):
    want = [(str(e[0])[:63], str(e[1]), e[2] if len(e) > 2 else {}) for e in (v if isinstance(v, list) else [])
            if isinstance(e, list) and len(e) >= 2]
    names = {w[0] for w in want}
    cur = o.modifiers
    for m in list(cur):
        if m.name not in names:
            cur.remove(m)
    for n, t, pr in want:
        m = cur.get(n)
        if m is not None and m.type != t:
            cur.remove(m)
            m = None
        if m is None:
            try:
                m = cur.new(n, t)
            except (TypeError, RuntimeError, ValueError):
                continue
        load(m, pr, True)
    idx = [m.name for m in cur]
    for i, (n, _, _) in enumerate(want):
        if n in idx and idx.index(n) != i:
            cur.move(idx.index(n), i)
            idx.insert(i, idx.pop(idx.index(n)))


def g_txt(o):
    cu = o.data
    fmt = []
    for k, c in enumerate(cu.body_format):
        bits = c.use_bold | c.use_italic << 1 | c.use_underline << 2 | c.use_small_caps << 3
        if bits or c.material_index:
            fmt.append([k, bits, c.material_index])
    return {"b": cu.body, "f": [vf.name if vf else "" for vf in (cu.font, cu.font_bold, cu.font_italic, cu.font_bold_italic)],
            "bf": fmt}


def a_txt(o, v):
    cu = o.data
    if not isinstance(v, dict):
        return
    if o.mode == "EDIT":
        raise Defer()
    if isinstance(v.get("b"), str) and cu.body != v["b"]:
        cu.body = v["b"][:50000]
    if isinstance(v.get("f"), list) and len(v["f"]) == 4:
        cu["sw_fonts"] = [str(x)[:63] for x in v["f"]]
        assets.refont()
    want = {e[0]: e[1:] for e in v.get("bf", []) if isinstance(e, list) and len(e) == 3 and all(isinstance(x, int) for x in e)}
    for k, c in enumerate(cu.body_format):
        bits, mi = want.get(k, (0, 0))
        for attr, on in (("use_bold", bits & 1), ("use_italic", bits & 2), ("use_underline", bits & 4), ("use_small_caps", bits & 8)):
            if getattr(c, attr) != bool(on):
                setattr(c, attr, bool(on))
        if c.material_index != mi:
            c.material_index = mi


def g_pose(o):
    return [[b.name, b.rotation_mode, [round(x, 5) for x in b.location], [round(x, 5) for x in b.rotation_quaternion],
             [round(x, 5) for x in b.rotation_euler], [round(x, 5) for x in b.scale]] for b in o.pose.bones] if o.pose else []


def a_pose(o, v):
    if not o.pose:
        return
    for e in v if isinstance(v, list) else []:
        pb = o.pose.bones.get(e[0]) if isinstance(e, list) and len(e) >= 6 else None
        if pb is not None:
            for k, x in zip(("rotation_mode", "location", "rotation_quaternion", "rotation_euler", "scale"), e[1:6]):
                _set(pb, k, x)


def g_arm(o):
    out = []
    for b in o.data.bones:
        h, t = b.head_local, b.tail_local
        try:
            roll = bpy.types.Bone.AxisRollFromMatrix(b.matrix_local.to_3x3(), axis=(t - h).normalized())[1]
        except (ValueError, TypeError, RuntimeError):
            roll = 0.0
        out.append([b.name, b.parent.name if b.parent else "", [round(x, 5) for x in h], [round(x, 5) for x in t],
                    round(roll, 5), int(b.use_connect), int(b.use_deform)])
    return out


def a_arm(o, v):
    want = [e for e in (v if isinstance(v, list) else []) if isinstance(e, list) and len(e) >= 7]
    have = g_arm(o)
    if len(have) == len(want) and all(h[:2] == w[:2] and h[2] == w[2] and h[3] == w[3] for h, w in zip(have, want)):
        return
    if bpy.context.mode != 'OBJECT':
        raise Defer()
    vl = bpy.context.view_layer
    prev = vl.objects.active
    try:
        vl.objects.active = o
        bpy.ops.object.mode_set(mode='EDIT')
        try:
            eb = o.data.edit_bones
            names = {e[0] for e in want}
            for b in list(eb):
                if b.name not in names:
                    eb.remove(b)
            for e in want:
                b = eb.get(e[0]) or eb.new(e[0])
                b.head, b.tail, b.roll = e[2], e[3], e[4]
            for e in want:
                b = eb.get(e[0])
                b.parent = eb.get(e[1]) if e[1] else None
                b.use_connect, b.use_deform = bool(e[5]), bool(e[6])
        finally:
            bpy.ops.object.mode_set(mode='OBJECT')
    finally:
        vl.objects.active = prev


def _fcs(act):
    if hasattr(act, "layers"):
        return [fc for lay in act.layers for st in lay.strips for cb in getattr(st, "channelbags", ()) for fc in cb.fcurves]
    return list(act.fcurves)


def _anim_dump(o):
    ad = o.animation_data
    act = ad.action if ad else None
    if act is None:
        return None
    fcs, n = [], 0
    for fc in _fcs(act):
        kp = [[round(k.co[0], 4), round(k.co[1], 5), k.interpolation, k.handle_left_type, k.handle_right_type,
               round(k.handle_left[0], 4), round(k.handle_left[1], 5), round(k.handle_right[0], 4), round(k.handle_right[1], 5)]
              for k in fc.keyframe_points]
        n += len(kp)
        if n > MAX_KEYS:
            return {"a": act.name, "f": []}
        fcs.append([fc.data_path, fc.array_index, kp])
    return {"a": act.name, "f": fcs}


def _anim_load(o, v):
    ad = o.animation_data or o.animation_data_create()
    if not isinstance(v, dict):
        ad.action = None
        return
    old = ad.action
    ad.action = None
    if old is not None and old.users == 0:
        bpy.data.actions.remove(old)
    act = bpy.data.actions.new(str(v.get("a") or o.name)[:63])
    ad.action = act
    if hasattr(act, "slots"):
        if not len(act.slots):
            act.slots.new(o.id_type, o.name)
        try:
            ad.action_slot = act.slots[0]
        except (AttributeError, TypeError, RuntimeError):
            pass
    for e in v.get("f") or []:
        if not (isinstance(e, list) and len(e) >= 3 and isinstance(e[0], str) and isinstance(e[2], list) and e[2]):
            continue
        try:
            fc = act.fcurve_ensure_for_datablock(o, e[0], index=int(e[1])) if hasattr(act, "fcurve_ensure_for_datablock") \
                else act.fcurves.new(e[0], index=int(e[1]))
        except (TypeError, RuntimeError, ValueError):
            continue
        kps = [k for k in e[2] if isinstance(k, list) and len(k) >= 9]
        fc.keyframe_points.add(len(kps))
        for kp, k in zip(fc.keyframe_points, kps):
            try:
                kp.co = (k[0], k[1])
                kp.interpolation = k[2]
                kp.handle_left_type, kp.handle_right_type = k[3], k[4]
                kp.handle_left, kp.handle_right = (k[5], k[6]), (k[7], k[8])
            except (TypeError, ValueError):
                pass
        fc.update()


def _world(w):
    out = dump(w)
    bg = w.node_tree.nodes.get("Background") if getattr(w, "use_nodes", True) and w.node_tree else None
    if bg is not None:
        out["_bg"] = [[round(x, 4) for x in bg.inputs[0].default_value], round(bg.inputs[1].default_value, 4)]
    return out


def g_scene(sc):
    out = {"s": dump(sc), "r": dump(sc.render), "u": dump(sc.unit_settings), "vs": dump(sc.view_settings),
           "ds": dump(sc.display_settings)}
    for k, a in (("ee", "eevee"), ("cy", "cycles")):
        st = getattr(sc, a, None)
        if st is not None:
            out[k] = dump(st)
    cam = sc.camera.get(ID) if sc.camera else None
    if isinstance(cam, str):
        out["cam"] = cam
    if sc.world:
        out["w"] = _world(sc.world)
    return out


def a_scene(sc, v):
    if not isinstance(v, dict):
        return
    load(sc, v.get("s"))
    for k, st in (("r", sc.render), ("u", sc.unit_settings), ("vs", sc.view_settings), ("ds", sc.display_settings),
                  ("ee", getattr(sc, "eevee", None)), ("cy", getattr(sc, "cycles", None))):
        if st is not None:
            load(st, v.get(k))
    cam = v.get("cam")
    if isinstance(cam, str):
        c = R["find"](cam)
        if c is not None and sc.camera is not c:
            sc.camera = c
    wv = v.get("w")
    if sc.world and isinstance(wv, dict):
        load(sc.world, wv)
        bg = sc.world.node_tree.nodes.get("Background") if getattr(sc.world, "use_nodes", True) and sc.world.node_tree else None
        d = wv.get("_bg")
        if bg is not None and isinstance(d, list) and len(d) == 2 and isinstance(d[0], list):
            _set(bg.inputs[0], "default_value", d[0], 4)
            _set(bg.inputs[1], "default_value", d[1], 4)


MAX_VG_VERTS = 50_000
MAX_SK_FLOATS = 450_000
BONE_SKIP = {"head", "tail", "matrix", "matrix_local", "length", "select_head", "select_tail"}


def _vv(v):
    if isinstance(v, (bool, int, str)):
        return v
    if isinstance(v, float):
        return round(v, 5)
    if hasattr(v, "__len__"):
        try:
            return [round(x, 5) for x in _flat(v)]
        except TypeError:
            return None
    return None


def g_vg(o):
    vgs = o.vertex_groups
    if not len(vgs):
        return None
    me = o.data
    w = [[] for _ in vgs]
    if len(me.vertices) <= MAX_VG_VERTS:
        n = len(w)
        for v in me.vertices:
            for g in v.groups:
                if g.group < n:
                    w[g.group] += (v.index, round(g.weight, 4))
    return {"n": [[g.name, int(g.lock_weight)] for g in vgs], "w": w, "c": len(me.vertices)}


def a_vg(o, v):
    me = o.data
    if not isinstance(v, dict) or not isinstance(v.get("n"), list):
        if len(o.vertex_groups):
            o.vertex_groups.clear()
        return
    if o.mode == "EDIT":
        raise Defer()
    nv = len(me.vertices)
    ws = v.get("w") if isinstance(v.get("w"), list) else []
    if v.get("c") != nv:
        raise Defer()
    names = [(str(e[0])[:63], bool(e[1]) if len(e) > 1 else False) for e in v["n"] if isinstance(e, list) and e]
    o.vertex_groups.clear()
    for n, lock in names:
        o.vertex_groups.new(name=n).lock_weight = lock
    for gi, flat in enumerate(ws[:len(names)]):
        if not isinstance(flat, list) or not flat:
            continue
        byw = {}
        for k in range(0, len(flat) - 1, 2):
            vi, wt = flat[k], flat[k + 1]
            if isinstance(vi, int) and 0 <= vi < nv and isinstance(wt, (int, float)):
                byw.setdefault(float(wt), []).append(vi)
        grp = o.vertex_groups[gi]
        for wt, idx in byw.items():
            grp.add(idx, min(1.0, max(0.0, wt)), 'REPLACE')


def g_sk(o):
    key = o.data.shape_keys
    if key is None or not len(key.key_blocks):
        return None
    n = len(o.data.vertices)
    co_ok = 3 * n * len(key.key_blocks) <= MAX_SK_FLOATS
    ks = []
    for kb in key.key_blocks:
        e = {"n": kb.name, "v": round(kb.value, 5), "mn": round(kb.slider_min, 4), "mx": round(kb.slider_max, 4),
             "mu": int(kb.mute), "vg": kb.vertex_group, "rel": kb.relative_key.name, "it": kb.interpolation}
        if co_ok and len(kb.data) == n:
            arr = [0.0] * (3 * n)
            kb.data.foreach_get("co", arr)
            e["co"] = [round(x, 5) for x in arr]
        ks.append(e)
    return {"r": int(key.use_relative), "c": n, "k": ks}


def a_sk(o, v):
    me = o.data
    if not isinstance(v, dict) or not isinstance(v.get("k"), list) or not v["k"]:
        if me.shape_keys is not None:
            o.shape_key_clear()
        return
    if o.mode == "EDIT":
        raise Defer()
    n = len(me.vertices)
    ks = [e for e in v["k"] if isinstance(e, dict) and isinstance(e.get("n"), str)]
    if v.get("c") != n or not ks:
        raise Defer()
    have = [k.name for k in me.shape_keys.key_blocks] if me.shape_keys else []
    if have != [e["n"][:63] for e in ks]:
        o.shape_key_clear()
        for e in ks:
            o.shape_key_add(name=e["n"][:63], from_mix=False)
    key = me.shape_keys
    key.use_relative = bool(v.get("r", 1))
    for e in ks:
        kb = key.key_blocks.get(e["n"][:63])
        if kb is None:
            continue
        co = e.get("co")
        if isinstance(co, list) and len(co) == 3 * n and len(kb.data) == n and all(
                isinstance(x, (int, float)) for x in co):
            kb.data.foreach_set("co", co)
        for a, k in (("slider_min", "mn"), ("slider_max", "mx"), ("value", "v")):
            if isinstance(e.get(k), (int, float)):
                _set(kb, a, e[k], 4)
        if "mu" in e:
            kb.mute = bool(e["mu"])
        for a, k in (("vertex_group", "vg"), ("interpolation", "it")):
            if isinstance(e.get(k), str):
                _set(kb, a, e[k])
    for e in ks:
        kb = key.key_blocks.get(e["n"][:63])
        rel = key.key_blocks.get(str(e.get("rel", ""))[:63])
        if kb is not None and rel is not None and kb.relative_key is not rel:
            kb.relative_key = rel
    me.update()


def _cons_dump(coll):
    out = []
    for c in coll:
        d = dump(c, True)
        if c.type == "CHILD_OF":
            d["_inv"] = [round(x, 5) for row in c.inverse_matrix for x in row]
        tg = getattr(c, "targets", None)
        if tg is not None:
            d["_tg"] = [[t.target.get(ID) if t.target is not None and isinstance(t.target.get(ID), str) else None,
                         t.subtarget, round(t.weight, 4)] for t in tg]
        out.append([c.name, c.type, d])
    return out


def _cons_apply(coll, v):
    want = [(str(e[0])[:63], str(e[1]), e[2] if len(e) > 2 and isinstance(e[2], dict) else {}) for e in
            (v if isinstance(v, list) else []) if isinstance(e, list) and len(e) >= 2]
    names = {w[0] for w in want}
    for c in list(coll):
        if c.name not in names:
            coll.remove(c)
    for n, t, pr in want:
        c = next((x for x in coll if x.name == n), None)
        if c is not None and c.type != t:
            coll.remove(c)
            c = None
        if c is None:
            try:
                c = coll.new(t)
                c.name = n
            except (TypeError, RuntimeError, ValueError):
                continue
        load(c, pr, True)
        inv = pr.get("_inv")
        if c.type == "CHILD_OF" and isinstance(inv, list) and len(inv) == 16 and all(
                isinstance(x, (int, float)) for x in inv):
            try:
                from mathutils import Matrix
                m = Matrix([inv[0:4], inv[4:8], inv[8:12], inv[12:16]])
                if c.inverse_matrix != m:
                    c.inverse_matrix = m
            except (TypeError, ValueError, RuntimeError):
                pass
        tg = pr.get("_tg")
        if getattr(c, "targets", None) is not None and isinstance(tg, list):
            while len(c.targets) > len(tg):
                c.targets.remove(c.targets[-1])
            while len(c.targets) < len(tg):
                c.targets.new()
            for t_, e in zip(c.targets, tg):
                if isinstance(e, list) and len(e) >= 3:
                    tgt = R["find"](e[0]) if isinstance(e[0], str) else None
                    if t_.target is not tgt:
                        t_.target = tgt
                    _set(t_, "subtarget", e[1] if isinstance(e[1], str) else "")
                    _set(t_, "weight", e[2], 4)
    idx = [c.name for c in coll]
    for i, (n, _, _) in enumerate(want):
        if n in idx and idx.index(n) != i:
            coll.move(idx.index(n), i)
            idx.insert(i, idx.pop(idx.index(n)))


def g_anim(o):
    return _anim_dump(o)


def a_anim(o, v):
    _anim_load(o, v)


def g_ska(o):
    k = o.data.shape_keys
    return _anim_dump(k) if k is not None else None


def a_ska(o, v):
    k = o.data.shape_keys
    if k is not None:
        _anim_load(k, v)


def g_ada(o):
    return _anim_dump(o.data)


def a_ada(o, v):
    _anim_load(o.data, v)


def g_con(o):
    return _cons_dump(o.constraints) or None


def a_con(o, v):
    _cons_apply(o.constraints, v)


def g_bcon(o):
    out = {pb.name: c for pb in o.pose.bones for c in [_cons_dump(pb.constraints)] if c} if o.pose else {}
    return out or None


def a_bcon(o, v):
    if not o.pose:
        return
    v = v if isinstance(v, dict) else {}
    miss = False
    for pb in o.pose.bones:
        _cons_apply(pb.constraints, v.get(pb.name))
    miss = any(n not in o.pose.bones for n in v)
    if miss:
        raise Defer()


def g_bone(o):
    out = {}
    for b in o.data.bones:
        pb = o.pose.bones.get(b.name) if o.pose else None
        d = {k: x for k, x in dump(b).items() if k not in BONE_SKIP}
        out[b.name] = {"b": d, "p": dump(pb, True) if pb is not None else {}}
    return out


def a_bone(o, v):
    if not isinstance(v, dict):
        return
    miss = False
    for n, e in v.items():
        b = o.data.bones.get(n)
        if b is None or not isinstance(e, dict):
            miss = True
            continue
        load(b, e.get("b"))
        pb = o.pose.bones.get(n) if o.pose else None
        if pb is not None:
            load(pb, e.get("p"), True)
    if miss:
        raise Defer()


def g_bcol(o):
    arm = o.data
    cols = getattr(arm, "collections_all", None)
    if cols is None or not len(cols):
        return None
    return {"c": [[c.name, c.parent.name if c.parent else "", int(c.is_visible), int(c.is_solo)] for c in cols],
            "m": {b.name: [c.name for c in b.collections] for b in arm.bones if len(b.collections)}}


def a_bcol(o, v):
    arm = o.data
    if getattr(arm, "collections_all", None) is None:
        return
    v = v if isinstance(v, dict) else {}
    want = [e for e in v.get("c", []) if isinstance(e, list) and len(e) >= 4 and isinstance(e[0], str)]
    names = {e[0] for e in want}
    for c in list(arm.collections_all):
        if c.name not in names:
            arm.collections.remove(c)
    todo, guard = list(want), 0
    while todo and guard < 200:
        guard += 1
        nxt = []
        for e in todo:
            if arm.collections_all.get(e[0]) is not None:
                continue
            par = arm.collections_all.get(e[1]) if e[1] else None
            if e[1] and par is None:
                nxt.append(e)
                continue
            try:
                arm.collections.new(e[0], parent=par)
            except (TypeError, RuntimeError, ValueError):
                pass
        todo = nxt
    for e in want:
        c = arm.collections_all.get(e[0])
        if c is not None:
            _set(c, "is_visible", bool(e[2]))
            _set(c, "is_solo", bool(e[3]))
    mem = v.get("m") if isinstance(v.get("m"), dict) else {}
    miss = False
    for b in arm.bones:
        wantc = {c for c in mem.get(b.name, []) if isinstance(c, str)}
        for c in list(b.collections):
            if c.name not in wantc:
                c.unassign(b)
        for cn in wantc:
            c = arm.collections_all.get(cn)
            if c is not None and b not in list(c.bones):
                c.assign(b)
    if any(n not in arm.bones for n in mem):
        miss = True
    if miss:
        raise Defer()


def g_drv(o):
    ad = o.animation_data
    if ad is None or not len(ad.drivers):
        return None
    out = []
    for fc in ad.drivers:
        d = fc.driver
        vs = []
        for var in d.variables:
            tg = []
            for t in var.targets:
                oid = t.id.get(ID) if t.id is not None and isinstance(t.id, bpy.types.Object) else None
                tg.append([oid if isinstance(oid, str) else None, t.data_path, t.transform_type, t.transform_space,
                           t.rotation_mode, t.bone_target])
            vs.append([var.name, var.type, tg])
        out.append([fc.data_path, fc.array_index, d.type, d.expression, int(d.use_self), vs])
    return out


def a_drv(o, v):
    ad = o.animation_data
    want = [e for e in (v if isinstance(v, list) else []) if isinstance(e, list) and len(e) >= 6]
    if ad is not None:
        for fc in list(ad.drivers):
            ad.drivers.remove(fc)
    if not want:
        return
    ad = o.animation_data or o.animation_data_create()
    for e in want:
        try:
            fc = ad.drivers.new(e[0], index=int(e[1]))
        except (TypeError, RuntimeError, ValueError):
            continue
        d = fc.driver
        _set(d, "type", e[2])
        _set(d, "expression", e[3] if isinstance(e[3], str) else "")
        _set(d, "use_self", bool(e[4]))
        for ve in e[5] if isinstance(e[5], list) else []:
            if not (isinstance(ve, list) and len(ve) >= 3):
                continue
            try:
                var = d.variables.new()
                var.name = str(ve[0])[:63]
                var.type = ve[1]
            except (TypeError, RuntimeError, ValueError):
                continue
            for t, te in zip(var.targets, ve[2] if isinstance(ve[2], list) else []):
                if isinstance(te, list) and len(te) >= 6:
                    tgt = R["find"](te[0]) if isinstance(te[0], str) else None
                    if tgt is not None:
                        t.id = tgt
                    for a, x in zip(("data_path", "transform_type", "transform_space", "rotation_mode", "bone_target"),
                                    te[1:6]):
                        _set(t, a, x)


IDX_NODES = ("ShaderNodeGroup", "NodeGroupInput", "NodeGroupOutput")


def _sid(n, s, coll):
    return "#%d" % list(coll).index(s) if n.bl_idname in IDX_NODES else s.identifier


def _nt_dump(nt):
    nodes = []
    for n in nt.nodes:
        ins = [[_sid(n, s, n.inputs), x] for s in n.inputs if hasattr(s, "default_value") for x in [_vv(s.default_value)]
               if x is not None]
        e = {"i": n.bl_idname, "n": n.name, "l": [round(n.location.x, 1), round(n.location.y, 1)], "p": dump(n, True),
             "s": ins}
        if n.parent is not None:
            e["pa"] = n.parent.name
        if n.bl_idname == "ShaderNodeGroup" and n.node_tree is not None:
            e["g"] = n.node_tree.name
        cr = getattr(n, "color_ramp", None)
        if cr is not None:
            e["cr"] = [cr.interpolation, cr.color_mode, [[round(el.position, 5), [round(x, 5) for x in el.color]]
                                                         for el in cr.elements]]
        nodes.append(e)
    names = {e["n"] for e in nodes}
    links = sorted([l.from_node.name, _sid(l.from_node, l.from_socket, l.from_node.outputs), l.to_node.name,
                    _sid(l.to_node, l.to_socket, l.to_node.inputs)]
                   for l in nt.links if l.from_node.name in names and l.to_node.name in names)
    return {"nodes": nodes, "links": links}


def _sock(coll, ident):
    if isinstance(ident, str) and ident.startswith("#") and ident[1:].isdigit():
        items = list(coll)
        return items[int(ident[1:])] if int(ident[1:]) < len(items) else None
    return next((s for s in coll if s.identifier == ident and s.enabled), None) or next(
        (s for s in coll if s.identifier == ident), None)


def _nt_apply(nt, v):
    if not isinstance(v, dict):
        return
    want = [e for e in v.get("nodes", []) if isinstance(e, dict) and isinstance(e.get("i"), str) and isinstance(
        e.get("n"), str)]
    keep = {e["n"] for e in want}
    skip = ()
    for n in list(nt.nodes):
        if n.bl_idname not in skip and (n.name not in keep or any(
                e["n"] == n.name and e["i"] != n.bl_idname for e in want)):
            nt.nodes.remove(n)
    for e in want:
        n = nt.nodes.get(e["n"])
        if n is None:
            try:
                n = nt.nodes.new(e["i"])
                n.name = e["n"]
            except (TypeError, RuntimeError, ValueError):
                continue
        load(n, e.get("p"), True)
        if e["i"] == "ShaderNodeGroup" and isinstance(e.get("g"), str):
            g = ensure_group(e["g"])
            if g is not nt and n.node_tree is not g:
                n.node_tree = g
        loc = e.get("l")
        if isinstance(loc, list) and len(loc) == 2:
            _set(n, "location", loc, 1)
        cr = e.get("cr")
        if getattr(n, "color_ramp", None) is not None and isinstance(cr, list) and len(cr) == 3:
            ramp = n.color_ramp
            _set(ramp, "interpolation", cr[0])
            _set(ramp, "color_mode", cr[1])
            els = [x for x in cr[2] if isinstance(x, list) and len(x) == 2]
            while len(ramp.elements) > max(1, len(els)):
                ramp.elements.remove(ramp.elements[-1])
            while len(ramp.elements) < len(els):
                ramp.elements.new(1.0)
            for el, x in zip(ramp.elements, els):
                _set(el, "position", x[0])
                _set(el, "color", x[1])
    for e in want:
        n = nt.nodes.get(e["n"])
        pa = nt.nodes.get(e["pa"]) if isinstance(e.get("pa"), str) else None
        if n is not None and n.parent is not pa and pa is not n:
            n.parent = pa
            loc = e.get("l")
            if isinstance(loc, list) and len(loc) == 2:
                _set(n, "location", loc, 1)
    for e in want:
        n = nt.nodes.get(e["n"])
        if n is None:
            continue
        for s in e.get("s", []):
            if isinstance(s, list) and len(s) == 2:
                sk = _sock(n.inputs, s[0])
                if sk is not None and hasattr(sk, "default_value"):
                    _set(sk, "default_value", s[1])
    links = [l for l in v.get("links", []) if isinstance(l, list) and len(l) == 4]
    have = sorted([l.from_node.name, _sid(l.from_node, l.from_socket, l.from_node.outputs), l.to_node.name,
                   _sid(l.to_node, l.to_socket, l.to_node.inputs)] for l in nt.links)
    if have != sorted(links):
        nt.links.clear()
        for fn, fs, tn, ts in links:
            a, b = nt.nodes.get(fn), nt.nodes.get(tn)
            if a is None or b is None:
                continue
            so, si = _sock(a.outputs, fs), _sock(b.inputs, ts)
            if so is not None and si is not None:
                try:
                    nt.links.new(so, si)
                except (TypeError, RuntimeError, ValueError):
                    pass


def _mat_dump(m):
    d = {"p": dump(m)}
    nt = m.node_tree if getattr(m, "use_nodes", True) else None
    if nt is not None:
        d["nt"] = _nt_dump(nt)
    return d


def _mat_apply(m, d):
    if not isinstance(d, dict):
        return
    load(m, d.get("p"))
    if isinstance(d.get("nt"), dict):
        try:
            if not m.use_nodes:
                m.use_nodes = True
        except (AttributeError, RuntimeError):
            pass
        if m.node_tree is not None:
            _nt_apply(m.node_tree, d["nt"])
    if any(isinstance(e, dict) and e.get("g") for e in (d.get("nt") or {}).get("nodes", [])):
        PENDING[m.name] = d
    else:
        PENDING.pop(m.name, None)


PENDING = {}


def ensure_group(name, idname="ShaderNodeTree"):
    g = bpy.data.node_groups.get(name)
    if g is None:
        g = bpy.data.node_groups.new(name, idname)
        g.use_fake_user = True
    return g


def ngs_dump():
    out = []
    for g in bpy.data.node_groups:
        if g.bl_idname == "ShaderNodeTree" and g.library is None:
            out.append([g.name, [[i.in_out, i.name, i.socket_type] for i in g.interface.items_tree if i.item_type == "SOCKET"],
                        _nt_dump(g)])
    return sorted(out, key=lambda e: e[0])


def ngs_apply(v):
    ents = [e for e in (v if isinstance(v, list) else []) if isinstance(e, list) and len(e) == 3
            and isinstance(e[0], str) and isinstance(e[1], list) and isinstance(e[2], dict)]
    for name, iface, _ in ents:
        g = ensure_group(name)
        want = [x for x in iface if isinstance(x, list) and len(x) == 3]
        if [[i.in_out, i.name, i.socket_type] for i in g.interface.items_tree if i.item_type == "SOCKET"] != want:
            g.interface.clear()
            for io, nm, st in want:
                try:
                    g.interface.new_socket(name=str(nm)[:63], in_out=io, socket_type=st)
                except (TypeError, RuntimeError, ValueError):
                    pass
    for name, _, nt in ents:
        _nt_apply(bpy.data.node_groups[name], nt)
    for n, d in list(PENDING.items()):
        m = bpy.data.materials.get(n)
        if m is None:
            PENDING.pop(n)
        else:
            _mat_apply(m, d)


def g_mat(o):
    me = o.data
    if not len(me.materials):
        return None
    defs = {}
    for m in me.materials:
        if m is not None and m.name not in defs:
            d = MAT_CACHE.get(m.name)
            if d is None:
                d = MAT_CACHE[m.name] = _mat_dump(m)
            defs[m.name] = d
    return {"s": [m.name if m is not None else "" for m in me.materials], "d": defs}


def a_mat(o, v):
    me = o.data
    if not isinstance(v, dict) or not isinstance(v.get("s"), list):
        if len(me.materials):
            me.materials.clear()
        return
    defs = v.get("d") if isinstance(v.get("d"), dict) else {}
    slots = [str(s)[:63] for s in v["s"]]
    mats = {}
    for n in set(slots):
        if not n:
            continue
        m = bpy.data.materials.get(n) or bpy.data.materials.new(n)
        _mat_apply(m, defs.get(n))
        mats[n] = m
    if [m.name if m is not None else "" for m in me.materials] != slots:
        keep = np.empty(len(me.polygons), "i4")
        me.polygons.foreach_get("material_index", keep)
        me.materials.clear()
        for n in slots:
            me.materials.append(mats.get(n))
        if len(keep) and keep.any():
            me.polygons.foreach_set("material_index", keep)


GROUPS = {
    "o": (g_o, a_o, lambda o: True, True),
    "dd": (g_dd, a_dd, lambda o: o.type in DD_TYPES, False),
    "arm": (g_arm, a_arm, lambda o: o.type == "ARMATURE", False),
    "pose": (g_pose, a_pose, lambda o: o.type == "ARMATURE", True),
    "ada": (g_ada, a_ada, lambda o: o.type == "ARMATURE", False),
    "mod": (g_mod, a_mod, lambda o: o.type in MOD_TYPES, True),
    "anim": (g_anim, a_anim, lambda o: True, False),
    "con": (g_con, a_con, lambda o: True, True),
    "bcon": (g_bcon, a_bcon, lambda o: o.type == "ARMATURE", True),
    "bone": (g_bone, a_bone, lambda o: o.type == "ARMATURE", True),
    "bcol": (g_bcol, a_bcol, lambda o: o.type == "ARMATURE", False),
    "drv": (g_drv, a_drv, lambda o: True, True),
    "vg": (g_vg, a_vg, lambda o: o.type == "MESH", "geo"),
    "sk": (g_sk, a_sk, lambda o: o.type == "MESH", "key"),
    "ska": (g_ska, a_ska, lambda o: o.type == "MESH", "key"),
    "mat": (g_mat, a_mat, lambda o: o.type in MOD_TYPES, "mat"),
    "txt": (g_txt, a_txt, lambda o: o.type == "FONT", True),
}


def due(cheap, new, allg, geo_hit, mat_hit):
    return (new or cheap is True or (allg and cheap is False) or (cheap == "geo" and geo_hit)
            or (cheap == "key" and (allg or geo_hit)) or (cheap == "mat" and (mat_hit or geo_hit)))
