import math
import random
import time

import bpy
from bpy_extras import view3d_utils
from mathutils import Vector

from . import sync

SHAPES = (
    ((240, 37), (185, 100), (155, 102), (190, 118), (330, 118), (338, 104), (305, 100), (240, 37)),
    ((50, 132), (440, 132), (440, 357), (50, 357), (50, 132)),
    ((60, 142), (88, 160)), ((432, 142), (406, 166)), ((60, 352), (100, 314)), ((432, 352), (400, 316)),
    ((108, 247), (147, 203), (186, 247)), ((316, 247), (352, 205), (388, 247)))
MOUTH = ((218, 339), (285, 339))
MOUTH_OPEN = ((226, 326), (277, 326), (277, 352), (226, 352), (226, 326))
CPS = 26
D = {"mode": "off", "ptr": None}
_snd = {}
CUBE = "Duddy's Cube"

STEPS = [
    dict(k="say", at=(0.5, 0.5), t="Hi! I'm Duddy, your SilverWood assistant. Let me show you around."),
    dict(k="say", at="launcher", t="This little button is your SilverWood menu. Click it for Settings, Account, Lobbies and Chat."),
    dict(k="say", at=(0.5, 0.82), t="SilverWood is still in BETA, so expect a few bugs. Save your work often!"),
    dict(k="say", at=(0.8, 0.45), t="Everyone in your session shows up here as a coloured cursor with their name. Press Shift+Alt+P to ping the spot you are looking at."),
    dict(k="say", at=(0.22, 0.55), t="Host Worldwide turns your PC into the server, with no size limit. Friends join with a short code."),
    dict(k="ask", at=(0.5, 0.5), t="Want to create your first Worldwide host right now?"),
    dict(k="host"),
    dict(k="join"),
    dict(k="spawn"),
    dict(k="say3", look="around", act="hold", t="I'm in! See my cursor? I just put a cube down right there. Everyone in the session can see it."),
    dict(k="select"),
    dict(k="say3", look="around", act="rotate", t="Now I've selected it, so I can rotate it..."),
    dict(k="say3", look="around", act="move", t="...and move it around. Everything I do shows up live for your friends too!"),
    dict(k="say3", look="stare", t="Hello there! I'm looking right at you. Your friends will see you like this too, so wave!"),
    dict(k="say3", look="around", t="Share your code from the Account tab and build together."),
    dict(k="say3", look="around", act="back", desel=True, t="Oh wait, I almost forgot! I was going to delete this before I left."),
    dict(k="select"),
    dict(k="remove"),
    dict(k="say3", look="stare", t="Bye!!"),
    dict(k="leave"),
    dict(k="wait", s=2.5),
    dict(k="say", at=(0.5, 0.5), enter=True, id="bye", t="I'm back! I just wanted to say goodbye. Have fun building together. Bye bye!", last=True),
    dict(k="say", at=(0.5, 0.5), id="no", t="No problem. Press my button in the SilverWood menu any time. Bye for now!", last=True),
    dict(k="say", at=(0.5, 0.5), id="ai", t="Yes! I will. I am a BETA helper, so I can make mistakes."),
    dict(k="host"),
    dict(k="join"),
    dict(k="say3", look="around", t="I'm in! Use the box at the bottom and ask me to select, move or build things."),
    dict(k="idle", look="around"),
    dict(k="leave", id="aileave"),
    dict(k="say", at=(0.5, 0.5), enter=True, t="Bye! Ask me to join again any time.", last=True),
]


def _beep(ch):
    if not ch.isalnum():
        return
    try:
        if "dev" not in _snd:
            import aud
            _snd["aud"], _snd["dev"] = aud, aud.Device()
        a = _snd["aud"]
        f = 175 + (ord(ch.lower()) % 9) * 11 + random.random() * 6
        _snd["dev"].play(a.Sound.sine(f).limit(0, 0.07).fadein(0, 0.01).fadeout(0.03, 0.04).volume(0.09))
    except Exception:
        _snd["dev"] = _snd["aud"] = None


def start(ptr, key=None):
    if ptr is None or D["mode"] != "off":
        return
    now = time.time()
    D.update(mode="2d", ptr=ptr, i=-1 if key is None else next(n for n, s in enumerate(STEPS) if s.get("id") == key) - 1, focus=None, selname=None, pos=None, t=now, hop=0.0, shown=0, since=now, text="", yaw=0.0, look="stare",
             alpha=0.0, failed=False, sel=False, cube_t=None, cube_p=None, act="", rot=[0.3, 0.2, 0.0], world=None, hold=0.0, done_typing=False, wait_until=0)
    _next()
    bpy.app.timers.register(_tick, first_interval=0.03)


def inside():
    return D["mode"] == "3d" and 0 <= D["i"] < len(STEPS) and STEPS[D["i"]]["k"] == "idle"


def say(t):
    if inside():
        D.update(text=t[:240], shown=0, since=time.time(), done_typing=False, hold=0.0)


def leave():
    if inside():
        _noedit()
        _goto("aileave")


def _noedit():
    from . import ui
    if ui._ui["edit"] == "field:dbox":
        ui._ui["edit"] = None


def stop():
    _noedit()
    D["mode"] = "off"
    bpy.app.timers.register(_rm_cube, first_interval=0)
    sync.redraw()


def _spawn_cube():
    _del_cube()
    me = bpy.data.meshes.new(CUBE)
    v = [(x, y, z) for x in (-1, 1) for y in (-1, 1) for z in (-1, 1)]
    me.from_pydata(v, [], [(0, 1, 3, 2), (4, 6, 7, 5), (0, 4, 5, 1), (2, 3, 7, 6), (0, 2, 6, 4), (1, 5, 7, 3)])
    ob = bpy.data.objects.new(CUBE, me)
    (bpy.context.collection or bpy.context.scene.collection).objects.link(ob)
    return None


def _del_cube():
    ob = bpy.data.objects.get(CUBE)
    if ob is not None:
        me = ob.data
        bpy.data.objects.remove(ob)
        if me is not None and me.users == 0:
            bpy.data.meshes.remove(me)


def _rm_cube():
    _del_cube()
    D["cube_t"] = D["cube_p"] = None
    return None


def _tick():
    if D["mode"] == "off":
        return None
    ob, t = bpy.data.objects.get(CUBE), D.get("cube_t")
    if ob is not None and t:
        ob.location, ob.rotation_euler, ob.scale = t[0], t[1], (t[2],) * 3
    sync.redraw()
    return 1 / 30


def _goto(key):
    D["i"] = next(n for n, s in enumerate(STEPS) if s.get("id") == key) - 1
    _next()


def _next():
    D["i"] += 1
    if D["i"] >= len(STEPS):
        return stop()
    s = STEPS[D["i"]]
    D.update(text=s.get("t", ""), shown=0, since=time.time(), done_typing=False, hold=0.0, ask=s["k"] == "ask")
    D["act"] = s.get("act", "")
    D["cur_to"] = "spot" if s["k"] == "spawn" else "cube" if s.get("act") == "back" else None
    if D.get("world"):
        D["world"]["tw"].clear()
    if s.get("desel"):
        D["sel"] = False
    if s["k"] in ("say3", "idle"):
        D["look"] = s["look"]
    if s["k"] == "join":
        _join()
    elif s["k"] == "select":
        D["sel"] = True
    elif s["k"] == "remove":
        D["sel"] = False
        bpy.app.timers.register(_rm_cube, first_interval=0)
    elif s["k"] == "leave":
        D.update(leaving=time.time())
        sync.chat_add("Duddy", (1, 1, 1), "left the session", system=True)
    elif s["k"] == "wait":
        D["wait_until"] = time.time() + s["s"]
    elif s["k"] == "host":
        D["host_t"] = time.time()
        try:
            if sync.status() == "disconnected":
                sync.start("tunnel")
        except (ValueError, OSError):
            D["text"] = "Hmm, I could not start hosting. Open the welcome screen and press One-Click Setup, then try again."
            D["failed"] = True
        else:
            D["text"] = "Starting your Worldwide host..."
    if s.get("enter"):
        D.update(mode="2d", pos=None, alpha=0.0)


def click(name):
    s = STEPS[D["i"]] if 0 <= D["i"] < len(STEPS) else {}
    if name == "duddy:skip":
        return stop()
    if name == "duddy:leave":
        return leave()
    if name == "duddy:yes":
        return _next()
    if name == "duddy:no":
        return _goto("no")
    if D["shown"] < len(D["text"]):
        D["shown"] = len(D["text"])
    elif s.get("last"):
        stop()
    else:
        _next()


def _join():
    sync.chat_add("Duddy", (1, 1, 1), "joined the session with your code", system=True)
    D.update(mode="3d", world=None, alpha=0.0)


def _world_setup(rv):
    rot, dist = rv.view_rotation, max(rv.view_distance, 0.5)
    right, up = rot @ Vector((1, 0, 0)), rot @ Vector((0, 1, 0))
    spot = rv.view_location - right * 0.15 * dist
    D["world"] = dict(r=right, u=up, f=right.cross(up), d=dist, spot=spot, P=spot.copy(), cur=spot + right * 0.5 * dist, cur_tw=None, tw={},
                      yaw=random.uniform(0, math.tau), pitch=0.5, dist=0.8 * dist, g=Vector((0, 0, -1)),
                      seg=dict(t0=0.0, dur=1.0, rest=0.0, a=(0, 0, 0), b=(0, 0, 0)))


def _ease(t):
    t = min(max(t, 0.0), 1.0)
    return t * t * t * (t * (6 * t - 15) + 10)


def _drift(w, key, now, val, pick):
    tw = w["tw"].get(key)
    if tw is None or now >= tw[0] + tw[1] + tw[4]:
        b, dur, rest = pick(val)
        tw = w["tw"][key] = [now, dur, val.copy() if hasattr(val, "copy") else val, b, rest]
    return tw[2] + (tw[3] - tw[2]) * _ease((now - tw[0]) / tw[1])


def _cam(w, now, dt, target, stare, viewer):
    d, sg = w["d"], w["seg"]
    if now >= sg["t0"] + sg["dur"] + sg["rest"]:
        a = (w["yaw"], w["pitch"], w["dist"])
        yaw, pitch, dist = a
        roll = random.random()
        if roll < 0.55:
            yaw += random.choice((-1, 1)) * random.uniform(0.35, 1.1)
        elif roll < 0.75:
            pitch = min(1.2, max(0.2, pitch + random.uniform(-0.3, 0.3)))
        else:
            dist = min(d, max(0.4 * d, dist * random.uniform(0.8, 1.25)))
        sg = w["seg"] = dict(t0=now, dur=random.uniform(0.9, 1.9), rest=random.uniform(0.5, 2.2), a=a, b=(yaw, pitch, dist))
    e = _ease((now - sg["t0"]) / sg["dur"])
    w["yaw"], w["pitch"], w["dist"] = (x + (y - x) * e for x, y in zip(sg["a"], sg["b"]))
    w["P"] += (target - w["P"]) * (1 - math.exp(-dt * 1.5))
    cp = math.cos(w["pitch"])
    pos = w["P"] + Vector((cp * math.cos(w["yaw"]), cp * math.sin(w["yaw"]), math.sin(w["pitch"]))) * w["dist"]
    sway = Vector((math.sin(now * 0.9), math.sin(now * 1.3), math.sin(now * 1.7))) * 0.015 * d
    t = (viewer - pos) if stare else (w["P"] + sway - pos)
    if t.length > 1e-6:
        w["g"] += (t.normalized() - w["g"]) * (1 - math.exp(-dt * (2.5 if stare else 6)))
        w["g"].normalize()
    return pos, w["g"].to_track_quat('-Z', 'Y')


def _target(s, W, H):
    at = s.get("at", (0.5, 0.5))
    return (92, 82) if at == "launcher" else (W * at[0], H * at[1])


def draw(r, rv):
    from . import ui
    if D["mode"] == "off" or bpy.context.area is None or bpy.context.area.as_pointer() != D["ptr"]:
        return
    now = time.time()
    dt, D["t"] = min(now - D["t"], 0.1), now
    s = STEPS[D["i"]]
    W, H, size = r.width, r.height, 96
    D["alpha"] = min(1.0, D["alpha"] + dt * 3)
    typed = D["shown"]
    if not D["done_typing"]:
        want = min(len(D["text"]), int((now - D["since"]) * CPS))
        for ch in D["text"][typed:want]:
            _beep(ch)
            D["hop"] = 1.0
        D["shown"] = want
        D["done_typing"] = want >= len(D["text"])
        if D["done_typing"]:
            D["hold"] = now
    talking = D["shown"] < len(D["text"])
    D["hop"] = max(0.0, D["hop"] - dt * 7)
    k = s["k"]
    if k == "idle":
        from . import ai, ui
        bw0 = min(460, W - 130)
        bx0 = (W - bw0) / 2
        ui._field("field:dbox", ui._ui.get("draft_ai", ""), "Duddy is thinking..." if ai.A["busy"] else "Ask Duddy... (select, move, build)", bx0, 14, bw0, 32)
        ui._beta(bx0, 52)
        ui._text("Experimental - edits are real, Ctrl+Z undoes them", bx0 + 58, 54, 12, (1.0, 0.62, 0.2, 1))
        ui._button("duddy:leave", "Leave", bx0 + bw0 + 8, 14, 56, 32, ui.PURPLE, 13)
        if D["text"] and D["done_typing"] and now - D["hold"] > 4 + 0.05 * len(D["text"]):
            D.update(text="", shown=0)
    if k == "host" and not D.get("failed") and not talking:
        st = sync.status()
        if st == "connected":
            return _next()
        if st == "error" or now - D["host_t"] > 45:
            D.update(text="Hmm, the tunnel did not start. Press One-Click Setup on the welcome screen and ask me again later.", failed=True,
                     shown=0, since=now, done_typing=False)
        elif st == "disconnected":
            D["host_t"] = now
    if k == "host" and D.get("failed") and D["done_typing"] and now - D["hold"] > 3:
        return _goto("no")
    if k in ("say", "say3") and D["done_typing"] and now - D["hold"] > 2.2 + 0.03 * len(D["text"]) and not s.get("last"):
        return _next()
    if k == "wait" and now > D["wait_until"]:
        return _next()
    if k in ("join", "remove"):
        return _next()
    if k == "select" and now - D["since"] > 1.6:
        return _next()
    if k == "leave" and now - D["leaving"] > 1.6:
        D["mode"] = "2d"
        D["alpha"] = 0.0
        return _next()
    if k == "wait":
        return
    if k == "leave":
        D["alpha"] = max(0.0, 1 - (now - D["leaving"]) / 1.5)
    hop = abs(math.sin(D["hop"] * math.pi / 2)) * 9
    bob = math.sin(now * 2.2) * 3
    if D["mode"] == "3d":
        if D["world"] is None:
            _world_setup(rv)
        w = D["world"]
        act, d, cube_p = D["act"], w["d"], D["cube_p"]
        viewer = rv.view_matrix.inverted().translation
        if D.get("cur_to"):
            tgt = D["focus"] if D["cur_to"] == "focus" else cube_p if D["cur_to"] == "cube" and cube_p is not None else w["spot"]
            w["cur_tw"] = [now, 1.1, w["cur"].copy(), tgt.copy(), 0.35]
            D["cur_to"] = None
        ct = w["cur_tw"]
        if ct:
            w["cur"] = ct[2] + (ct[3] - ct[2]) * _ease((now - ct[0]) / ct[1])
            if k == "spawn" and now >= ct[0] + ct[1] + ct[4]:
                D["cube_p"], D["rot"] = w["spot"].copy(), [0.3, 0.2, 0.0]
                bpy.app.timers.register(_spawn_cube, first_interval=0)
                return _next()
        co, q = _cam(w, now, dt, D["focus"] if D.get("focus") is not None else cube_p if cube_p is not None else w["spot"], D["look"] == "stare" and k != "spawn", viewer)
        if cube_p is not None:
            if act == "rotate":
                D["rot"][2] = _drift(w, "rz", now, D["rot"][2], lambda v: (v + random.choice((-1, 1)) * random.uniform(0.6, 1.4), random.uniform(0.7, 1.3), random.uniform(0.2, 0.6)))
                D["rot"][0] = _drift(w, "rx", now, D["rot"][0], lambda v: (v + random.choice((-1, 1)) * random.uniform(0.3, 0.7), random.uniform(0.7, 1.3), random.uniform(0.2, 0.6)))
            elif act == "move":
                D["cube_p"] = cube_p = _drift(w, "mv", now, cube_p, lambda v: (
                    w["spot"] + w["r"] * random.uniform(-0.35, 0.35) * d + w["u"] * random.uniform(-0.2, 0.2) * d + w["f"] * random.uniform(-0.3, 0.3) * d,
                    random.uniform(0.9, 1.5), random.uniform(0.6, 1.4)))
            D["cube_t"] = (cube_p, tuple(D["rot"]), 1.0)
        if k == "leave":
            co = co + w["u"] * (now - D["leaving"]) * 0.25 * w["d"]
        D["lines"] = None
        p2 = view3d_utils.location_3d_to_region_2d(r, rv, co)
        p3 = view3d_utils.location_3d_to_region_2d(r, rv, co + w["r"] * 0.3 * w["d"])
        if p2 is None or p3 is None:
            return
        size = max(30.0, min(260.0, (p3 - p2).length * 1.2))
        px, py = p2.x, p2.y
        s3 = 0.07 * w["d"]
        co = co + w["u"] * D["hop"] * 0.12 * s3
        D["lines"] = ui.cam_lines(co, q, s3) + _face3(co, q, s3, talking, now)
        cb = bpy.data.objects.get(D.get("selname") or CUBE)
        if D.get("sel") and cb is not None:
            D["lines"] += ui._bbox(cb)
        x, y, z = w["cur"]
        dc = 0.3
        D["lines"] += [(x - dc, y, z), (x + dc, y, z), (x, y - dc, z), (x, y + dc, z), (x, y, z - dc), (x, y, z + dc)]
        ui._text("Duddy (BETA)", px + 10, py + 10, 13, (1, 1, 1, D["alpha"]))
        pc = view3d_utils.location_3d_to_region_2d(r, rv, w["cur"])
        if pc is not None and k != "leave":
            ui._text("Duddy", pc.x + 10, pc.y + 8, 13, (1, 1, 1, D["alpha"]))
    else:
        tx, ty = _target(s, W, H)
        if D["pos"] is None:
            D["pos"] = [W + 100, ty]
        e = 1 - math.exp(-dt * 3.5)
        D["pos"][0] += (tx - D["pos"][0]) * e
        D["pos"][1] += (ty - D["pos"][1]) * e
        px, py = D["pos"]
        D["yaw"] = 0.0
    py += bob + hop
    a = D["alpha"]
    if D["mode"] != "3d":
        gpu_draw_face(ui, px, py, size, D["yaw"], (1, 1, 1, a), talking, now)
    if not D["text"]:
        return
    bw, lines = 300, ui._wrap(D["text"], 14, 276)
    bh = 26 + 20 * len(lines) + 34
    if D["mode"] == "3d":
        bx, by = (W - bw) / 2, 76
    else:
        bx = max(10, min(W - bw - 10, px - bw / 2))
        by = py + size * 0.55 + 14
        if by + bh > H - 10:
            by = py - size * 0.55 - 14 - bh
    ui._rect(bx, by, bw, bh, (*ui.BG, 0.97 * a), r=6)
    ui._rect(bx, by, bw, bh, (*ui.LINE, a), outline=True, r=6)
    shown = D["text"][:D["shown"]]
    left, ly = shown, by + bh - 24
    for ln in lines:
        part = left[:len(ln) + 1]
        left = left[len(ln) + 1:]
        ui._text(part.rstrip(), bx + 12, ly, 14, (0.92, 0.92, 0.95, a))
        ly -= 20
    row = by + 6
    if D["ask"]:
        btns = (("duddy:yes", "Yes, host!", 12, 112, ui.ACCENT), ("duddy:no", "Maybe later", 132, 100, ui.PURPLE), ("duddy:skip", "Skip", 240, 48, ui.PURPLE))
    else:
        btns = () if k == "idle" else (("duddy:next", "Bye" if s.get("last") else "Next >", bw - 140, 62, ui.ACCENT), ("duddy:skip", "Skip", bw - 70, 58, ui.PURPLE))
    for nm, lab, dx, bwid, col in btns:
        if D["ask"] and nm != "duddy:skip" and not D["done_typing"]:
            continue
        ui._button(nm, lab, bx + dx, row, bwid, 26, col, 13)
        ui._hit(nm, "btn", bx + dx, row, bwid, 26)


def _face3(co, q, s, talk, now):
    def P(x, y):
        return co + q @ Vector((x * s, y * s, -1.5 * s))
    out = []
    for cx in (-0.4, 0.4):
        out += [P(cx - 0.15, 0.02), P(cx, 0.22), P(cx, 0.22), P(cx + 0.15, 0.02)]
    if talk and int(now * 10) % 2 == 0:
        c = ((-0.1, -0.14), (0.1, -0.14), (0.1, -0.26), (-0.1, -0.26))
        out += [P(*c[i]) for n in range(4) for i in (n, (n + 1) % 4)]
    else:
        out += [P(-0.12, -0.2), P(0.12, -0.2)]
    return out


def face_lines(cx, cy, size, yaw=0.0, mouth_open=False):
    s, cw = size / 400.0, math.cos(yaw)
    sx = s * (cw if abs(cw) > 0.12 else 0.12 if cw >= 0 else -0.12)
    sh = math.sin(yaw) * size * 0.12

    def pt(p):
        return (cx + (p[0] - 245) * sx + sh, cy - (p[1] - 245) * s)
    out = []
    for poly in SHAPES + ((MOUTH_OPEN,) if mouth_open else (MOUTH,)):
        for a, b in zip(poly, poly[1:]):
            out += [pt(a), pt(b)]
    return out


def gpu_draw_face(ui, cx, cy, size, yaw, col, talking, now):
    ui._lines(face_lines(cx, cy, size, yaw, talking and int(now * 10) % 2 == 0), col, max(1.5, size / 36))
