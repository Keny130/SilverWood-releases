import hashlib
import random
import re
import threading
import time

COMMUNITY_SID = "FREEFORALL"
LOBBY_TTL_MS = 180_000
STALE_MS = 600_000
HEARTBEAT_MS = 120_000
WINDOW = 30
SHARDS = 16
MAX_LISTED = 40
PING_TIMEOUT = 4.0
LID_RE = re.compile(r"[0-9a-f]{12}")
CODE_RE = re.compile(r"[A-Z2-7]{8}|[A-Z2-7]{32,200}")


def lobby_id(code):
    return hashlib.sha1(code.replace("-", "").encode()).hexdigest()[:12]


def entry(name, owner, code, kind, users, version):
    return {"n": name.strip()[:40] or "Lobby", "o": owner[:32], "c": code.replace("-", ""), "k": "w" if kind == "tunnel" else "f",
            "u": int(users), "t": int(time.time() * 1000), "v": str(version)[:12]}


def clean(lid, e, now_ms):
    if not (LID_RE.fullmatch(lid) and isinstance(e, dict)):
        return None
    n, o, c, k, u, t = (e.get(x) for x in ("n", "o", "c", "k", "u", "t"))
    if not (isinstance(n, str) and isinstance(o, str) and isinstance(c, str) and CODE_RE.fullmatch(c) and k in ("w", "f")):
        return None
    if isinstance(u, bool) or not isinstance(u, int) or isinstance(t, bool) or not isinstance(t, (int, float)):
        return None
    if now_ms - t > LOBBY_TTL_MS:
        return None
    if (k == "f") != (len(c) == 8):
        return None
    ok = lambda s: "".join(ch for ch in s if ch.isprintable())
    return {"id": lid, "name": ok(n)[:40] or "Lobby", "owner": ok(o)[:32] or "?", "code": c, "kind": k,
            "users": max(0, min(u, 1_000_000)), "ms": 0}


def fetch_list(fb):
    d = fb.call("GET", "lobbies", timeout=8)
    d = d if isinstance(d, dict) else {}
    now = time.time() * 1000
    stale = {k: None for k, v in d.items() if not isinstance(v, dict) or not isinstance(v.get("t"), (int, float))
             or now - v["t"] > STALE_MS}
    if stale:
        try:
            fb.call("PATCH", "lobbies", stale, timeout=8)
        except Exception:
            pass
    rows = [r for r in (clean(k, v, now) for k, v in d.items()) if r]
    rows.sort(key=lambda r: (-r["users"], r["name"].lower()))
    return rows[:MAX_LISTED]


def ping(base, token, path, uid=""):
    from . import net
    try:
        c = net.Client(base, token, uid)
        t0 = time.time()
        c.call("GET", path, timeout=PING_TIMEOUT)
        return max(1, int((time.time() - t0) * 1000))
    except Exception:
        return 0


def ping_all(rows, db_url, token, resolve):
    def one(r):
        try:
            if r["kind"] == "f":
                r["ms"] = ping(db_url, token, f"sessions/{r['code']}/status")
            else:
                base, tok = resolve(r["code"])
                r["ms"] = ping(base, tok, "sessions/main/status")
        except Exception:
            r["ms"] = 0

    ts = [threading.Thread(target=one, args=(r,), daemon=True) for r in rows]
    for t in ts:
        t.start()
    end = time.time() + PING_TIMEOUT + 1
    for t in ts:
        t.join(max(0.0, end - time.time()))


def shard(cid):
    return cid[:1] if cid[:1] in "0123456789abcdef" else "0"


def heartbeat(fb, cid):
    fb.call("PUT", f"community/{shard(cid)}/{cid}", int(time.time() * 1000), timeout=8)


def leave(fb, cid):
    fb.call("DELETE", f"community/{shard(cid)}/{cid}", timeout=4)


def _fresh(d, now):
    return sum(1 for v in d.values() if isinstance(v, (int, float)) and not isinstance(v, bool) and now - v < HEARTBEAT_MS)


def count(fb):
    now = time.time() * 1000
    s = random.choice("0123456789abcdef")
    d = fb.call("GET", f"community/{s}", timeout=8)
    d = d if isinstance(d, dict) else {}
    n = _fresh(d, now)
    if n >= 6:
        stale = {k: None for k, v in d.items() if not isinstance(v, (int, float)) or now - v > STALE_MS}
        if stale:
            try:
                fb.call("PATCH", f"community/{s}", stale, timeout=8)
            except Exception:
                pass
        return n * SHARDS
    tree = fb.call("GET", "community", timeout=8)
    tree = tree if isinstance(tree, dict) else {}
    return sum(_fresh(v, now) for v in tree.values() if isinstance(v, dict))


def every(n):
    return 3.0 if n < 50 else 6.0 if n < 500 else 12.0


def events_every(n):
    return 1.0 if n < 200 else 2.5
