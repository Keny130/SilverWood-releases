import glob
import os
import sys

import blf

from . import assets

MAX_BYTES = 5 * 1024 * 1024
_ids, _list = {}, []


def dirs():
    if sys.platform == "win32":
        return [os.path.join(os.environ.get("WINDIR", r"C:\Windows"), "Fonts"),
                os.path.join(os.environ.get("LOCALAPPDATA", ""), "Microsoft", "Windows", "Fonts")]
    if sys.platform == "darwin":
        return ["/Library/Fonts", "/System/Library/Fonts", os.path.expanduser("~/Library/Fonts")]
    return ["/usr/share/fonts", os.path.expanduser("~/.fonts"), os.path.expanduser("~/.local/share/fonts")]


def listing(refresh=False):
    if _list and not refresh:
        return _list
    found = {}
    for d in dirs():
        for root, _, files in os.walk(d):
            for f in files:
                if f.lower().endswith((".ttf", ".otf")):
                    p = os.path.join(root, f)
                    try:
                        if os.path.getsize(p) <= MAX_BYTES:
                            found.setdefault(os.path.splitext(f)[0], p)
                    except OSError:
                        pass
    _list[:] = sorted(found.items(), key=lambda e: e[0].lower())
    return _list


def blf_id(path):
    if path not in _ids:
        try:
            fid = blf.load(path)
        except Exception:
            fid = -1
        _ids[path] = fid if fid >= 0 else 0
    return _ids[path]


def fid_for(S, name):
    if not name:
        return 0
    if name == S.my_font:
        return blf_id(S.my_font_path)
    sha = S.asset_sha.get(("f", name))
    hits = glob.glob(os.path.join(assets.cache_dir(), sha + ".*")) if sha else []
    return blf_id(hits[0]) if hits else 0
