"""SilverWood main-thread logic: change detection, remote event application, presence.

Policy
- Identity: every synced object carries a UUID in the custom property `sw_id`.
- Local changes are found by diffing a cached snapshot (`S.known`) on a 0.1 s timer,
  only when a depsgraph update marked the scene dirty. One event per changed property.
- Conflicts: last-writer-wins per (object, property group). Stamp = (server-adjusted ms, user id).
  A remote event older than the newest stamp we hold for that property is dropped.
- Remote events are applied inside a time budget per tick; Blender data is only touched here.
"""
import array
import base64
import collections
import getpass
import hashlib
import itertools
import json
import logging
import math
import os
import queue
import random
import re
import socket
import threading
import time
import types
import uuid

import bpy
from mathutils import Matrix, Quaternion, Vector

from . import assets, fontsel, inputs, limits, lobby, meshio, net, props, server, tunnel, update

log = logging.getLogger("SilverWood.sync")
ID = "sw_id"
DATA = {"LIGHT": ("type", "energy", "color", "shadow_soft_size"),
        "CAMERA": ("type", "lens", "clip_start", "clip_end")}
TYPES = {"MESH", "EMPTY", "FONT", "ARMATURE", *DATA}
BIG_VERTS = 200_000  # meshes above this are re-sent at most every (verts / BIG_VERTS) seconds while being edited
BUDGET = 0.025
ERRORS = collections.deque(maxlen=4)
FATAL = []
AV = 64
CUR = 48
BG_RGB = (0.06, 0.06, 0.07)
MY = {"b64": "", "cur": "", "ver": 0}
S = types.SimpleNamespace()


def reset():
    S.worker = None
    S.uid = S.sid = S.host = S.project = S.code = ""
    S.server, S.local = None, False
    S.mesh_ver, S.tunnel = {}, None
    S.glide, S.anim_t = {}, time.perf_counter()
    S.setting_color = False
    S.color = "#FF8800"
    S.ready, S.dirty = False, True
    S.known, S.stamps, S.byid, S.mesh_hash, S.mesh_next = {}, {}, {}, {}, {}
    S.asset_fp, S.asset_sha, S.asset_next = {}, {}, 0.0
    S.geo, S.deferred, S.remote = set(), [], {}
    S.pfps, S.perms, S.people, S.revert_at = {}, {}, [], 0.0
    S.curs = {}
    S.rows_sig, S.pres = None, None
    S.last_sync, S.pres_next = 0.0, 0.0
    S.seq = itertools.count()
    S.mouse, S.mouse_dn, S.ghosts = None, False, []
    S.gh, S.touch, S.touch_all, S.scene_next = {}, set(), False, 0.0
    S.mats = False
    S.cols, S.zones, S.deny_t, S.room = set(), {}, 0.0, ""
    S.pings, S.reset_pending = [], False
    S.my_font = S.my_font_path = ""
    S.chat, S.chat_unread, S.chat_toast = collections.deque(maxlen=100), 0, None
    S.guard_until, S.guard, S.skipped = 0.0, False, 0
    S.com, S.public, S.lobby = False, False, ""  # Free-For-All member; my session is listed publicly; id of my lobby entry


reset()
LAST = ["", ""]  # (kind, code) of the last start(): for Reconnect
RECON = ("join", "online", "community")
LOB = {"rows": [], "t": 0.0, "busy": False, "err": "", "msg": "", "com": 0, "com_ms": 0, "com_t": 0.0}  # lobbies page data


def mat16(m):
    return [round(v, 5) for row in m for v in row]


def to_mat(v):
    return Matrix([v[0:4], v[4:8], v[8:12], v[12:16]])


def ok16(v):
    return (isinstance(v, list) and len(v) == 16
            and all(isinstance(x, (int, float)) and not isinstance(x, bool) and abs(x) < 1e9 for x in v))


def hex2rgb(h):
    if isinstance(h, str) and re.fullmatch(r"#[0-9A-Fa-f]{6}", h):
        return tuple(int(h[i:i + 2], 16) / 255 for i in (1, 3, 5))
    return (0.6, 0.6, 0.6)


def secret():
    """Per-file secret stored in the .blend (scene property). Becomes the auth token + part of the code."""
    sc = bpy.context.scene
    c = sc.get("sw_secret") if sc else None
    return c if isinstance(c, str) and re.fullmatch(r"[0-9a-f]{18}", c) else ""


def new_secret():
    sc = bpy.context.scene
    if sc is not None:
        sc["sw_secret"] = os.urandom(9).hex()


def lan_ip():
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        s.connect(("10.255.255.255", 1))
        return s.getsockname()[0]
    except OSError:
        return "127.0.0.1"
    finally:
        s.close()


def make_code(ip, port, sec):
    """code = base32(ipv4[4] + port[2] + secret[9]) = 24 chars: where the host is + the password."""
    raw = socket.inet_pton(socket.AF_INET, ip) + port.to_bytes(2, "big") + bytes.fromhex(sec)
    return base64.b32encode(raw).decode()


def parse_code(code):
    c = re.sub(r"[^A-Z2-7]", "", code.upper())
    if len(c) != 24:
        raise ValueError("Code is 24 characters (XXXX-XXXX-...)")
    raw = base64.b32decode(c)
    return socket.inet_ntoa(raw[:4]), int.from_bytes(raw[4:6], "big"), raw[6:].hex()


def fmt(c):
    return "-".join(c[i:i + 4] for i in range(0, len(c), 4))


def online_code():
    """Short code for online sessions: 8 chars derived from the file secret."""
    sec = secret()
    return fmt(base64.b32encode(bytes.fromhex(sec)[:5]).decode()) if sec else ""


def make_tunnel_code(url, sec):
    """flag(1) + secret(9) + len(1) + subdomain, zero-padded to >=20 bytes (so it is always >=32 chars)."""
    host = url.split("//", 1)[1]
    for flag, suf in ((1, ".trycloudflare.com"), (2, ".lhr.life")):
        if host.endswith(suf):
            host = host[:-len(suf)]
            break
    else:
        flag = 0
    h = host.encode()
    raw = bytes([flag]) + bytes.fromhex(sec) + bytes([len(h)]) + h
    return base64.b32encode(raw.ljust(20, b"\0")).decode().rstrip("=")


def parse_tunnel_code(c):
    raw = base64.b32decode(c + "=" * (-len(c) % 8))
    flag, sec, n = raw[0], raw[1:10].hex(), raw[10]
    host = raw[11:11 + n].decode()
    return "https://" + host + {1: ".trycloudflare.com", 2: ".lhr.life"}.get(flag, ""), sec


PRES = {"t": 0.0, "on": False, "n": None, "err": "", "cid": "", "track": []}  # presence heartbeat, player count


def fb_call(method, path, data=None, quiet=False):
    """One Firebase REST call in a thread (the main thread never waits for the network)."""
    p = prefs()
    fb = net.Client(p.database_url, p.auth_token)

    def run():
        try:
            fb.call(method, path, data, timeout=8)
        except Exception as e:
            if not quiet:
                log.warning("firebase %s %s failed (check the rules): %s", method, path, e)

    threading.Thread(target=run, daemon=True, name="SilverWood-fb").start()


def track(path):
    """Remember a Firebase path this install created, so a crash cannot leave it behind for ever."""
    if path not in PRES["track"]:
        PRES["track"].append(path)
        prefs().leftovers = json.dumps(PRES["track"])


def cleanup_leftovers():
    """Start of a session: remove what a crashed earlier run left (a session only when nobody is in it any more)."""
    p = prefs()
    try:
        old = [x for x in json.loads(p.leftovers or "[]") if isinstance(x, str) and re.fullmatch(r"(sessions|rooms|roster|lobbies)/[A-Za-z0-9]{4,40}", x)]
    except ValueError:
        old = []
    p.leftovers, PRES["track"] = "[]", []
    if not old:
        return
    fb = net.Client(p.database_url, p.auth_token)

    def run():
        for path in old:
            try:
                if path.startswith("sessions/"):
                    m = fb.call("GET", path + "/members", timeout=8) or {}
                    now = time.time() * 1000
                    if any(isinstance(d, dict) and isinstance(d.get("last_seen"), (int, float)) and now - d["last_seen"] < 120000
                           for d in m.values()):
                        continue
                fb.call("DELETE", path, timeout=8)
            except Exception:
                pass

    threading.Thread(target=run, daemon=True, name="SilverWood-leftovers").start()


def roster_put():
    """The host writes who is in the room to roster/<room>. The rules make it write-only for everyone else, so the
    names are only visible in your Firebase console, never to the public."""
    key = S.room if S.local else S.sid
    if key and S.host == S.uid:
        fb_call("PUT", f"roster/{key}", {"t": int(time.time() * 1000), "host": my_name(),
                                         "players": {q.uid: {"n": q.name, "ms": q.ms} for q in S.people if q.online}}, quiet=True)


def presence_tick():
    """While you are in a session: online/<install id> = time every 45 s (that is the player count); a PC host also
    refreshes its room code and roster. Everything is removed when you leave."""
    now = time.time()
    if S.worker is not None and S.ready and now >= PRES["t"]:
        cid = prefs().client_id
        if not re.fullmatch(r"[0-9a-f]{16}", cid or ""):
            cid = prefs().client_id = os.urandom(8).hex()
        PRES["t"], PRES["on"], PRES["cid"] = now + 45, True, cid
        fb_call("PUT", f"online/{cid}", int(now * 1000), quiet=True)
        if S.room and S.local and S.host == S.uid and S.code:
            fb_call("PUT", f"rooms/{S.room}", {"c": S.code.replace("-", ""), "t": int(now * 1000)}, quiet=True)
        roster_put()
        lobby_tick(cid, now)
    elif S.worker is None and PRES["on"]:
        PRES["t"], PRES["on"] = 0.0, False
        fb_call("DELETE", f"online/{PRES['cid']}", quiet=True)
        fb_call("DELETE", f"community/{lobby.shard(PRES['cid'])}/{PRES['cid']}", quiet=True)


def hosting_public():
    """(kind, code) when this PC hosts a session that may be listed (worldwide or Firebase), else None."""
    if S.worker is not None and S.worker.mode == "create" and S.host == S.uid and LAST[0] in ("tunnel", "online") and S.code:
        return LAST[0], S.code
    return None


def lobby_name():
    n = (prefs().lobby_name or "").strip()
    return n or f"{my_name()}'s lobby"


def lobby_tick(cid, now):
    """Every 45 s: Free-For-All members heartbeat and count the crowd; a host with 'public' on refreshes its lobby entry."""
    p = prefs()
    fb = net.Client(p.database_url, p.auth_token)
    w = S.worker
    if S.com:
        def run():
            try:
                lobby.heartbeat(fb, cid)
                LOB["com"], LOB["com_t"] = lobby.count(fb), time.time()
                w.pace_n = max(1, LOB["com"])
            except Exception as e:
                log.warning("free-for-all count failed (check the Firebase rules): %s", e)

        threading.Thread(target=run, daemon=True, name="SilverWood-com").start()
    h = hosting_public()
    if h and S.public:
        e = lobby.entry(lobby_name(), my_name(), h[1], h[0], sum(1 for q in S.people if q.online) or 1, update.VERSION)
        lid = lobby.lobby_id(h[1])
        if S.lobby and S.lobby != lid:
            fb_call("DELETE", f"lobbies/{S.lobby}", quiet=True)
        S.lobby = lid
        track(f"lobbies/{lid}")
        fb_call("PUT", f"lobbies/{lid}", e)
    elif S.lobby:
        fb_call("DELETE", f"lobbies/{S.lobby}", quiet=True)
        S.lobby = ""


def set_public(on):
    """Switch my hosted session's public listing on or off (takes effect within a second)."""
    if on and not hosting_public():
        return False
    S.public = bool(on)
    PRES["t"] = 0.0
    redraw()
    return True


def resolve_code(code):
    """Worldwide join code -> (base url, token) for pinging a lobby."""
    return parse_tunnel_code(re.sub(r"[^A-Z2-7]", "", code.upper()))


def fetch_lobbies():
    """Refresh the lobbies page in the background: the list, a ping for every lobby and the Free-For-All's size."""
    if LOB["busy"]:
        return
    LOB["busy"], LOB["t"] = True, time.time()
    p = prefs()
    url, tok = p.database_url, p.auth_token
    fb = net.Client(url, tok)

    def run():
        try:
            rows = lobby.fetch_list(fb)
            lobby.ping_all(rows, url, tok, resolve_code)
            com_ms = lobby.ping(url, tok, f"sessions/{lobby.COMMUNITY_SID}/status")
            n = lobby.count(fb)
            LOB.update(rows=rows, err="", com=n if not S.com else max(n, LOB["com"]), com_ms=com_ms, com_t=time.time())
        except Exception as e:
            LOB["err"] = (f"HTTP {e.code}: check the Firebase rules (README)" if getattr(e, "code", 0) in (401, 403) else str(e))[:90] or "error"
        LOB["busy"] = False
        redraw()

    threading.Thread(target=run, daemon=True, name="SilverWood-lobbies").start()


def fetch_online():
    """Player count = online/<uid> entries written in the last 2 min. Entries older than 10 min are cleaned up here."""
    p = prefs()
    fb = net.Client(p.database_url, p.auth_token)

    def run():
        try:
            d = fb.call("GET", "online", timeout=8) or {}
            now, num = time.time() * 1000, (int, float)
            PRES["n"], PRES["err"] = sum(1 for v in d.values() if isinstance(v, num) and now - v < 120000), ""
            stale = {k: None for k, v in d.items() if not isinstance(v, num) or now - v > 600000}
            if stale:
                fb.call("PATCH", "online", stale, timeout=8)
        except Exception as e:
            PRES["n"], PRES["err"] = None, str(e)[:60] or "error"

    threading.Thread(target=run, daemon=True, name="SilverWood-online").start()


def ensure_font():
    """Load my chosen name font (a preference) as a fake-user font datablock so the asset sync sends it to everyone."""
    path = prefs().font_path
    S.my_font = S.my_font_path = ""
    if path and os.path.isfile(path) and path.lower().endswith((".ttf", ".otf")) and os.path.getsize(path) <= fontsel.MAX_BYTES:
        name = "SW " + os.path.splitext(os.path.basename(path))[0][:55]
        try:
            vf = bpy.data.fonts.get(name) or bpy.data.fonts.load(path)
        except RuntimeError:
            log.warning("font %s cannot be read by Blender, using the default font", path)
            prefs().font_path = ""
            vf = None
        if vf is not None:
            vf.name = name
            vf.use_fake_user = True
            S.my_font, S.my_font_path = vf.name, path
    if S.worker is not None:
        S.worker.font = S.my_font
        S.worker.presence_v += 1


def drop_font():
    vf = bpy.data.fonts.get(S.my_font) if S.my_font else None
    if vf is not None:
        vf.use_fake_user = False
        if vf.users == 0:
            bpy.data.fonts.remove(vf)
    S.my_font = S.my_font_path = ""


def set_font(path):
    """Use this font file for my name ("" = default). Takes effect for everyone in the session."""
    prefs().font_path = path or ""
    if S.worker is not None:
        drop_font()
        ensure_font()
    redraw()


def room_publish(code):
    """Give a LAN/worldwide host a 6-char code joiners can type instead of the long one. A new code (New Code,
    restart) removes the old room and its roster first, so the database never lists a room twice."""
    rid = base64.b32encode(bytes.fromhex(secret())[5:9]).decode()[:6]
    if S.room and S.room != rid:
        fb_call("DELETE", f"rooms/{S.room}", quiet=True)
        fb_call("DELETE", f"roster/{S.room}", quiet=True)
    S.room = rid
    track(f"rooms/{rid}")
    track(f"roster/{rid}")
    fb_call("PUT", f"rooms/{rid}", {"c": code.replace("-", ""), "t": int(time.time() * 1000)})
    PRES["t"] = 0.0  # roster right away


def add_ping(ev):
    p = ev.get("p")
    if not (isinstance(p, list) and len(p) == 3 and all(type(x) in (int, float) for x in p)):
        return
    if S.worker.now_ms() - ev["ts"] > 4000:  # replayed old event
        return
    r = next((r for r in S.remote.values() if r.uid == ev["u"]), None)
    col = hex2rgb(S.color) if ev["u"] == S.uid else (r.color if r else (0.6, 0.6, 0.6))
    S.pings = (S.pings + [{"p": tuple(p), "t0": time.time(), "c": col}])[-20:]
    redraw()


def send_ping():
    """Ping the 3D cursor position: everyone sees a pulsing ring there for 4 s."""
    w = S.worker
    if w is None or not S.ready or w.role == "view":
        return False
    p = [round(x, 4) for x in bpy.context.scene.cursor.location]
    W = {}
    emit(W, "ping", uuid.uuid4().hex, {"p": p}, {}, "")
    w.outbox.put(W)
    add_ping({"u": S.uid, "p": p, "ts": w.now_ms()})
    return True


def host_code():
    """LAN/VPN code (address + port + secret) for hosting on this PC."""
    sec = secret()
    if not sec:
        return ""
    prefs = bpy.context.preferences.addons[__package__].preferences
    try:
        return fmt(make_code(prefs.address.strip() or lan_ip(), prefs.port, sec))
    except (OSError, ValueError):
        return ""


def prefs():
    return bpy.context.preferences.addons[__package__].preferences


def my_name():
    """Your SilverWood name: the preference, else the PC login name. Never writes anything to the OS."""
    try:
        n = prefs().username.strip()
    except Exception:
        n = ""
    if n:
        return n[:32]
    try:
        return getpass.getuser()[:32]
    except Exception:
        return "Artist"


def set_my_name(name):
    """Change only the SilverWood name (blank = PC login name). Live: updates the running session too."""
    prefs().username = name.strip()[:32]
    w = S.worker
    if w is not None:
        w.user = my_name()
        w.presence_v += 1
    redraw()


def make_pfp(path):
    """Image file -> base64 of 64x64 opaque RGBA bytes (center crop, composited over the UI background)."""
    import numpy as np
    img = bpy.data.images.load(path, check_existing=False)
    try:
        w, h = img.size
        if w < 1 or h < 1:
            raise ValueError("empty image")
        k = AV / min(w, h)
        nw, nh = max(AV, round(w * k)), max(AV, round(h * k))
        img.scale(nw, nh)
        px = np.empty(nw * nh * 4, dtype=np.float32)
        img.pixels.foreach_get(px)
    finally:
        bpy.data.images.remove(img)
    x0, y0 = (nw - AV) // 2, (nh - AV) // 2
    px = np.clip(px.reshape(nh, nw, 4)[y0:y0 + AV, x0:x0 + AV], 0.0, 1.0)
    a = px[..., 3:4]
    rgb = px[..., :3] * a + np.array(BG_RGB, np.float32) * (1.0 - a)
    out = np.concatenate([rgb, np.ones_like(a)], axis=2)
    return base64.b64encode((out * 255 + 0.5).astype(np.uint8).tobytes()).decode()


def make_cursor(path):
    """Image file -> base64 of 48x48 premultiplied RGBA bytes (fitted, transparency kept)."""
    import numpy as np
    img = bpy.data.images.load(path, check_existing=False)
    try:
        img.alpha_mode = 'STRAIGHT'
        w, h = img.size
        if w < 1 or h < 1:
            raise ValueError("empty image")
        k = CUR / max(w, h)
        nw, nh = max(1, round(w * k)), max(1, round(h * k))
        img.scale(nw, nh)
        px = np.empty(nw * nh * 4, dtype=np.float32)
        img.pixels.foreach_get(px)
    finally:
        bpy.data.images.remove(img)
    out = np.zeros((CUR, CUR, 4), np.float32)
    y0, x0 = (CUR - nh) // 2, (CUR - nw) // 2
    out[y0:y0 + nh, x0:x0 + nw] = np.clip(px.reshape(nh, nw, 4), 0.0, 1.0)
    out[..., :3] *= out[..., 3:4]
    return base64.b64encode((out * 255 + 0.5).astype(np.uint8).tobytes()).decode()


def push_blob():
    p = prefs()
    cur = MY["cur"] if p.use_custom_cursor else ""
    MY["ver"] += 1
    w = S.worker
    if w is not None:
        w.pfp_b64, w.pfp_ver = (MY["b64"] + "," + cur if cur else MY["b64"]), MY["ver"]
        w.presence_v += 1
    redraw()


def set_my_cursor(path):
    """Set (or with "" clear) your custom cursor image. Raises if the file cannot be read."""
    MY["cur"] = make_cursor(path) if path else ""
    prefs().cursor_path = path or ""
    push_blob()


def set_my_pfp(path):
    """Set (or with "" clear) your picture. Raises if the file cannot be read."""
    b64 = make_pfp(path) if path else ""
    prefs().pfp_path = path or ""
    MY["b64"] = b64
    push_blob()


def init_profile():
    """Load the picture saved in the preferences (once per Blender run)."""
    p = prefs().pfp_path
    if p and not MY["b64"]:
        try:
            MY["b64"], MY["ver"] = make_pfp(p), MY["ver"] + 1
        except Exception as e:
            log.warning("profile picture not loaded: %s", e)
    p = prefs().cursor_path
    if p and not MY["cur"]:
        try:
            MY["cur"], MY["ver"] = make_cursor(p), MY["ver"] + 1
        except Exception as e:
            log.warning("custom cursor not loaded: %s", e)


def ctl():
    """Moderation controls. Only exists on the PC that hosts (Worldwide / LAN); None for Firebase and joiners."""
    return getattr(S.server, "ctl", None)


def role_of(uid):
    if uid == S.host:
        return "edit"
    p = S.perms
    return "view" if (p.get(uid) or p.get("_default") or "edit") == "view" else "edit"


def host_do(action, uid=None, arg=None):
    """Host actions: kick / role / default / lock / unban. Returns False when this PC is not a hosting server."""
    c = ctl()
    if c is None:
        return False
    if action == "kick":
        c.kick(uid)
    elif action == "role":
        c.set_role(uid, arg)
    elif action == "default":
        c.set_default(arg)
    elif action == "lock":
        c.lock_joins(arg)
    elif action == "unban":
        c.clear_kicks()
    elif action == "snap":
        c.snapshot("manual")
    elif action == "restore":
        if c.rollback(int(uid)):  # host's own Blender follows the same path as everyone else
            S.reset_pending = True
            S.worker.resync = True
    elif action == "zmode":
        c.zone(uid, mode="only" if (S.zones.get(uid) or {}).get("m") == "not" else "not")
    elif action == "zcol":
        c.zone(uid, cid=col_id(bpy.context.view_layer.active_layer_collection.collection))
    S.perms, S.zones = c.roles(), c.cperms()
    redraw()
    return True


def chat_add(name, col, text, mine=False, system=False):
    S.chat.append({"n": name, "c": col, "t": text, "ts": time.time(), "me": mine, "sys": system})
    if not mine:
        S.chat_toast = (name, col, text, time.time() + 7)
        S.chat_unread += 1
    redraw()


def send_chat(text):
    w = S.worker
    text = text.strip()[:300]
    if not text or w is None:
        return
    w.chat_out.put(text)
    chat_add(my_name(), hex2rgb(S.color), text, mine=True)


def conn_info():
    """(text, rgb, can_reconnect) for the status line in the menu and sidebar."""
    w = S.worker
    if w is None:
        return ("Disconnected: " + FATAL[-1][:60] if FATAL else "Not in a session"), ((0.9, 0.3, 0.3) if FATAL else (0.6, 0.6, 0.65)), bool(FATAL and LAST[0] in RECON)
    online = max(sum(1 for q in S.people if q.online), LOB["com"] if S.com else 0)
    if w.status == "connected":
        age = time.time() - S.last_sync if S.last_sync else 0
        t = "Connected" + (f"  {w.latency} ms" if w.latency else "") + f"  {online} online" + (f"  last sync {int(age)}s ago" if age > 15 else "")
        return t, (0.3, 0.85, 0.4), False
    if w.status == "connecting":
        return f"Reconnecting... (try {w.fails})", (1.0, 0.6, 0.2), False
    return "Connection lost: " + (w.err or "unknown")[:50], (0.9, 0.3, 0.3), LAST[0] in RECON


def reconnect():
    kind, code = LAST
    if kind in RECON:
        try:
            start(kind, code)
        except Exception as e:
            ERRORS.append(f"Reconnect failed: {e}")


def blocked(i, kinds):
    """During an undo/redo: True if one of these properties was last written by someone else.
    Blender's undo restores the whole file, so without this it would send teammates' work back to its old state."""
    if S.guard:
        for kind in kinds:
            st = S.stamps.get((i, kind))
            if st and st[1] != S.uid:
                S.skipped += 1
                return True
    return False


def redraw():
    for w in bpy.context.window_manager.windows:
        for a in w.screen.areas:
            if a.type == "VIEW_3D":
                a.tag_redraw()


def my_ws():
    ws = bpy.context.window_manager.windows
    return ws[0].workspace.name if ws else ""


def redraw_cursors():
    if S.ghosts or any(r.pos for r in S.remote.values()):
        for w in bpy.context.window_manager.windows:
            for a in w.screen.areas:
                a.tag_redraw()


def ui_state():
    ws, m = my_ws(), S.mouse
    return [ws, *m[1:6]] if m and m[0] == ws and time.time() - m[6] < 15 else [ws]


def status():
    if S.worker:
        return S.worker.status
    return "error" if FATAL else "disconnected"


def find(i):
    n = S.byid.get(i)
    o = bpy.data.objects.get(n) if n else None
    if o is None or o.get(ID) != i:
        o = next((x for x in bpy.data.objects if x.get(ID) == i), None)
        if o:
            S.byid[i] = o.name
    return o


props.R["find"] = find


def baseline(o, i):
    for g, spec in props.GROUPS.items():
        if spec[2](o) and not (g == "arm" and o.mode == "EDIT"):
            try:
                S.gh[(i, g)] = hash_of(spec[0](o))
            except Exception:
                log.debug("baseline failed: %s", g, exc_info=True)


def apply_group(o, i, g, v, ev):
    spec = props.GROUPS.get(g)
    if spec is None or not spec[2](o) or stale(i, "g:" + g, ev):
        return
    try:
        spec[1](o, v)
    except props.Defer:
        return defer({"id": i, "k": "props", "ts": ev["ts"], "u": ev["u"], "g": g, "v": v})
    stamp(i, "g:" + g, ev)
    try:
        S.gh[(i, g)] = hash_of(spec[0](o))
    except Exception:
        log.debug("hash failed: %s", g, exc_info=True)


ROOT = "r"  # id of the scene's master collection


def col_of(i):
    sc = bpy.context.scene.collection
    return sc if i == ROOT else next((c for c in bpy.data.collections if c.get(ID) == i), None)


def col_id(c):
    if c == bpy.context.scene.collection:
        return ROOT
    if not isinstance(c.get(ID), str):
        c[ID] = uuid.uuid4().hex
    return c[ID]


def cols_dump():
    """{collection id: [name, parent id]} for the scene's collection tree. Re-ids copied (Shift-D) collections."""
    sc, seen, out = bpy.context.scene.collection, set(), {}
    for p in (sc, *sc.children_recursive):
        for c in p.children:
            if not isinstance(c.get(ID), str) or c[ID] in seen:
                c[ID] = uuid.uuid4().hex
            seen.add(c[ID])
            out[c[ID]] = [c.name, col_id(p)]
    return out


def ensure_col(i):
    c = col_of(i)
    if c is None:  # object arrived before the collection list: placeholder, renamed/moved when the list lands
        c = bpy.data.collections.new("Collection")
        c[ID] = i
        bpy.context.scene.collection.children.link(c)
    return c


def apply_cols(v):
    sc = bpy.context.scene.collection
    v = {i: d for i, d in v.items() if net.ID_RE.fullmatch(i) and isinstance(d, list) and len(d) == 2}
    for i in v:
        ensure_col(i)
    for i, (name, par) in v.items():
        c, p = ensure_col(i), col_of(par) or sc
        if isinstance(name, str) and name and c.name != name[:63]:
            c.name = name[:63]
        cur = [q for q in (sc, *sc.children_recursive) if c.name in q.children]
        if cur != [p] and p is not c and p not in c.children_recursive:
            for q in cur:
                q.children.unlink(c)
            p.children.link(c)
    # ponytail: whole list is last-writer-wins; only collections we knew about are removed, so a new local one survives
    for i in S.cols - set(v):
        c = col_of(i)
        if c is not None and c is not sc:
            bpy.data.collections.remove(c)
    S.cols = set(v)


def apply_scene(ev):
    gd = ev.get("g") if ev["k"] == "create" else {ev.get("g"): ev.get("v")}
    if not isinstance(gd, dict):
        return
    if "scene" in gd and not stale(props.SCENE_ID, "g:scene", ev):
        stamp(props.SCENE_ID, "g:scene", ev)
        props.a_scene(bpy.context.scene, gd["scene"])
        S.gh[("", "scene")] = hash_of(props.g_scene(bpy.context.scene))
    fr = gd.get("frame")
    if type(fr) is int and not stale(props.SCENE_ID, "g:frame", ev):
        stamp(props.SCENE_ID, "g:frame", ev)
        sc = bpy.context.scene
        if sc.frame_current != fr:
            sc.frame_set(fr)
            for o in sc.objects:  # animated objects moved by the frame, not by a user: don't echo them
                i = o.get(ID)
                if o.animation_data and isinstance(i, str) and i in S.known:
                    S.known[i] = snap(o)
        S.gh[("", "frame")] = fr
    cl = gd.get("cols")
    if isinstance(cl, dict) and not stale(props.SCENE_ID, "g:cols", ev):
        stamp(props.SCENE_ID, "g:cols", ev)
        apply_cols(cl)
        S.gh[("", "cols")] = hash_of({"c": cols_dump()})
    ng = gd.get("ngs")
    if isinstance(ng, list) and not stale(props.SCENE_ID, "g:ngs", ev):
        stamp(props.SCENE_ID, "g:ngs", ev)
        props.ngs_apply(ng)
        S.gh[("", "ngs")] = hash_of({"n": props.ngs_dump()})


def scene_diff():
    W = {}
    v = props.g_scene(bpy.context.scene)
    h = hash_of(v)
    if h != S.gh.get(("", "scene")):
        S.gh[("", "scene")] = h
        emit(W, "props", props.SCENE_ID, {"g": "scene", "v": v}, {"/g/scene": v}, ["g:scene"])
    cd = cols_dump()
    h = hash_of({"c": cd})
    if h != S.gh.get(("", "cols")):
        S.gh[("", "cols")] = h
        S.cols = set(cd)
        emit(W, "props", props.SCENE_ID, {"g": "cols", "v": cd}, {"/g/cols": cd}, ["g:cols"])
    ng = props.ngs_dump() if bpy.data.node_groups else []
    h, old = hash_of({"n": ng}), S.gh.get(("", "ngs"))
    if h != old:
        S.gh[("", "ngs")] = h
        if ng or old is not None:
            emit(W, "props", props.SCENE_ID, {"g": "ngs", "v": ng}, {"/g/ngs": ng}, ["g:ngs"])
    c = bpy.context
    fr = c.scene.frame_current
    # ponytail: no sync while playing (each user keeps own playhead), 1 s lag from scene_diff cadence
    if fr != S.gh.get(("", "frame")) and S.worker.role != "view" and not (c.screen and c.screen.is_animation_playing):
        S.gh[("", "frame")] = fr
        emit(W, "props", props.SCENE_ID, {"g": "frame", "v": fr}, {"/g/frame": fr}, ["g:frame"])
    return W


def props_diff(W, cur, created, geo=()):
    c = bpy.context
    playing = bool(c.screen and c.screen.is_animation_playing)
    allg, touch, mats = S.touch_all, S.touch, S.mats
    props.MAT_CACHE.clear()
    S.touch, S.touch_all, S.mats = set(), False, False
    for i, o in cur.items():
        new = i in created
        touched = new or allg or o.name in touch
        if not (touched or mats):
            continue
        geo_hit = o.name in geo
        for g, (dump_fn, _, ok, cheap) in props.GROUPS.items():
            if not ok(o) or (playing and g in ("pose", "anim", "ada", "ska")) or (g == "arm" and o.mode == "EDIT"):
                continue
            if o.type == "MESH" and o.mode == "EDIT" and g in ("vg", "sk"):
                continue
            if touched:
                if not props.due(cheap, new, allg, geo_hit, mats):
                    continue
            elif not (mats and cheap == "mat"):
                continue
            try:
                v = dump_fn(o)
            except Exception:
                log.debug("dump failed: %s", g, exc_info=True)
                continue
            h = hash_of(v)
            if h != S.gh.get((i, g)):
                S.gh[(i, g)] = h
                emit(W, "props", i, {"g": g, "v": v}, {"/g/" + g: v}, ["g:" + g])


def pid(o):
    p = o.parent
    return p.get(ID) if p is not None and isinstance(p.get(ID), str) else None


def get_data(o):
    if o.type not in DATA:
        return None
    out = {}
    for k in DATA[o.type]:
        v = getattr(o.data, k)
        out[k] = [round(x, 4) for x in v] if hasattr(v, "__len__") and not isinstance(v, str) else round(v, 4) if isinstance(v, float) else v
    return out


def set_data(o, d):
    for k in DATA[o.type]:
        v = d.get(k)
        try:
            if isinstance(v, list) and all(isinstance(x, (int, float)) for x in v):
                setattr(o.data, k, v)
            elif isinstance(v, (str, int, float)) and not isinstance(v, bool):
                setattr(o.data, k, v)
        except (TypeError, ValueError):
            pass


def snap(o):
    p = pid(o)
    return {"name": o.name, "d": get_data(o), "m": mat16(o.matrix_basis), "hide": bool(o.hide_viewport),
            "par": p, "mpi": mat16(o.matrix_parent_inverse) if p else None,
            "col": sorted(col_id(c) for c in o.users_collection)}


def hash_of(d):
    return hashlib.md5(json.dumps(d).encode()).hexdigest() if d else None


def scan(scene):
    """Map id -> object for syncable objects; assigns ids, re-ids duplicated ones (Shift-D)."""
    groups = {}
    for o in scene.objects:
        if o.type in TYPES:
            i = o.get(ID)
            groups.setdefault(i if isinstance(i, str) else None, []).append(o)
    cur = {}
    for i, objs in groups.items():
        keep = next((o for o in objs if o.name == S.byid.get(i)), objs[0]) if i else None
        for o in objs:
            if o is keep:
                cur[i] = o
            else:
                nid = uuid.uuid4().hex
                o[ID] = nid
                cur[nid] = o
    S.byid = {i: o.name for i, o in cur.items()}
    return cur


def emit(W, k, i, fields, state, kinds):
    if k != "create" and blocked(i, kinds):
        return
    ts = S.worker.now_ms()
    key = f"{ts:013d}-{S.uid[:4]}{next(S.seq) % 100000:05d}"
    net.merge(W, f"events/{key}", {"id": i, "k": k, "ts": ts, "u": S.uid, **fields})
    for sub, val in state.items():
        net.merge(W, f"objects/{i}{sub}", val)
    for kind in kinds:
        S.stamps[(i, kind)] = (ts, S.uid)
    if k == "transform":
        S.glide.pop(i, None)


MESH_PART = 500_000


def capture_mesh(me):
    cap = meshio.capture(me)
    if cap is None:
        ERRORS.append(f"Mesh '{me.name}' is too large to sync ({len(me.vertices):,} vertices)")
    return cap


def put_mesh(W, i, cap):
    """Store a mesh as meshes/<id>/<version>/<n> string chunks. Returns (version, count)."""
    txt = meshio.pack(cap)
    ver = str(S.worker.now_ms())
    parts = [txt[k:k + MESH_PART] for k in range(0, len(txt), MESH_PART)]
    for n, p in enumerate(parts):
        net.merge(W, f"meshes/{i}/{ver}/{n}", p)
    old = S.mesh_ver.get(i)
    if old and old != ver:
        net.merge(W, f"meshes/{i}/{old}", None)
    S.mesh_ver[i] = ver
    return ver, len(parts)


def emit_create(W, i, o, s):
    st = {"type": o.type, **s}
    if o.type == "MESH":
        cap = capture_mesh(o.data)
        if cap:
            st["mv"], st["mn"] = put_mesh(W, i, cap)
            S.mesh_hash[i] = cap.digest()
    emit(W, "create", i, st, {"": st}, "xnthpmdc")


def local_diff(scene):
    W = {}
    cur = scan(scene)
    geo, S.geo = S.geo, set()
    created = set()
    playing = bool(bpy.context.screen and bpy.context.screen.is_animation_playing)
    for i, o in cur.items():
        s, old = snap(o), S.known.get(i)
        if old is None:
            emit_create(W, i, o, s)
            created.add(i)
        else:
            if playing:
                s["m"] = old["m"]
            if s["name"] != old["name"]:
                emit(W, "rename", i, {"name": s["name"]}, {"/name": s["name"]}, "n")
            if s["m"] != old["m"]:
                emit(W, "transform", i, {"m": s["m"]}, {"/m": s["m"]}, "t")
            if s["d"] != old["d"]:
                emit(W, "data", i, {"d": s["d"]}, {"/d": s["d"]}, "d")
            if s["hide"] != old["hide"]:
                emit(W, "visibility", i, {"hide": s["hide"]}, {"/hide": s["hide"]}, "h")
            if s["col"] != old["col"]:
                emit(W, "col", i, {"col": s["col"]}, {"/col": s["col"]}, "c")
            if (s["par"], s["mpi"]) != (old["par"], old["mpi"]):
                emit(W, "parent", i, {"par": s["par"], "mpi": s["mpi"]}, {"/par": s["par"], "/mpi": s["mpi"]}, "p")
            if o.type == "MESH" and o.name in geo and o.mode != "EDIT":
                nv, now = len(o.data.vertices), time.time()
                if nv > BIG_VERTS and now < S.mesh_next.get(i, 0):
                    S.geo.add(o.name)  # big mesh changed again too soon: try on a later pass
                    S.known[i] = s
                    continue
                cap = capture_mesh(o.data)
                h = cap.digest() if cap else None
                if h and h != S.mesh_hash.get(i) and not blocked(i, "m"):
                    S.mesh_hash[i] = h
                    mv, mn = put_mesh(W, i, cap)
                    S.mesh_next[i] = now + nv / BIG_VERTS
                    emit(W, "mesh", i, {"mv": mv, "mn": mn}, {"/mv": mv, "/mn": mn}, "m")
        S.known[i] = s
    for i in [i for i in S.known if i not in cur]:
        if blocked(i, "x"):  # undo removed a teammate's object: it comes back with the resync
            S.known.pop(i)
            continue
        emit(W, "delete", i, {}, {"": None}, "x")
        net.merge(W, f"meshes/{i}", None)
        S.mesh_ver.pop(i, None)
        S.known.pop(i)
        S.mesh_hash.pop(i, None)
        S.mesh_next.pop(i, None)
        for g in props.GROUPS:
            S.gh.pop((i, g), None)
    props_diff(W, cur, created, geo)
    return W


def stale(i, kind, ev):
    return (ev["ts"], ev["u"]) <= S.stamps.get((i, kind), (0, ""))


def stamp(i, kind, ev):
    S.stamps[(i, kind)] = (ev["ts"], ev["u"])


def defer(ev):
    ev.setdefault("_t", time.time())
    if len(S.deferred) < 500:
        S.deferred.append(ev)


def set_parent(o, par, mpi):
    p = find(par) if par else None
    if par and p is None:
        return False
    q = p
    while q is not None:
        if q.name == o.name:
            return True
        q = q.parent
    o.parent = p
    if p is not None and ok16(mpi):
        o.matrix_parent_inverse = to_mat(mpi)
    return True


def fields(o, ev, ks):
    """Apply property groups in `ks` (n,t,h,p,m) from ev. Returns True if anything changed."""
    i, hit = ev["id"], False
    go = lambda kind: kind in ks and not stale(i, kind, ev)
    nm = ev.get("name")
    if go("n") and isinstance(nm, str) and nm:
        stamp(i, "n", ev)
        o.name = nm[:63]
        hit = True
    if go("t") and ok16(ev.get("m")):
        stamp(i, "t", ev)
        if ev["k"] == "transform" and o.mode == "OBJECT":
            S.glide[i] = to_mat(ev["m"]).decompose()
        else:
            o.matrix_basis = to_mat(ev["m"])
        hit = True
    if go("h") and isinstance(ev.get("hide"), bool):
        stamp(i, "h", ev)
        o.hide_viewport = ev["hide"]
        hit = True
    cl = ev.get("col")
    if go("c") and isinstance(cl, list) and cl:
        stamp(i, "c", ev)
        want = [ensure_col(x) for x in cl if x == ROOT or (isinstance(x, str) and net.ID_RE.fullmatch(x))]
        for c in want:
            if o.name not in c.objects:
                c.objects.link(o)
        for c in list(o.users_collection):
            if c not in want:
                c.objects.unlink(o)
        hit = True
    par = ev.get("par")
    if go("p") and (par is None or (isinstance(par, str) and net.ID_RE.fullmatch(par))):
        if set_parent(o, par, ev.get("mpi")):
            stamp(i, "p", ev)
            hit = True
        else:
            defer({"id": i, "k": "parent", "ts": ev["ts"], "u": ev["u"], "par": par, "mpi": ev.get("mpi")})
    if go("d") and o.type in DATA and isinstance(ev.get("d"), dict):
        stamp(i, "d", ev)
        set_data(o, ev["d"])
        hit = True
    if go("m") and o.type == "MESH" and isinstance(ev.get("mesh"), meshio.Cap):
        if o.mode == "EDIT":
            defer({"id": i, "k": "mesh", "ts": ev["ts"], "u": ev["u"], "mesh": ev["mesh"]})
        else:
            stamp(i, "m", ev)
            if isinstance(ev.get("mv"), str):
                S.mesh_ver[i] = ev["mv"]
            meshio.build(o.data, ev["mesh"])
            S.mesh_hash[i] = meshio.capture(o.data).digest()
            for g in ("vg", "sk"):
                try:
                    S.gh[(i, g)] = hash_of(props.GROUPS[g][0](o))
                except Exception:
                    log.debug("rebaseline failed: %s", g, exc_info=True)
            hit = True
    return hit


def upsert(ev):
    i, o = ev["id"], find(ev["id"])
    if o is None:
        typ = ev.get("type")
        if typ not in TYPES:
            return
        name = ev["name"][:63] if isinstance(ev.get("name"), str) and ev["name"] else typ.title()
        d = ev.get("d") if isinstance(ev.get("d"), dict) else {}
        if typ == "MESH":
            o = bpy.data.objects.new(name, bpy.data.meshes.new(name))
        elif typ == "LIGHT":
            lt = d.get("type") if d.get("type") in {"POINT", "SUN", "SPOT", "AREA"} else "POINT"
            o = bpy.data.objects.new(name, bpy.data.lights.new(name, lt))
        elif typ == "CAMERA":
            o = bpy.data.objects.new(name, bpy.data.cameras.new(name))
        elif typ == "FONT":
            o = bpy.data.objects.new(name, bpy.data.curves.new(name, "FONT"))
        elif typ == "ARMATURE":
            o = bpy.data.objects.new(name, bpy.data.armatures.new(name))
        else:
            o = bpy.data.objects.new(name, None)
        o[ID] = i
        bpy.context.scene.collection.objects.link(o)
        S.byid[i] = o.name
    fields(o, ev, "nthpmdc")
    gd = ev.get("g") if isinstance(ev.get("g"), dict) else {}
    for g in props.GROUPS:
        if g in gd:
            apply_group(o, i, g, gd[g], ev)
    baseline(o, i)
    S.known[i] = snap(o)


def apply_asset(ev):
    if isinstance(ev.get("data"), (bytes, bytearray)):
        assets.apply(S, ev, bytes(ev["data"]))


def push_assets(w):
    """Upload textures/fonts that are new or changed (checked every 1.5 s)."""
    for kind, name, b, meta, ext in assets.scan(S):
        sha = hashlib.sha1(b).hexdigest()
        if S.asset_sha.get((kind, name)) == sha:
            continue
        a, parts, W = assets.aid(kind, name), assets.chunks(b), {}
        for n, p in enumerate(parts):
            net.merge(W, f"assets/{a}/{sha}/{n}", p)
        old = S.asset_sha.get((kind, name))
        if old:
            net.merge(W, f"assets/{a}/{old}", None)
        info = {"ak": kind, "name": name[:63], "sha": sha, "n": len(parts), "ext": ext, **meta}
        net.merge(W, f"asset_meta/{a}", info)
        ts = w.now_ms()
        net.merge(W, f"events/{ts:013d}-{S.uid[:4]}{next(S.seq) % 100000:05d}", {"id": a, "k": "asset", "ts": ts, "u": S.uid, **info})
        S.asset_sha[(kind, name)] = sha
        w.have_assets[a] = sha
        w.outbox.put(W)


def apply(ev):
    k, i = ev["k"], ev["id"]
    if k == "asset":
        return apply_asset(ev)
    if k == "ping":
        return add_ping(ev)
    if k == "reset":  # host rolled the session back: refetch everything and drop what is not in it
        S.reset_pending = True
        S.worker.resync = True
        return
    if i == props.SCENE_ID:
        if k in ("create", "props"):
            apply_scene(ev)
        return
    if k == "create":
        if not stale(i, "x", ev):
            stamp(i, "x", ev)
            upsert(ev)
        return
    o = find(i)
    if k == "delete":
        if stale(i, "x", ev):
            return
        if o is not None and o.mode != "OBJECT":
            return defer(ev)
        stamp(i, "x", ev)
        if o is not None:
            bpy.data.objects.remove(o, do_unlink=True)
        for d in (S.known, S.byid, S.mesh_hash, S.mesh_next):
            d.pop(i, None)
        for g in props.GROUPS:
            S.gh.pop((i, g), None)
        for c in list(S.known):
            co = find(c)
            if co is not None:
                S.known[c] = snap(co)
        return
    if k == "props":
        if o is not None:
            apply_group(o, i, ev.get("g"), ev.get("v"), ev)
            S.known[i] = snap(o)
        return
    ks = {"transform": "t", "rename": "n", "visibility": "h", "parent": "p", "mesh": "m", "data": "d", "col": "c"}.get(k)
    if o is not None and ks and fields(o, ev, ks):
        S.known[i] = snap(o)


def safe_apply(ev):
    try:
        apply(ev)
    except Exception as e:
        log.exception("apply failed: %s", ev.get("k"))
        ERRORS.append(f"Apply {ev.get('k')} failed: {e}")


def on_snapshot(ts, objs, found=()):
    if S.reset_pending:
        S.reset_pending = False
        for i in [i for i in S.known if i not in objs]:
            o = find(i)
            if o is not None:
                bpy.data.objects.remove(o, do_unlink=True)
            S.known.pop(i, None)
    for ev in found:
        safe_apply(ev)
    for i in sorted(objs, key=lambda i: (i != props.SCENE_ID, i)):  # scene first: collections and node groups exist before objects
        st = objs[i]
        if net.ID_RE.fullmatch(i) and isinstance(st, dict):
            safe_apply({**st, "id": i, "k": "create", "ts": ts, "u": "~"})
    try:
        S.gh[("", "scene")] = hash_of(props.g_scene(bpy.context.scene))
        S.gh[("", "frame")] = bpy.context.scene.frame_current
        cd = cols_dump()
        S.gh[("", "cols")], S.cols = hash_of({"c": cd}), set(cd)
        S.gh[("", "ngs")] = hash_of({"n": props.ngs_dump() if bpy.data.node_groups else []})
    except Exception:
        log.exception("scene baseline failed")
    S.ready, S.dirty = True, True
    S.last_sync = time.time()


def on_members(m, now):
    rows, remote, people = [], {}, []
    for uid, d in m.items():
        if not isinstance(d, dict):
            continue
        ls = d.get("last_seen")
        if uid != S.uid and isinstance(ls, (int, float)) and now - ls > 120000:
            continue  # ghost of someone who left without cleaning up; the workers delete it after 5 min
        online = isinstance(ls, (int, float)) and now - ls < net.STALE_MS and d.get("status") == "online"
        name, col = str(d.get("username", "?"))[:32], hex2rgb(d.get("color"))
        act = str(d.get("activity", ""))[:48]
        ms = S.worker.latency if uid == S.uid else d.get("ms")
        ms = ms if isinstance(ms, int) and not isinstance(ms, bool) and 0 < ms < 10000 else 0
        fn = d.get("fn") if isinstance(d.get("fn"), str) else ""
        rows.append((uid != S.host, name, uid, col, online, act, uid == S.uid, ms))
        people.append(types.SimpleNamespace(uid=uid, name=name, color=col, online=online, host=uid == S.host, me=uid == S.uid,
                                            ms=ms, font=fn[:63]))
        if uid != S.uid:
            sel, cur = d.get("sel"), d.get("cur")
            sel = [s for s in sel if isinstance(s, str)][:100] if isinstance(sel, list) else []
            cur = tuple(cur) if isinstance(cur, list) and len(cur) == 3 and all(
                isinstance(c, (int, float)) for c in cur) else None
            cam = d.get("cam")
            if isinstance(cam, list) and len(cam) == 7 and all(isinstance(c, (int, float)) and abs(c) < 1e7 for c in cam):
                q = Quaternion(cam[3:])
                cam = (Vector(cam[:3]), q.normalized() if q.magnitude > 1e-6 else Quaternion())
            else:
                cam = None
            inputs.on_remote(uid, name, col, d.get("inp"), time.time())
            prev = S.remote.get(uid)
            ui, ws, pos = d.get("ui"), None, None
            if isinstance(ui, list) and ui and isinstance(ui[0], str):
                ws = ui[0][:64]
                if len(ui) == 6 and isinstance(ui[1], int) and isinstance(ui[2], str) and all(
                        isinstance(c, (int, float)) and not isinstance(c, bool) for c in ui[3:5]):
                    pos = types.SimpleNamespace(ai=ui[1], at=ui[2][:32], fx=min(1.0, max(0.0, float(ui[3]))),
                                                fy=min(1.0, max(0.0, float(ui[4]))), dn=bool(ui[5]))
            if prev and prev.ws and ws and ws != prev.ws and prev.ws == my_ws() and prev.pos_s and online:
                S.ghosts.append({"ws": prev.ws, "pos": list(prev.pos_s), "t0": time.time(), "name": name, "color": col,
                                 "text": f"{name} is switching to the {ws} workspace"})
            ps = (list(prev.pos_s) if prev and prev.pos_s and pos and prev.pos_s[0] == pos.ai and prev.pos_s[1] == pos.at
                  else [pos.ai, pos.at, pos.fx, pos.fy] if pos else None)
            remote[uid] = types.SimpleNamespace(uid=uid, name=name, color=col, sel=sel, cur=cur, online=online, cam=cam,
                                                cam_s=(prev.cam_s if prev and prev.cam_s and cam else cam),
                                                ws=ws, pos=pos, pos_s=ps, font=fn[:63])
    S.remote = remote
    inputs.prune(set(m))
    redraw_cursors()
    people.sort(key=lambda q: (not q.host, q.name.lower()))
    S.people = people
    S.pfps = {u: b for u, b in S.pfps.items() if u in m}
    S.curs = {u: b for u, b in S.curs.items() if u in m}
    rows.sort()
    if rows != S.rows_sig:
        S.rows_sig = rows
        PRES["t"] = min(PRES["t"], time.time() + 3)  # roster refresh in a few seconds
        coll = bpy.context.window_manager.sw_members
        coll.clear()
        for _, name, uid, col, online, act, me, ms in rows:
            it = coll.add()
            it.name, it.online, it.activity, it.ms = name, online, act, ms
            it["c"] = col
            it.host, it.me = uid == S.host, me
    redraw()


def view_cam():
    """This user's 3D viewport camera as [x,y,z, qw,qx,qy,qz] (first 3D view found)."""
    for w in bpy.context.window_manager.windows:
        for a in w.screen.areas:
            rv = getattr(a.spaces.active, "region_3d", None) if a.type == "VIEW_3D" else None
            if rv is not None:
                m = rv.view_matrix.inverted()
                return [round(c, 3) for c in m.translation] + [round(c, 4) for c in m.to_quaternion()]
    return None


def smooth_cams(a):
    """Ease remote viewport cameras toward their latest sample. Returns True while still moving."""
    moving = False
    for r in S.remote.values():
        if r.cam:
            (l, q), (tl, tq) = r.cam_s, r.cam
            r.cam_s = (l.lerp(tl, a), q.slerp(tq, a))
            moving = moving or (r.cam_s[0] - tl).length > 1e-4 or r.cam_s[1].rotation_difference(tq).angle > 1e-3
        if r.pos and r.pos_s:
            dx, dy = r.pos.fx - r.pos_s[2], r.pos.fy - r.pos_s[3]
            r.pos_s[2] += dx * a
            r.pos_s[3] += dy * a
            moving = moving or abs(dx) > 1e-4 or abs(dy) > 1e-4
    return moving


def anim_tick():
    """~60 Hz while anything is easing (remote cameras, remote object moves), 10 Hz idle."""
    try:
        presence_tick()
        if S.worker is None:
            return 0.25
        now = time.perf_counter()
        dt, S.anim_t = min(0.1, now - S.anim_t), now
        a = 1.0 - math.exp(-dt / (0.08 if S.local else 0.2))
        busy = smooth_cams(a)
        S.ghosts = [g for g in S.ghosts if time.time() - g["t0"] < 2.5]
        S.pings = [g for g in S.pings if time.time() - g["t0"] < 4]
        busy = busy or bool(S.ghosts) or bool(S.pings)
        for i in list(S.glide):
            o = find(i)
            if o is None:
                del S.glide[i]
                continue
            tl, tq, ts = S.glide[i]
            l, q, sc = o.matrix_basis.decompose()
            done = (l - tl).length < 1e-5 and (sc - ts).length < 1e-5 and q.rotation_difference(tq).angle < 1e-5
            if done:
                o.matrix_basis = Matrix.LocRotScale(tl, tq, ts)
                del S.glide[i]
            else:
                o.matrix_basis = Matrix.LocRotScale(l.lerp(tl, a), q.slerp(tq, a), sc.lerp(ts, a))
                busy = True
            S.known[i] = snap(o)
        if busy:
            redraw()
            redraw_cursors()
        return 1 / 60 if busy else 0.1
    except Exception:
        log.exception("anim_tick failed")
        return 0.25


def set_my_color(rgb):
    """User picked a color: remember it, hand it to the worker, push presence now."""
    if S.setting_color:
        return
    h = "#%02X%02X%02X" % tuple(round(max(0.0, min(1.0, c)) * 255) for c in rgb)
    try:
        bpy.context.preferences.addons[__package__].preferences.color_hex = h
    except Exception:
        pass
    w = S.worker
    if w is not None and h != w.color:
        w.color, S.color = h, h
        w.presence_v += 1


def push_presence(w):
    c = bpy.context
    vl = c.view_layer
    sel = []
    for o in vl.objects.selected:
        i = o.get(ID)
        if isinstance(i, str):
            sel.append(i)
    ao = vl.objects.active
    act = c.mode.replace("_", " ").title() + (f" - {ao.name}" if ao else "")
    p = {"sel": sel[:100], "cur": [round(x, 3) for x in c.scene.cursor.location], "activity": act, "cam": view_cam(), "ui": ui_state()}
    pr = c.preferences.addons[__package__].preferences
    if pr.input_share:
        p["inp"] = inputs.wire(pr.input_key_time)
    elif S.pres and S.pres.get("inp") not in (None, [0, 0, ""]):
        p["inp"] = [0, 0, ""]  # tell the others to hide my display once
    if p != S.pres:
        S.pres = p
        w.presence = p
        w.presence_v += 1


def drain(w):
    end = time.perf_counter() + BUDGET
    while time.perf_counter() < end:
        try:
            msg = w.inbox.get_nowait()
        except queue.Empty:
            return
        t = msg[0]
        if t == "event":
            safe_apply(msg[1])
            S.last_sync = time.time()
        elif t == "snapshot":
            on_snapshot(msg[1], msg[2], msg[3] if len(msg) > 3 else ())
        elif t == "members":
            on_members(msg[1], msg[2])
        elif t == "joined":
            S.host, S.color = msg[1], msg[2]
            S.setting_color = True
            try:
                bpy.context.window_manager.sw_my_color = hex2rgb(S.color)
            finally:
                S.setting_color = False
        elif t == "pfp":
            pf, _, cu = (msg[2] or "").partition(",")
            for d, v in ((S.pfps, pf), (S.curs, cu)):
                if v:
                    d[msg[1]] = v
                else:
                    d.pop(msg[1], None)
            redraw()
        elif t == "perms":
            S.perms = msg[1]
            redraw()
        elif t == "chat":
            m = msg[1]
            chat_add(m["n"], hex2rgb(m["c"]), m["t"])
        elif t == "sent":
            S.last_sync = msg[1]
        elif t == "denied":
            S.revert_at = time.time() + 1.0  # roll the refused edit back from the host's state
            if time.time() > S.deny_t:
                S.deny_t = time.time() + 10
                chat_add("SilverWood", (0.9, 0.5, 0.39), "The host limited which collections you may edit; that change was undone.", system=True)
        elif t == "error":
            ERRORS.append(msg[1])
        elif t == "fatal":
            ERRORS.append(msg[1])
            FATAL.append(msg[1])
            stop()
            return


def tick():
    try:
        w = S.worker
        if w is None and not secret():
            new_secret()
        if w is not None and S.tunnel is not None and not S.code:
            if S.tunnel.url:
                S.code = fmt(make_tunnel_code(S.tunnel.url, secret()))
                room_publish(S.code)
                redraw()
            elif S.tunnel.err:
                ERRORS.append(S.tunnel.err)
                FATAL.append(S.tunnel.err)
                stop()
                return 0.1
        if w is not None:
            drain(w)
            if S.worker is w and S.ready and bpy.context.scene is not None:
                items, S.deferred = S.deferred, []
                for ev in items:
                    if time.time() - ev["_t"] < 30:
                        safe_apply(ev)
                if S.dirty:
                    S.dirty = False
                    S.guard = time.time() < S.guard_until
                    try:
                        W = local_diff(bpy.context.scene)
                    finally:
                        S.guard = False
                    if S.skipped:
                        n, S.skipped, w.resync = S.skipped, 0, True
                        chat_add("SilverWood", (0.9, 0.5, 0.39), f"Undo skipped {n} change(s) that would have overwritten a teammate's work.", system=True)
                    if W:
                        if w.role == "view":
                            S.revert_at = time.time() + 1.0
                        else:
                            w.outbox.put(W)
                if time.time() >= S.asset_next and w.role != "view":
                    S.asset_next = time.time() + 1.5
                    push_assets(w)
                if time.time() >= S.scene_next:
                    S.scene_next = time.time() + 1.0
                    W = scene_diff()
                    if W:
                        if w.role == "view":
                            S.revert_at = time.time() + 1.0
                        else:
                            w.outbox.put(W)
                if S.revert_at and time.time() >= S.revert_at:
                    S.revert_at = 0.0
                    w.resync = True
                if time.time() >= S.pres_next:
                    S.pres_next = time.time() + (0.06 if S.local else 0.2)
                    push_presence(w)
    except Exception:
        log.exception("tick failed")
    if S.chat_toast and time.time() > S.chat_toast[3]:
        S.chat_toast = None
        redraw()
    return 0.03 if S.local else 0.05


@bpy.app.handlers.persistent
def on_undo(*_):
    if S.worker is not None:
        # ponytail: 0.6 s window also guards my own edits to teammates' properties right after an undo
        S.guard_until, S.dirty, S.touch_all = time.time() + 0.6, True, True


@bpy.app.handlers.persistent
def on_depsgraph(scene, depsgraph):
    if S.worker is None:
        return
    S.dirty = True
    for u in depsgraph.updates:
        i = u.id
        if isinstance(i, bpy.types.Object):
            if u.is_updated_geometry:
                S.geo.add(i.original.name)
            S.touch.add(i.original.name)
        elif isinstance(i, (bpy.types.Material, bpy.types.NodeTree)):
            S.mats = True
        elif not isinstance(i, (bpy.types.Mesh, bpy.types.Material, bpy.types.Scene, bpy.types.World, bpy.types.Collection,
                                bpy.types.Image)):
            S.touch_all = True


@bpy.app.handlers.persistent
def on_load(*_):
    stop()


def start(kind, code=""):
    """kind: 'tunnel' (this PC + public tunnel, worldwide), 'online' (Firebase), 'local' (LAN/VPN), 'join' (by code length)."""
    stop()
    LAST[:] = [kind, code]
    prefs = bpy.context.preferences.addons[__package__].preferences
    srv, local, mode = None, False, "create"
    if kind == "community":
        mode, base, token, sid = "join", prefs.database_url, prefs.auth_token, lobby.COMMUNITY_SID
        S.code = "FREE-FOR-ALL"
    elif kind != "join":
        if not secret():
            new_secret()
        if kind in ("local", "tunnel"):
            srv = server.start(prefs.port, secret())
            base, token, sid, local = f"http://127.0.0.1:{prefs.port}", secret(), "main", True
            S.code = host_code() if kind == "local" else ""
            if S.code:
                room_publish(S.code)
        else:
            base, token = prefs.database_url, prefs.auth_token
            S.code = online_code()
            sid = S.code.replace("-", "")
    else:
        mode, c = "join", re.sub(r"[^A-Z2-7]", "", code.upper())
        if len(c) == 6:
            try:
                room = net.Client(prefs.database_url, prefs.auth_token).call("GET", f"rooms/{c}", timeout=8)
                if isinstance(room.get("t"), (int, float)) and time.time() * 1000 - room["t"] > 180000:
                    raise ValueError("host stopped refreshing it")  # a leftover room from a closed or crashed host
                c = re.sub(r"[^A-Z2-7]", "", str(room["c"]).upper())
            except Exception:
                raise ValueError("Room code not found (is the host still online?)") from None
        if len(c) == 24:
            ip, port, token = parse_code(c)
            base, sid, local = f"http://{ip}:{port}", "main", True
        elif len(c) >= 32:
            base, token = parse_tunnel_code(c)
            sid, local = "main", True
        elif len(c) == 8:
            base, token, sid = prefs.database_url, prefs.auth_token, c
        else:
            raise ValueError("Unrecognised code (room 6, online 8, LAN/VPN 24, worldwide 32+ characters)")
        S.code = fmt(c)
    user = my_name()
    cid = prefs.client_id
    if not re.fullmatch(r"[0-9a-f]{16}", cid or ""):
        cid = prefs.client_id = os.urandom(8).hex()
    ERRORS.clear()
    FATAL.clear()
    S.server, S.local = srv, local
    S.tunnel = tunnel.start(prefs.port) if kind == "tunnel" else None
    S.uid, S.sid = uuid.uuid4().hex[:12], sid
    S.project = os.path.basename(bpy.data.filepath) or "Untitled"
    pref = prefs.color_hex if re.fullmatch(r"#[0-9A-Fa-f]{6}", prefs.color_hex) else None
    S.worker = net.Worker(net.Client(base, token, S.uid if local else "", cid if local else ""), mode, sid, S.uid,
                          user[:32], S.project, local=local, color=pref, community=kind == "community")
    S.com = kind == "community"
    if S.com:
        LOB["com"] = max(LOB["com"], 1)
    S.worker.pfp_b64 = MY["b64"] + "," + MY["cur"] if MY["cur"] and prefs.use_custom_cursor else MY["b64"]
    S.worker.pfp_ver = MY["ver"]
    limits.apply(prefs.size_boost)
    ensure_font()
    cleanup_leftovers()
    if not local and mode == "create":
        track(f"sessions/{sid}")
        track(f"roster/{sid}")
    S.worker.start()


def wipe_scene():
    """Delete every object, collection and unused datablock so no one else's models stay in this file.
    Call AFTER stop(): with no live session the deletions are never sent to other users."""
    try:
        ao = bpy.context.object
        if ao is not None and ao.mode != 'OBJECT':
            bpy.ops.object.mode_set(mode='OBJECT')
    except Exception:
        pass
    D = bpy.data
    for o in list(D.objects):
        D.objects.remove(o, do_unlink=True)
    for c in list(D.collections):
        D.collections.remove(c)
    logo = os.path.abspath(os.path.join(os.path.dirname(__file__), "logo.png"))

    def mine(img):
        if img.name.startswith(".sw_") or img.type != 'IMAGE':
            return True
        try:
            return os.path.abspath(bpy.path.abspath(img.filepath)) == logo
        except Exception:
            return False

    for _ in range(2):  # twice: node groups/materials freed by the first pass
        for coll in (D.meshes, D.curves, D.lights, D.cameras, D.armatures, D.lattices, D.metaballs, D.speakers,
                     D.materials, D.node_groups, D.textures, D.actions, D.images):
            for idb in list(coll):
                if idb.users == 0 and not (coll is D.images and mine(idb)):
                    try:
                        coll.remove(idb)
                    except Exception:
                        pass


def stop(join=False):
    try:
        drop_font()
    except Exception:
        log.exception("font cleanup failed")
    w, srv = S.worker, S.server
    if S.lobby:
        fb_call("DELETE", f"lobbies/{S.lobby}", quiet=True)
    if S.com and PRES["cid"]:
        fb_call("DELETE", f"community/{lobby.shard(PRES['cid'])}/{PRES['cid']}", quiet=True)
    if S.room:
        fb_call("DELETE", f"rooms/{S.room}", quiet=True)
        fb_call("DELETE", f"roster/{S.room}", quiet=True)
    elif S.worker is not None and not S.local and S.host == S.uid:
        fb_call("DELETE", f"roster/{S.sid}", quiet=True)  # Firebase session: whoever is host now rewrites it
    try:
        prefs().leftovers, PRES["track"] = "[]", []
    except Exception:
        pass
    if w is not None:
        w.stop_ev.set()
        if join:
            w.join(3)
    if S.tunnel is not None:
        tunnel.stop(S.tunnel)
    if getattr(srv, "stop_auto", None) is not None:
        srv.stop_auto.set()
    if srv is not None:
        srv.shutdown()
        srv.server_close()
    reset()
    inputs.clear()
    try:
        bpy.context.window_manager.sw_members.clear()
        redraw()
    except Exception:
        pass
