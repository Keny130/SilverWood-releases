"""Host-side data store: a tiny in-memory server speaking the Firebase-REST subset SilverWood uses.

The host's Blender runs this; every client (including the host itself) talks to it with net.Client.
Supports GET/PUT/PATCH(multi-path)/DELETE on <path>.json, orderBy="$key" + startAt/endAt, ".sv" timestamps.
Storage is host RAM: no per-file size limit. Requests need ?auth=<token>.
"""
import hmac
import json
import random
import copy
import threading
import time
import urllib.parse
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

MAX_BODY = 512 * 1024 * 1024


def _sv(x):
    if isinstance(x, dict):
        if x == {".sv": "timestamp"}:
            return int(time.time() * 1000)
        return {k: _sv(v) for k, v in x.items() if v is not None}
    return x


SCENE_OBJ = "f" * 30 + "01"  # scene-level events (frame, settings, collection list) are never zoned


class Store:
    def __init__(self):
        self.db = {}

    def get(self, path):
        n = self.db
        for p in path:
            if not isinstance(n, dict) or p not in n:
                return None
            n = n[p]
        return None if n == {} else n

    def put(self, path, val):
        val = _sv(val)
        if not path:
            self.db = val if isinstance(val, dict) else {}
            return
        n = self.db
        for p in path[:-1]:
            if val is None:
                n = n.get(p)
                if not isinstance(n, dict):
                    return
            else:
                if not isinstance(n.get(p), dict):
                    n[p] = {}
                n = n[p]
        if val is None:
            n.pop(path[-1], None)
        else:
            n[path[-1]] = val


class Control:
    """Host-only moderation. The host's Blender calls these directly (same process as the server);
    no HTTP route can reach them, and HTTP writes to `perms` are refused.

    Identity is the `uid` (per join) and `cid` (per install) query parameters every client sends.
    That is cooperative security for a friends-only tool: it stops the normal add-on, not someone
    who rewrites it. The host PC is what enforces it (clients cannot skip it).
    """

    def __init__(self, store, lock):
        self.store, self.lock = store, lock
        self.kicked, self.banned, self.seen, self.cids = set(), set(), set(), {}
        self.locked = False
        self.snaps = []  # (ms, label, {objects, meshes, assets, asset_meta}); RAM only, newest last

    def _host(self):
        h = self.store.get(["sessions", "main", "host"])
        return h if isinstance(h, str) else ""

    def _perms(self):
        p = self.store.get(["sessions", "main", "perms"])
        return p if isinstance(p, dict) else {}

    def _role(self, uid):
        p = self._perms()
        return "view" if (p.get(uid) or p.get("_default") or "edit") == "view" else "edit"

    def admit(self, uid, cid, write, targets):
        """Called by the request handler with the lock held. Returns None, or the refusal reason."""
        host = self._host()
        if uid and uid == host:
            self.cids[uid] = cid
            self.seen.add(uid)
            return None
        if uid in self.kicked or (cid and cid in self.banned):
            return "kicked"
        if uid and uid not in self.seen:
            if self.locked and host:
                return "locked"
            self.seen.add(uid)
        if uid:
            self.cids[uid] = cid
        if write and host:
            for t in targets:
                if len(t) <= 2 or t[2] in ("perms", "cperms"):
                    return "host only"
            if self._role(uid) == "view" and any(t[2:4] not in (["members", uid], ["pfps", uid]) and t[2:3] != ["chat"] for t in targets):
                return "view-only"
        return None

    def denied(self, uid, targets, vals):
        """Indexes of writes that touch an object outside this user's zone. Zone = a set of collection ids plus a mode:
        "only" (may edit only objects in them) or "not" (may edit everything except objects in them).
        Both the object's current collections and the ones it is being moved to must pass."""
        host = self._host()
        cp = self.store.get(["sessions", "main", "cperms", uid]) if host and uid != host else None
        # only the host may send a rollback ("reset") event
        out = {n for n, (t, v) in enumerate(zip(targets, vals)) if host and uid != host and t[2:3] == ["events"]
               and isinstance(v, dict) and v.get("k") == "reset"}
        cs = set(cp["c"]) if isinstance(cp, dict) and isinstance(cp.get("c"), dict) else set()
        if not cs:
            return out
        only = cp.get("m") != "not"
        for n, (t, v) in enumerate(zip(targets, vals)):
            if t[2:3] == ["events"] and len(t) == 4 and isinstance(v, dict):
                if v.get("k") == "ping":
                    continue
                oid, new = v.get("id"), v.get("col")
            elif t[2:3] in (["objects"], ["meshes"]) and len(t) >= 4:
                oid = t[3]
                new = v.get("col") if len(t) == 4 and isinstance(v, dict) else (v if t[4:5] == ["col"] else None)
            else:
                continue
            if oid == SCENE_OBJ:
                continue
            cur = self.store.get(["sessions", "main", "objects", str(oid), "col"])
            for col in ([new] if new is not None else []) + ([cur] if cur is not None or new is None else []):
                m = {x for x in col if isinstance(x, str)} if isinstance(col, list) else set()
                if bool(m & cs) != only:
                    out.add(n)
                    break
        return out

    SNAP_KEYS = ("objects", "meshes", "assets", "asset_meta")
    MAX_SNAPS = 10

    def snapshot(self, label="manual"):
        """Keep a copy of the scene state. Mesh chunk strings are shared, not duplicated, so it is cheap."""
        with self.lock:
            sess = self.store.get(["sessions", "main"]) or {}
            if not sess.get("objects"):
                return False
            self.snaps.append((int(time.time() * 1000), label, {k: copy.deepcopy(sess[k]) for k in self.SNAP_KEYS if k in sess}))
            del self.snaps[:-self.MAX_SNAPS]
            return True

    def snap_list(self):
        with self.lock:
            return [(ts, label) for ts, label, _ in self.snaps]

    def rollback(self, n):
        """Put the stored scene back to snapshot n and tell everyone to resync (clients delete what is not in it)."""
        with self.lock:
            if not 0 <= n < len(self.snaps):
                return False
            snap = self.snaps[n][2]
            for k in self.SNAP_KEYS:
                self.store.put(["sessions", "main", k], copy.deepcopy(snap.get(k)))
            host, ts = self._host(), int(time.time() * 1000)
            self.store.put(["sessions", "main", "events", f"{ts:013d}-{host[:4]}{random.randrange(100000):05d}"],
                           {"id": SCENE_OBJ, "k": "reset", "ts": ts, "u": host})
            return True

    def cperms(self):
        with self.lock:
            p = self.store.get(["sessions", "main", "cperms"])
            return dict(p) if isinstance(p, dict) else {}

    def zone(self, uid, mode=None, cid=None):
        """Set a user's zone mode and/or toggle one collection id in their zone."""
        with self.lock:
            if not uid or uid == self._host():
                return
            cur = self.store.get(["sessions", "main", "cperms", uid])
            cur = cur if isinstance(cur, dict) else {}
            c = dict(cur.get("c") or {})
            if cid:
                c.pop(cid) if cid in c else c.__setitem__(cid, True)
            self.store.put(["sessions", "main", "cperms", uid], {"m": mode or cur.get("m") or "only", "c": c} if (c or mode) else None)

    def roles(self):
        with self.lock:
            return dict(self._perms())

    def state(self):
        """(locked, default role, number of kicked installs)"""
        with self.lock:
            return self.locked, self._perms().get("_default") or "edit", len(self.banned) + len(self.kicked)

    def set_role(self, uid, role):
        with self.lock:
            if uid and uid != self._host():
                self.store.put(["sessions", "main", "perms", uid], "view" if role == "view" else "edit")

    def set_default(self, role):
        with self.lock:
            self.store.put(["sessions", "main", "perms", "_default"], "view" if role == "view" else None)

    def lock_joins(self, on):
        with self.lock:
            self.locked = bool(on)

    def kick(self, uid):
        """Remove a user. Their next request is refused, and so is their install (cid) unless it is the host's own PC."""
        with self.lock:
            host = self._host()
            if not uid or uid == host:
                return False
            self.kicked.add(uid)
            cid = self.cids.get(uid)
            if cid and cid != self.cids.get(host):
                self.banned.add(cid)
            for sub in ("members", "pfps", "perms", "cperms"):
                self.store.put(["sessions", "main", sub, uid], None)
            return True

    def clear_kicks(self):
        with self.lock:
            self.kicked.clear()
            self.banned.clear()


def start(port, token):
    """Start serving on 0.0.0.0:port. Returns the server (call shutdown() + server_close() to stop)."""
    store, lock = Store(), threading.Lock()
    ctl = Control(store, lock)

    class H(BaseHTTPRequestHandler):
        def log_message(self, *a):
            pass

        def reply(self, code, obj):
            data = json.dumps(obj).encode()
            self.send_response(code)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(data)))
            self.end_headers()
            self.wfile.write(data)

        def handle_any(self):
            u = urllib.parse.urlparse(self.path)
            q = urllib.parse.parse_qs(u.query)
            if not hmac.compare_digest(q.get("auth", [""])[0], token):
                return self.reply(401, {"error": "Permission denied"})
            n = int(self.headers.get("Content-Length") or 0)
            if n > MAX_BODY or not u.path.endswith(".json"):
                return self.reply(400, {"error": "Bad request"})
            try:
                body = json.loads(self.rfile.read(n)) if n else None
            except ValueError:
                return self.reply(400, {"error": "Bad JSON"})
            path = [p for p in urllib.parse.unquote(u.path[:-5]).split("/") if p]
            m = self.command
            uid, cid = q.get("uid", [""])[0][:32], q.get("cid", [""])[0][:40]
            if m == "PATCH" and isinstance(body, dict):
                targets = [path + [p for p in k.split("/") if p] for k in body]
            else:
                targets = [path] if m != "GET" else []
            with lock:
                why = ctl.admit(uid, cid, m != "GET", targets)
                if why is None:
                    items = list(body.items()) if m == "PATCH" and isinstance(body, dict) else None
                    bad = ctl.denied(uid, targets, [v for _, v in items] if items is not None else [body]) if m != "GET" else set()
                    if m == "PUT" and not bad:
                        store.put(path, body)
                    elif items is not None:
                        for n, (k, v) in enumerate(items):
                            if n not in bad:
                                store.put(path + [p for p in k.split("/") if p], v)
                    elif m == "DELETE" and not bad:
                        store.put(path, None)
                    out = store.get(path) if m == "GET" else body
                    if bad and isinstance(out, dict):
                        out = {**out, "_denied": len(bad)}
                    if m == "GET" and "orderBy" in q and isinstance(out, dict):
                        try:
                            lo = json.loads(q["startAt"][0]) if "startAt" in q else ""
                            hi = json.loads(q["endAt"][0]) if "endAt" in q else "\U0010ffff"
                        except ValueError:
                            why, out = "bad query", None
                        else:
                            out = {k: v for k, v in out.items() if lo <= k <= hi}
                    data = json.dumps(out)
            if why is not None:
                return self.reply(400 if why == "bad query" else 403, {"error": why})
            self._raw(data)

        def _raw(self, data):
            b = data.encode()
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(b)))
            self.end_headers()
            self.wfile.write(b)

        do_GET = do_PUT = do_PATCH = do_DELETE = handle_any

    try:
        srv = ThreadingHTTPServer(("0.0.0.0", port), H)
    except OSError as e:
        raise ValueError(f"Cannot open port {port}: {e}") from None
    srv.daemon_threads = True
    srv.ctl = ctl
    srv.stop_auto = threading.Event()

    def auto():  # ponytail: fixed 5 min cadence, RAM only; write snapshots to disk if they must survive the session
        while not srv.stop_auto.wait(300):
            ctl.snapshot("auto")

    threading.Thread(target=auto, daemon=True, name="SilverWood-snap").start()
    threading.Thread(target=srv.serve_forever, kwargs={"poll_interval": 0.1}, daemon=True, name="SilverWood-host").start()
    return srv
