"""Duddy's eyes and hands. scene() describes the scene for the AI; DO maps the command names the AI may use to Blender actions.
The AI only ever sends literals (parsed with ast in ai.py), never code that gets executed."""
import math

import bmesh
import bpy
from mathutils import Vector

from . import duddy


def _ob(name):
    n = str(name)
    o = bpy.data.objects.get(n) or next((x for x in bpy.data.objects if x.name.lower() == n.lower()), None)
    if o is None:
        raise ValueError(f"no object called {n}")
    return o


def _v(t, n=3):
    t = tuple(float(x) for x in t)
    if len(t) != n or not all(math.isfinite(x) and abs(x) < 1e5 for x in t):
        raise ValueError("bad vector")
    return t


def _look(ob, sel=None):
    bpy.context.view_layer.update()  # new/moved objects have a stale world matrix until this
    w = ob.matrix_world.translation
    duddy.D.update(focus=Vector(w), cur_to="focus")
    if sel is not None:
        duddy.D.update(sel=sel, selname=ob.name if sel else None)


def scene():
    """Plain-text list of every object and where it is (the AI's way to 'look')."""
    bpy.context.view_layer.update()
    rows, sel = [], []
    for o in list(bpy.data.objects)[:150]:
        w, d, r, s = o.matrix_world.translation, o.dimensions, o.rotation_euler, o.scale
        on = o.select_get() if o.name in bpy.context.view_layer.objects else False
        if on:
            sel.append(o.name)
        rows.append(f"{o.name} | {o.type} | at({w.x:.2f},{w.y:.2f},{w.z:.2f}) | rot_deg({math.degrees(r.x):.0f},{math.degrees(r.y):.0f},"
                    f"{math.degrees(r.z):.0f}) | scale({s.x:.2f},{s.y:.2f},{s.z:.2f}) | size({d.x:.2f},{d.y:.2f},{d.z:.2f})" + (" | SELECTED" if on else ""))
    out = "Objects (Z up, metres):\n" + ("\n".join(rows) or "(the scene is empty)")
    ao = bpy.context.view_layer.objects.active
    if ao is not None and ao.type == 'MESH' and len(ao.data.vertices) <= 64:  # small active mesh: give its geometry so it can be rewritten
        out += (f"\nGeometry of active object {ao.name}: verts={[tuple(round(c, 3) for c in v.co) for v in ao.data.vertices]} "
                f"faces={[tuple(p.vertices) for p in ao.data.polygons]}")
    return out


def _new(name, me):
    ob = bpy.data.objects.new(str(name), me)
    (bpy.context.collection or bpy.context.scene.collection).objects.link(ob)
    return ob


def add(kind, name, loc=(0, 0, 0), size=(1, 1, 1)):
    k, bm = str(kind).lower(), bmesh.new()
    if k == "cube":
        bmesh.ops.create_cube(bm, size=2.0)
    elif k == "sphere":
        bmesh.ops.create_uvsphere(bm, u_segments=32, v_segments=16, radius=1.0)
    elif k in ("cylinder", "cone"):
        bmesh.ops.create_cone(bm, cap_ends=True, cap_tris=False, segments=32, radius1=1.0, radius2=0.0 if k == "cone" else 1.0, depth=2.0)
    elif k == "plane":
        bm.faces.new([bm.verts.new(p) for p in ((-1, -1, 0), (1, -1, 0), (1, 1, 0), (-1, 1, 0))])
    elif k == "monkey":
        bmesh.ops.create_monkey(bm)
    else:
        bm.free()
        raise ValueError(f"unknown shape {k}")
    me = bpy.data.meshes.new(str(name))
    bm.to_mesh(me)
    bm.free()
    for p in me.polygons:
        p.use_smooth = k in ("sphere", "monkey")
    ob = _new(name, me)
    ob.location, ob.scale = _v(loc), _v(size)
    _look(ob)


def mesh(name, verts, faces, loc=(0, 0, 0)):
    verts, faces = [_v(v) for v in verts], [tuple(int(i) for i in f) for f in faces]
    if len(verts) > 4000 or len(faces) > 4000 or any(len(f) < 3 or min(f) < 0 or max(f) >= len(verts) for f in faces):
        raise ValueError("bad or too big mesh")
    ob = bpy.data.objects.get(str(name))
    if ob is not None and ob.type == 'MESH':
        ob.data.clear_geometry()
        me = ob.data
    else:
        me = bpy.data.meshes.new(str(name))
        ob = _new(name, me)
        ob.location = _v(loc)
    me.from_pydata(verts, [], faces)
    me.update()
    me.validate()
    _look(ob)


def select(name):
    ob = _ob(name)
    for o in bpy.context.view_layer.objects:
        o.select_set(False)
    ob.select_set(True)
    bpy.context.view_layer.objects.active = ob
    _look(ob, True)


def deselect():
    for o in bpy.context.view_layer.objects:
        o.select_set(False)
    duddy.D["sel"] = False


def move(name, pos):
    ob = _ob(name)
    ob.location = _v(pos)
    _look(ob)


def shift(name, d):
    ob = _ob(name)
    ob.location = ob.location + Vector(_v(d))
    _look(ob)


def rotate(name, deg):
    ob = _ob(name)
    ob.rotation_euler = [math.radians(a) for a in _v(deg)]
    _look(ob)


def scale(name, s):
    ob = _ob(name)
    ob.scale = _v(s)
    _look(ob)


def delete(name):
    ob = _ob(name)
    _look(ob, False)
    bpy.data.objects.remove(ob, do_unlink=True)


def rename(name, new):
    _ob(name).name = str(new)[:60]


def color(name, rgb):
    ob, c = _ob(name), _v(rgb)
    m = bpy.data.materials.new(ob.name + " color")
    m.diffuse_color = (*c, 1.0)
    try:
        m.use_nodes = True
        m.node_tree.nodes["Principled BSDF"].inputs["Base Color"].default_value = (*c, 1.0)
    except Exception:
        pass  # ponytail: viewport colour only if the node tree API differs
    ob.data.materials.clear()
    ob.data.materials.append(m)
    _look(ob)


def modifier(name, kind, v=1):
    ob, k, v = _ob(name), str(kind).lower(), float(v)
    m = ob.modifiers.new(k, {"subsurf": "SUBSURF", "mirror": "MIRROR", "solidify": "SOLIDIFY", "bevel": "BEVEL", "array": "ARRAY"}[k])
    if k == "subsurf":
        m.levels = m.render_levels = max(0, min(int(v), 4))
    elif k == "solidify":
        m.thickness = v
    elif k == "bevel":
        m.width = v
    elif k == "array":
        m.count = max(1, min(int(v), 100))
    else:
        m.use_axis = [i == int(v) for i in range(3)]
    _look(ob)


DO = {f.__name__: f for f in (add, mesh, select, deselect, move, shift, rotate, scale, delete, rename, color, modifier)}
