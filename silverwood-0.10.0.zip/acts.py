import math

import bmesh
import bpy
from mathutils import Vector

from . import duddy


def getob(name):
    n = str(name)
    o = bpy.data.objects.get(n) or next((x for x in bpy.data.objects if x.name.lower() == n.lower()), None)
    if o is None:
        raise ValueError(f"no object called {n}")
    return o


def vec3(t, n=3):
    t = tuple(float(x) for x in t)
    if len(t) != n or not all(math.isfinite(x) and abs(x) < 1e5 for x in t):
        raise ValueError("bad vector")
    return t


def peek(o_, sel=None):
    bpy.context.view_layer.update()
    w = o_.matrix_world.translation
    duddy.D.update(focus=Vector(w), cur_to="focus")
    if sel is not None:
        duddy.D.update(sel=sel, selname=o_.name if sel else None)


def scene():
    bpy.context.view_layer.update()
    rows, sel = [], []
    for o in list(bpy.data.objects)[:150]:
        w, d, r, s = o.matrix_world.translation, o.dimensions, o.rotation_euler, o.scale
        on = o.select_get() if o.name in bpy.context.view_layer.objects else False
        if on:
            sel.append(o.name)
        rows.append(f"{o.name} | {o.type} | at({w.x:.2f},{w.y:.2f},{w.z:.2f}) | rot_deg({math.degrees(r.x):.0f},{math.degrees(r.y):.0f},"
                    f"{math.degrees(r.z):.0f}) | scale({s.x:.2f},{s.y:.2f},{s.z:.2f}) | size({d.x:.2f},{d.y:.2f},{d.z:.2f})" + (" | SELECTED" if on else ""))
    out = "Objects (Z up, metres):\n" + ("\n".join(rows) or "(the scene is empty)")
    ao = bpy.context.view_layer.objects.active
    if ao is not None and ao.type == 'MESH' and len(ao.data.vertices) <= 64:
        out += (f"\nGeometry of active object {ao.name}: verts={[tuple(round(c, 3) for c in v.co) for v in ao.data.vertices]} "
                f"faces={[tuple(p.vertices) for p in ao.data.polygons]}")
    return out


def mkob(name, m_):
    o_ = bpy.data.objects.new(str(name), m_)
    (bpy.context.collection or bpy.context.scene.collection).objects.link(o_)
    return o_


def add(kind, name, loc=(0, 0, 0), size=(1, 1, 1)):
    k, b = str(kind).lower(), bmesh.new()
    if k == "cube":
        bmesh.ops.create_cube(b, size=2.0)
    elif k == "sphere":
        bmesh.ops.create_uvsphere(b, u_segments=32, v_segments=16, radius=1.0)
    elif k in ("cylinder", "cone"):
        bmesh.ops.create_cone(b, cap_ends=True, cap_tris=False, segments=32, radius1=1.0, radius2=0.0 if k == "cone" else 1.0, depth=2.0)
    elif k == "plane":
        b.faces.new([b.verts.new(p) for p in ((-1, -1, 0), (1, -1, 0), (1, 1, 0), (-1, 1, 0))])
    elif k == "monkey":
        bmesh.ops.create_monkey(b)
    else:
        b.free()
        raise ValueError(f"unknown shape {k}")
    m_ = bpy.data.meshes.new(str(name))
    b.to_mesh(m_)
    b.free()
    for p in m_.polygons:
        p.use_smooth = k in ("sphere", "monkey")
    o_ = mkob(name, m_)
    o_.location, o_.scale = vec3(loc), vec3(size)
    peek(o_)


def mesh(name, verts, faces, loc=(0, 0, 0)):
    verts, faces = [vec3(v) for v in verts], [tuple(int(i) for i in f) for f in faces]
    if len(verts) > 4000 or len(faces) > 4000 or any(len(f) < 3 or min(f) < 0 or max(f) >= len(verts) for f in faces):
        raise ValueError("bad or too big mesh")
    o_ = bpy.data.objects.get(str(name))
    if o_ is not None and o_.type == 'MESH':
        o_.data.clear_geometry()
        m_ = o_.data
    else:
        m_ = bpy.data.meshes.new(str(name))
        o_ = mkob(name, m_)
        o_.location = vec3(loc)
    m_.from_pydata(verts, [], faces)
    m_.update()
    m_.validate()
    peek(o_)


def select(name):
    o_ = getob(name)
    for o in bpy.context.view_layer.objects:
        o.select_set(False)
    o_.select_set(True)
    bpy.context.view_layer.objects.active = o_
    peek(o_, True)


def deselect():
    for o in bpy.context.view_layer.objects:
        o.select_set(False)
    duddy.D["sel"] = False


def move(name, pos):
    o_ = getob(name)
    o_.location = vec3(pos)
    peek(o_)


def shift(name, d):
    o_ = getob(name)
    o_.location = o_.location + Vector(vec3(d))
    peek(o_)


def rotate(name, deg):
    o_ = getob(name)
    o_.rotation_euler = [math.radians(a) for a in vec3(deg)]
    peek(o_)


def scale(name, s):
    o_ = getob(name)
    o_.scale = vec3(s)
    peek(o_)


def delete(name):
    o_ = getob(name)
    peek(o_, False)
    bpy.data.objects.remove(o_, do_unlink=True)


def rename(name, new):
    getob(name).name = str(new)[:60]


def color(name, rgb):
    o_, c = getob(name), vec3(rgb)
    m = bpy.data.materials.new(o_.name + " color")
    m.diffuse_color = (*c, 1.0)
    try:
        m.use_nodes = True
        m.node_tree.nodes["Principled BSDF"].inputs["Base Color"].default_value = (*c, 1.0)
    except Exception:
        pass
    o_.data.materials.clear()
    o_.data.materials.append(m)
    peek(o_)


def modifier(name, kind, v=1):
    o_, k, v = getob(name), str(kind).lower(), float(v)
    m = o_.modifiers.new(k, {"subsurf": "SUBSURF", "mirror": "MIRROR", "solidify": "SOLIDIFY", "bevel": "BEVEL", "array": "ARRAY"}[k])
    if k == "subsurf":
        m.levels = m.render_levels = max(0, min(int(v), 4))
    elif k == "solidify":
        m.thickness = v
    elif k == "bevel":
        m.width = v
    elif k == "array":
        m.count = max(1, min(int(v), 100))
    else:
        m.use_axis = [i == int(v) for i in range(3)]
    peek(o_)


DO = {f.__name__: f for f in (add, mesh, select, deselect, move, shift, rotate, scale, delete, rename, color, modifier)}
