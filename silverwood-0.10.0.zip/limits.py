"""Size limits that grow with this PC's RAM instead of fixed numbers. Never lower than the old fixed limits."""
import ctypes
import os
import sys

MB = 1024 * 1024
LABELS = {"1": "Auto", "2": "x2", "4": "x4"}


def ram_gb():
    try:
        if sys.platform == "win32":
            class MS(ctypes.Structure):
                _fields_ = [("len", ctypes.c_ulong), ("load", ctypes.c_ulong), ("total", ctypes.c_ulonglong),
                            ("avail", ctypes.c_ulonglong), ("tpf", ctypes.c_ulonglong), ("apf", ctypes.c_ulonglong),
                            ("tv", ctypes.c_ulonglong), ("av", ctypes.c_ulonglong), ("ave", ctypes.c_ulonglong)]
            m = MS()
            m.len = ctypes.sizeof(MS)
            ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(m))
            return m.total / 2 ** 30
        return os.sysconf("SC_PAGE_SIZE") * os.sysconf("SC_PHYS_PAGES") / 2 ** 30
    except Exception:
        return 8.0


def scale(boost="1"):
    """1x at 16 GB RAM, up to 8x at 128 GB, never below 1x; the user's x2 / x4 on top (capped at 16x)."""
    return min(16.0, max(1.0, min(8.0, ram_gb() / 16)) * float(boost if boost in LABELS else 1))


def apply(boost="1"):
    from . import assets, meshio, net, server
    k = scale(boost)
    meshio.MAX_VERTS, meshio.MAX_LOOPS = int(8_000_000 * k), int(40_000_000 * k)
    assets.MAX_BYTES, assets.MAX_CHUNKS = int(200 * MB * k), int(400 * k)
    net.MAX_MESH_CHUNKS, net.MAX_ASSET_CHUNKS, net.MCACHE_BYTES = int(800 * k), int(400 * k), int(800 * MB * k)
    server.MAX_BODY = int(512 * MB * k)


def describe(boost="1"):
    k = scale(boost)
    return (f"Up to {8 * k:.0f}M vertices per mesh and {200 * k:.0f} MB per file on this PC ({ram_gb():.0f} GB RAM). "
            "Everyone in the session needs enough RAM for what the host sends.")
