import ast
import json
import re
import threading
import time
import urllib.error
import urllib.request

import bpy

from . import acts, duddy, sync

SYSTEM = ("You are Duddy, the friendly assistant of SilverWood, a Blender co-op add-on where several people edit one scene live. "
          "Help with Blender, modelling, and using SilverWood. Keep answers short and plain text (no markdown).")
HANDS = """
You are standing inside the user's Blender scene and can act on it. After your short spoken reply you may add a block
<do>
one command per line, Python call syntax with literal values only
</do>
Commands (metres, Z up, angles in degrees, colours 0-1):
select("Name")  deselect()  move("Name",(x,y,z)) absolute  shift("Name",(dx,dy,dz)) relative  rotate("Name",(rx,ry,rz))  scale("Name",(sx,sy,sz))
delete("Name")  rename("Name","New")  color("Name",(r,g,b))  modifier("Name","subsurf|mirror|solidify|bevel|array",number)
add("cube|sphere|cylinder|cone|plane|monkey","Name",(x,y,z),(sx,sy,sz)) - base shapes are 2 m wide/tall (cube spans -1..1), scale multiplies them
mesh("Name",[(x,y,z),...],[(i,j,k,...),...],(x,y,z)) - create a custom mesh from vertices and faces, or replace the mesh of an existing object
Build bigger things out of several add/mesh commands (max 40 per reply). Use object names exactly as listed below.
Talk as if you just did it ("I've selected cube1."). Never mention the commands or the <do> block.
"""
A = {"msgs": [], "busy": False, "err": "", "queue": [], "next": 0.0}
lk = threading.Lock()
DORE = re.compile(r"<do>(.*?)(?:</do>|$)", re.S)


def _prefs():
    try:
        return bpy.context.preferences.addons[__package__].preferences
    except Exception:
        return None


def parse(text):
    todo = []
    for blk in DORE.findall(text):
        for ln in blk.splitlines():
            try:
                n = ast.parse(ln.strip().strip("`"), mode="eval").body
                if isinstance(n, ast.Call) and isinstance(n.func, ast.Name) and n.func.id in acts.DO:
                    todo.append((acts.DO[n.func.id], [ast.literal_eval(a) for a in n.args]))
            except (SyntaxError, ValueError):
                pass
    return DORE.sub("", text).replace("```", "").strip(), todo[:40]


def ask(url, key, model, msgs):
    body = json.dumps({"model": model, "messages": msgs}).encode()
    h = {"Content-Type": "application/json", "User-Agent": "SilverWood-Blender", "Authorization": "Bearer " + (key or "free")}
    req = urllib.request.Request(url.rstrip("/") + "/chat/completions", body, h, method="POST")
    with urllib.request.urlopen(req, timeout=45) as r:
        return json.load(r)["choices"][0]["message"]["content"].strip()


def reason(e):
    return f"HTTP {e.code}" + (" (daily limit?)" if e.code in (402, 429) else "") if isinstance(e, urllib.error.HTTPError) \
        else str(getattr(e, "reason", e))[:80] or e.__class__.__name__


def run(eps, msgs, acting):
    out, errs = "", set()
    for _name, url, key, model in eps:
        try:
            out = ask(url, key, model, msgs)
            break
        except (OSError, ValueError, KeyError, IndexError) as e:
            errs.add(reason(e))
    said, todo = parse(out) if out else ("", [])
    with lk:
        if out:
            A["msgs"].append({"r": "assistant", "t": said or "Done!", "raw": out})
            A["queue"] = todo if acting else []
            duddy.say(said)
        A["err"] = "" if out else "Duddy couldn't think right now: " + "; ".join(sorted(errs))
        A["busy"] = False


def tick():
    now = time.time()
    if A["queue"] and now >= A["next"]:
        fn, args = A["queue"].pop(0)
        try:
            fn(*args)
        except Exception as e:
            A["err"] = (A["err"] + "; " if A["err"] else "") + f"Duddy could not do that: {e}"[:120]
        A["next"] = now + 0.7
    sync.redraw()
    return 0.1 if A["busy"] or A["queue"] else None


def send(text):
    text = text.strip()
    p = _prefs()
    if not text or A["busy"] or p is None:
        return
    acting = duddy.inside()
    sysmsg = SYSTEM + (HANDS + "\nSCENE (scanned just now):\n" + acts.scene() if acting else
                       "\nYou are not in the scene yet. If asked to edit it, say the user can press 'Ask Duddy to join my session' first.")
    with lk:
        A["msgs"].append({"r": "user", "t": text, "raw": text})
        A.update(busy=True, err="", queue=[])
        hist = [{"role": m["r"], "content": m["raw"]} for m in A["msgs"][-20:]]
    eps = [("LLMFaucet", p.llm_url, p.llm_key, p.llm_model)]
    if p.llm_fallback:
        eps += [("Pollinations", "https://text.pollinations.ai/v1", "", "openai"),
                  ("Local Ollama", "http://localhost:11434/v1", "", p.llm_local_model)]
    threading.Thread(target=run, args=(eps, [{"role": "system", "content": sysmsg}] + hist, acting), daemon=True).start()
    if not bpy.app.timers.is_registered(tick):
        bpy.app.timers.register(tick, first_interval=0.1)


def clear():
    with lk:
        A["msgs"].clear()
        A["err"] = ""
