import base64
import hashlib
import json
import struct
import zlib

import numpy as np

MAGIC = "SW2:"
MAX_VERTS = 8_000_000
MAX_LOOPS = 40_000_000
BUILTIN = {"position", "sharp_face", "sharp_edge", "material_index", "uv_seam", "id"}
GENERIC_TYPES = {"FLOAT": ("value", 1, "f4"), "INT": ("value", 1, "i4"), "BOOLEAN": ("value", 1, "u1"),
                 "FLOAT_VECTOR": ("vector", 3, "f4"), "FLOAT_COLOR": ("color", 4, "f4"), "BYTE_COLOR": ("color", 4, "f4"),
                 "INT8": ("value", 1, "i1"), "FLOAT2": ("vector", 2, "f4"), "INT32_2D": ("value", 2, "i4")}
DOMAINS = {"POINT", "EDGE", "FACE", "CORNER"}
COLOR_TYPES = {"FLOAT_COLOR", "BYTE_COLOR"}


class Cap:

    def __init__(self, meta, arrays):
        self.meta, self.arrays = meta, arrays

    def digest(self):
        h = hashlib.blake2b(json.dumps(self.meta, sort_keys=True).encode(), digest_size=16)
        for k in sorted(self.arrays):
            h.update(k.encode())
            h.update(memoryview(np.ascontiguousarray(self.arrays[k])).cast("B"))
        return h.hexdigest()


def _get(coll, prop, n, dtype, width=1):
    a = np.empty(n * width, dtype=dtype)
    if n:
        coll.foreach_get(prop, a)
    return a


def capture(me):
    nv, ne, nf, nl = len(me.vertices), len(me.edges), len(me.polygons), len(me.loops)
    if nv > MAX_VERTS or nl > MAX_LOOPS:
        return None
    A, meta = {}, {"nv": nv, "ne": ne, "nf": nf, "nl": nl}
    A["p"] = _get(me.vertices, "co", nv, "f4", 3)
    A["e"] = _get(me.edges, "vertices", ne, "i4", 2)
    A["o"] = _get(me.polygons, "loop_start", nf, "i4")
    A["c"] = _get(me.loops, "vertex_index", nl, "i4")
    mi = _get(me.polygons, "material_index", nf, "i4")
    if mi.any():
        A["mi"] = mi.astype("i2") if mi.max() < 32000 else mi
    sm = _get(me.polygons, "use_smooth", nf, "u1")
    if sm.any():
        A["sm"] = sm
    if ne:
        sh = _get(me.edges, "use_edge_sharp", ne, "u1")
        if sh.any():
            A["sh"] = sh
        sd = _get(me.edges, "use_seam", ne, "u1")
        if sd.any():
            A["sd"] = sd
    uvs = []
    for u in me.uv_layers:
        A["uv:" + u.name] = _get(u.data, "uv", nl, "f4", 2)
        uvs.append([u.name, bool(u.active), bool(u.active_render)])
    if uvs:
        meta["uv"] = uvs
    cols, gen = [], []
    for a in me.attributes:
        n = a.name
        if n.startswith(".") or n in BUILTIN or a.domain not in DOMAINS or a.data_type not in GENERIC_TYPES:
            continue
        if a.data_type == "FLOAT2" and a.domain == "CORNER" and n in me.uv_layers:
            continue
        prop, width, dt = GENERIC_TYPES[a.data_type]
        cnt = {"POINT": nv, "EDGE": ne, "FACE": nf, "CORNER": nl}[a.domain]
        try:
            arr = _get(a.data, prop, cnt, dt, width)
        except (RuntimeError, TypeError, ValueError):
            continue
        key = "a:" + n
        A[key] = arr
        (cols if a.data_type in COLOR_TYPES else gen).append([n, a.domain, a.data_type])
    if cols:
        meta["col"] = cols
    if gen:
        meta["gen"] = gen
    ca = getattr(me.color_attributes, "active_color_name", None)
    if cols and ca:
        meta["cact"] = ca
    try:
        if me.has_custom_normals and nl:
            cn = np.empty(nl * 3, "f4")
            me.corner_normals.foreach_get("vector", cn)
            A["cn"] = cn
    except (AttributeError, RuntimeError, TypeError):
        pass
    return Cap(meta, A)


def pack(cap):
    index, off, parts = [], 0, []
    for k, a in cap.arrays.items():
        a = np.ascontiguousarray(a)
        b = a.tobytes()
        index.append([k, a.dtype.str, int(a.size), off])
        off += len(b)
        parts.append(b)
    head = json.dumps({"m": cap.meta, "a": index}, separators=(",", ":")).encode()
    raw = struct.pack("<I", len(head)) + head + b"".join(parts)
    return MAGIC + base64.b64encode(zlib.compress(raw, 1)).decode("ascii")


class Bad(ValueError):
    pass


def unpack(txt):
    if not isinstance(txt, str) or not txt.startswith(MAGIC):
        raise Bad("not a SilverWood v2 mesh")
    try:
        raw = zlib.decompress(base64.b64decode(txt[len(MAGIC):]))
        (hl,) = struct.unpack_from("<I", raw, 0)
        head = json.loads(raw[4:4 + hl])
        body = memoryview(raw)[4 + hl:]
        meta, A = head["m"], {}
        for k, dt, cnt, off in head["a"]:
            dt = np.dtype(dt)
            if dt.kind not in "fiu" or cnt < 0 or off < 0 or off + cnt * dt.itemsize > len(body):
                raise Bad("bad array")
            A[str(k)] = np.frombuffer(body, dtype=dt, count=cnt, offset=off)
    except Bad:
        raise
    except Exception as e:
        raise Bad(f"mesh decode failed: {e}") from None
    _check(meta, A)
    return Cap(meta, A)


def _check(meta, A):
    try:
        nv, ne, nf, nl = (int(meta[k]) for k in ("nv", "ne", "nf", "nl"))
    except (KeyError, TypeError, ValueError):
        raise Bad("bad counts") from None
    if not (0 <= nv <= MAX_VERTS and 0 <= nl <= MAX_LOOPS and 0 <= ne <= 3 * MAX_VERTS and 0 <= nf <= nl):
        raise Bad("mesh too large")
    want = {"p": nv * 3, "e": ne * 2, "o": nf, "c": nl}
    for k, n in want.items():
        if k not in A or A[k].size != n:
            raise Bad(f"array {k} has wrong size")
    if nv and (A["p"].dtype.kind != "f" or not np.isfinite(A["p"]).all()):
        raise Bad("bad positions")
    if nl and (A["c"].min() < 0 or A["c"].max() >= nv):
        raise Bad("corner index out of range")
    if ne and (A["e"].min() < 0 or A["e"].max() >= nv):
        raise Bad("edge index out of range")
    if nf:
        o = A["o"]
        if o[0] != 0 or o[-1] >= nl or (np.diff(o) < 3).any() or nl - o[-1] < 3:
            raise Bad("bad face layout")
    elif nl:
        raise Bad("corners without faces")
    for k, n in (("mi", nf), ("sm", nf), ("sh", ne), ("sd", ne), ("cn", nl * 3)):
        if k in A and A[k].size != n:
            raise Bad(f"array {k} has wrong size")
    for name, *_ in meta.get("uv", []):
        if ("uv:" + str(name)) not in A or A["uv:" + str(name)].size != nl * 2:
            raise Bad("bad uv layer")


def _count(meta, dom):
    return {"POINT": meta["nv"], "EDGE": meta["ne"], "FACE": meta["nf"], "CORNER": meta["nl"]}[dom]


def build(me, cap):
    m, A = cap.meta, cap.arrays
    nv, ne, nf, nl = m["nv"], m["ne"], m["nf"], m["nl"]
    me.clear_geometry()
    me.vertices.add(nv)
    me.edges.add(ne)
    me.loops.add(nl)
    me.polygons.add(nf)
    if nv:
        me.vertices.foreach_set("co", A["p"])
    if ne:
        me.edges.foreach_set("vertices", A["e"])
    if nf:
        me.polygons.foreach_set("loop_start", A["o"])
        me.polygons.foreach_set("vertices", A["c"])
    me.update(calc_edges=bool(nf), calc_edges_loose=bool(ne))
    if nf:
        if "mi" in A:
            me.polygons.foreach_set("material_index", A["mi"].astype("i4"))
        me.polygons.foreach_set("use_smooth", A["sm"].astype(bool) if "sm" in A else np.zeros(nf, bool))
    if ne and "sh" in A and me.edges.__len__() == ne:
        me.edges.foreach_set("use_edge_sharp", A["sh"].astype(bool))
    if ne and "sd" in A and len(me.edges) == ne:
        me.edges.foreach_set("use_seam", A["sd"].astype(bool))
    for name, act, ren in m.get("uv", []):
        layer = me.uv_layers.new(name=str(name)[:63], do_init=False)
        if layer is None:
            break
        layer.data.foreach_set("uv", A["uv:" + str(name)])
        if act:
            me.uv_layers.active = layer
        if ren:
            layer.active_render = True
    for kind in ("col", "gen"):
        for name, dom, dt in m.get(kind, []):
            arr = A.get("a:" + str(name))
            if arr is None or dom not in DOMAINS or dt not in GENERIC_TYPES:
                continue
            prop, width, _ = GENERIC_TYPES[dt]
            if arr.size != _count(m, dom) * width:
                continue
            try:
                at = me.attributes.new(str(name)[:63], dt, dom)
                at.data.foreach_set(prop, arr)
            except (RuntimeError, TypeError, ValueError):
                continue
    if m.get("cact"):
        try:
            me.color_attributes.active_color_name = m["cact"]
        except (AttributeError, RuntimeError, TypeError):
            pass
    if "cn" in A and nl:
        try:
            me.normals_split_custom_set(A["cn"].reshape(-1, 3).tolist())
        except (AttributeError, RuntimeError, TypeError, ValueError):
            pass
    me.update()
    me.validate()
