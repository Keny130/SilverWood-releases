"""Host-side data store: a tiny in-memory server speaking the Firebase-REST subset SilverWood uses.

The host's Blender runs this; every client (including the host itself) talks to it with net.Client.
Supports GET/PUT/PATCH(multi-path)/DELETE on <path>.json, orderBy="$key" + startAt/endAt, ".sv" timestamps.
Storage is host RAM: no per-file size limit. Requests need ?auth=<token>.
"""
import hmac
import json
import threading
import time
import urllib.parse
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

MAX_BODY = 512 * 1024 * 1024


def _sv(x):
    if isinstance(x, dict):
        if x == {".sv": "timestamp"}:
            return int(time.time() * 1000)
        return {k: _sv(v) for k, v in x.items() if v is not None}
    return x


class Store:
    def __init__(self):
        self.db = {}

    def get(self, path):
        n = self.db
        for p in path:
            if not isinstance(n, dict) or p not in n:
                return None
            n = n[p]
        return None if n == {} else n

    def put(self, path, val):
        val = _sv(val)
        if not path:
            self.db = val if isinstance(val, dict) else {}
            return
        n = self.db
        for p in path[:-1]:
            if val is None:
                n = n.get(p)
                if not isinstance(n, dict):
                    return
            else:
                if not isinstance(n.get(p), dict):
                    n[p] = {}
                n = n[p]
        if val is None:
            n.pop(path[-1], None)
        else:
            n[path[-1]] = val


class Control:
    """Host-only moderation. The host's Blender calls these directly (same process as the server);
    no HTTP route can reach them, and HTTP writes to `perms` are refused.

    Identity is the `uid` (per join) and `cid` (per install) query parameters every client sends.
    That is cooperative security for a friends-only tool: it stops the normal add-on, not someone
    who rewrites it. The host PC is what enforces it (clients cannot skip it).
    """

    def __init__(self, store, lock):
        self.store, self.lock = store, lock
        self.kicked, self.banned, self.seen, self.cids = set(), set(), set(), {}
        self.locked = False

    def _host(self):
        h = self.store.get(["sessions", "main", "host"])
        return h if isinstance(h, str) else ""

    def _perms(self):
        p = self.store.get(["sessions", "main", "perms"])
        return p if isinstance(p, dict) else {}

    def _role(self, uid):
        p = self._perms()
        return "view" if (p.get(uid) or p.get("_default") or "edit") == "view" else "edit"

    def admit(self, uid, cid, write, targets):
        """Called by the request handler with the lock held. Returns None, or the refusal reason."""
        host = self._host()
        if uid and uid == host:
            self.cids[uid] = cid
            self.seen.add(uid)
            return None
        if uid in self.kicked or (cid and cid in self.banned):
            return "kicked"
        if uid and uid not in self.seen:
            if self.locked and host:
                return "locked"
            self.seen.add(uid)
        if uid:
            self.cids[uid] = cid
        if write and host:
            for t in targets:
                if len(t) <= 2 or t[2] == "perms":
                    return "host only"
            if self._role(uid) == "view" and any(t[2:4] not in (["members", uid], ["pfps", uid]) and t[2:3] != ["chat"] for t in targets):
                return "view-only"
        return None

    def roles(self):
        with self.lock:
            return dict(self._perms())

    def state(self):
        """(locked, default role, number of kicked installs)"""
        with self.lock:
            return self.locked, self._perms().get("_default") or "edit", len(self.banned) + len(self.kicked)

    def set_role(self, uid, role):
        with self.lock:
            if uid and uid != self._host():
                self.store.put(["sessions", "main", "perms", uid], "view" if role == "view" else "edit")

    def set_default(self, role):
        with self.lock:
            self.store.put(["sessions", "main", "perms", "_default"], "view" if role == "view" else None)

    def lock_joins(self, on):
        with self.lock:
            self.locked = bool(on)

    def kick(self, uid):
        """Remove a user. Their next request is refused, and so is their install (cid) unless it is the host's own PC."""
        with self.lock:
            host = self._host()
            if not uid or uid == host:
                return False
            self.kicked.add(uid)
            cid = self.cids.get(uid)
            if cid and cid != self.cids.get(host):
                self.banned.add(cid)
            for sub in ("members", "pfps", "perms"):
                self.store.put(["sessions", "main", sub, uid], None)
            return True

    def clear_kicks(self):
        with self.lock:
            self.kicked.clear()
            self.banned.clear()


def start(port, token):
    """Start serving on 0.0.0.0:port. Returns the server (call shutdown() + server_close() to stop)."""
    store, lock = Store(), threading.Lock()
    ctl = Control(store, lock)

    class H(BaseHTTPRequestHandler):
        def log_message(self, *a):
            pass

        def reply(self, code, obj):
            data = json.dumps(obj).encode()
            self.send_response(code)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(data)))
            self.end_headers()
            self.wfile.write(data)

        def handle_any(self):
            u = urllib.parse.urlparse(self.path)
            q = urllib.parse.parse_qs(u.query)
            if not hmac.compare_digest(q.get("auth", [""])[0], token):
                return self.reply(401, {"error": "Permission denied"})
            n = int(self.headers.get("Content-Length") or 0)
            if n > MAX_BODY or not u.path.endswith(".json"):
                return self.reply(400, {"error": "Bad request"})
            try:
                body = json.loads(self.rfile.read(n)) if n else None
            except ValueError:
                return self.reply(400, {"error": "Bad JSON"})
            path = [p for p in urllib.parse.unquote(u.path[:-5]).split("/") if p]
            m = self.command
            uid, cid = q.get("uid", [""])[0][:32], q.get("cid", [""])[0][:40]
            if m == "PATCH" and isinstance(body, dict):
                targets = [path + [p for p in k.split("/") if p] for k in body]
            else:
                targets = [path] if m != "GET" else []
            with lock:
                why = ctl.admit(uid, cid, m != "GET", targets)
                if why is None:
                    if m == "PUT":
                        store.put(path, body)
                    elif m == "PATCH" and isinstance(body, dict):
                        for k, v in body.items():
                            store.put(path + [p for p in k.split("/") if p], v)
                    elif m == "DELETE":
                        store.put(path, None)
                    out = store.get(path) if m == "GET" else body
                    if m == "GET" and "orderBy" in q and isinstance(out, dict):
                        try:
                            lo = json.loads(q["startAt"][0]) if "startAt" in q else ""
                            hi = json.loads(q["endAt"][0]) if "endAt" in q else "\U0010ffff"
                        except ValueError:
                            why, out = "bad query", None
                        else:
                            out = {k: v for k, v in out.items() if lo <= k <= hi}
                    data = json.dumps(out)
            if why is not None:
                return self.reply(400 if why == "bad query" else 403, {"error": why})
            self._raw(data)

        def _raw(self, data):
            b = data.encode()
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(b)))
            self.end_headers()
            self.wfile.write(b)

        do_GET = do_PUT = do_PATCH = do_DELETE = handle_any

    try:
        srv = ThreadingHTTPServer(("0.0.0.0", port), H)
    except OSError as e:
        raise ValueError(f"Cannot open port {port}: {e}") from None
    srv.daemon_threads = True
    srv.ctl = ctl
    threading.Thread(target=srv.serve_forever, kwargs={"poll_interval": 0.1}, daemon=True, name="SilverWood-host").start()
    return srv
