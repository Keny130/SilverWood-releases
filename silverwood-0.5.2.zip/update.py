"""SilverWood self-update: check for a newer version, download it, and report progress for notifications.

The update source is a small JSON document, either:
  * a Firebase node  {"version": "0.4.0", "url": "https://.../silverwood-0.4.0.zip", "sha256": "...", "notes": "..."}
  * or a Blender extension repo index.json (the entry with id "silverwood" is used).
Blank "Update URL" in preferences = the built-in DEFAULT_UPDATE_URL (GitHub Pages index.json)
"""
import hashlib
import json
import os
import tempfile
import threading
import time
import types
import urllib.parse
import urllib.request

import bpy

VERSION = "0.5.2"
PKG_ID = "silverwood"
DEFAULT_UPDATE_URL = "https://keny130.github.io/SilverWood-releases/index.json"

# state: idle | checking | uptodate | available | downloading | downloaded | installed | error
STATE = types.SimpleNamespace(state="idle", latest="", url="", sha256="", notes="", msg="", pct=0.0,
                              path="", toast_until=0.0, silent=True)
_lock = threading.Lock()


def vtuple(v):
    out = []
    for p in str(v).strip().lstrip("vV").split("."):
        digits = "".join(ch for ch in p if ch.isdigit())
        out.append(int(digits) if digits else 0)
    return tuple(out)


def is_newer(latest, current=VERSION):
    a, b = vtuple(latest), vtuple(current)
    n = max(len(a), len(b))
    return a + (0,) * (n - len(a)) > b + (0,) * (n - len(b))


def parse(doc, src_url):
    """Return (version, url, sha256, notes) from a Firebase node or a Blender index.json."""
    if isinstance(doc, dict) and isinstance(doc.get("data"), list):
        e = next((d for d in doc["data"] if d.get("id") == PKG_ID), None)
        if not e:
            raise ValueError("silverwood not found in index.json")
        h = str(e.get("archive_hash", ""))
        return (e["version"], urllib.parse.urljoin(src_url, e["archive_url"]),
                h.split(":", 1)[-1] if h else "", e.get("notes", e.get("tagline", "")))
    if isinstance(doc, dict) and doc.get("version") and doc.get("url"):
        return (doc["version"], urllib.parse.urljoin(src_url, doc["url"]),
                str(doc.get("sha256", "")).split(":", 1)[-1], str(doc.get("notes", "")))
    raise ValueError("update document has no version/url")


def _prefs():
    return bpy.context.preferences.addons[__package__].preferences


def source_url():
    p = _prefs()
    return (p.update_url or "").strip() or DEFAULT_UPDATE_URL


def _set(**kw):
    with _lock:
        for k, v in kw.items():
            setattr(STATE, k, v)


def check(silent=True):
    """Background check. silent=True keeps 'up to date' / error quiet (startup check)."""
    if STATE.state in ("checking", "downloading"):
        return
    try:
        url = source_url()
    except Exception:
        return
    _set(state="checking", msg="Checking for updates...", silent=silent)

    def run():
        try:
            req = urllib.request.Request(url, headers={"User-Agent": "SilverWood/" + VERSION})
            with urllib.request.urlopen(req, timeout=10) as r:
                doc = json.loads(r.read().decode("utf-8"))
            ver, dl, sha, notes = parse(doc, url)
            if is_newer(ver):
                _set(state="available", latest=str(ver), url=dl, sha256=sha, notes=notes,
                     msg=f"Update {ver} available", toast_until=time.time() + 12)
            else:
                _set(state="uptodate", latest=str(ver), msg=f"SilverWood {VERSION} is up to date")
        except Exception as e:
            _set(state="error", msg=f"Update check failed: {e}")
        _kick()

    threading.Thread(target=run, daemon=True, name="SilverWood-update-check").start()


def download():
    """Download the new zip in a background thread, verifying sha256 if the source gave one."""
    if STATE.state not in ("available", "error") or not STATE.url:
        return
    url, sha = STATE.url, STATE.sha256.lower()
    _set(state="downloading", pct=0.0, msg=f"Downloading SilverWood {STATE.latest}...", silent=False)

    def run():
        try:
            fn = os.path.basename(urllib.parse.urlparse(url).path) or f"silverwood-{STATE.latest}.zip"
            path = os.path.join(tempfile.gettempdir(), fn)
            h = hashlib.sha256()
            req = urllib.request.Request(url, headers={"User-Agent": "SilverWood/" + VERSION})
            with urllib.request.urlopen(req, timeout=20) as r, open(path, "wb") as f:
                total = int(r.headers.get("Content-Length") or 0)
                got = 0
                while True:
                    b = r.read(65536)
                    if not b:
                        break
                    f.write(b)
                    h.update(b)
                    got += len(b)
                    if total:
                        _set(pct=got / total)
            if sha and h.hexdigest().lower() != sha:
                os.remove(path)
                raise ValueError("checksum mismatch, download discarded")
            _set(state="downloaded", pct=1.0, path=path, msg=f"SilverWood {STATE.latest} downloaded",
                 toast_until=time.time() + 15)
        except Exception as e:
            _set(state="error", msg=f"Download failed: {e}")
        _kick()

    threading.Thread(target=run, daemon=True, name="SilverWood-update-dl").start()
    _kick()


def install():
    """Main-thread install of the downloaded zip via Blender's extension installer."""
    if STATE.state != "downloaded" or not os.path.isfile(STATE.path):
        return False
    try:
        bpy.ops.extensions.package_install_files(filepath=STATE.path, repo="user_default",
                                                 enable_on_install=True, overwrite=True)
        _set(state="installed", msg="Installed. Restart Blender to finish updating.",
             toast_until=time.time() + 20)
        return True
    except Exception as e:
        _set(msg=f"Saved to {STATE.path}. Auto-install failed ({e}); drag the zip into Blender.",
             toast_until=time.time() + 20)
        return False


def toast_active():
    return STATE.state == "downloading" or (
        STATE.state in ("available", "downloaded", "installed") and time.time() < STATE.toast_until)


def toast_text():
    s = STATE
    if s.state == "downloading":
        return f"Downloading SilverWood {s.latest}", f"{int(s.pct * 100)}%", s.pct
    if s.state == "available":
        return "SilverWood update available", f"{VERSION} -> {s.latest}  (open About / Setup or the panel)", None
    if s.state == "downloaded":
        return f"SilverWood {s.latest} downloaded", "Click Install Update in the SilverWood panel", None
    return "SilverWood updated", "Restart Blender to finish", None


def status_label():
    """Short text for the status bar, '' when nothing to say."""
    s = STATE
    if s.state == "downloading":
        return f"SilverWood: downloading {s.latest} ({int(s.pct * 100)}%)"
    if s.state == "available":
        return f"SilverWood: update {s.latest} available"
    if s.state == "downloaded":
        return f"SilverWood: {s.latest} ready to install"
    if s.state == "installed":
        return "SilverWood: restart Blender to finish update"
    return ""


def _kick():
    """Redraw from a thread-safe timer so notifications repaint."""
    def f():
        for w in bpy.context.window_manager.windows:
            for a in w.screen.areas:
                a.tag_redraw()
        return 0.4 if (STATE.state == "downloading" or toast_active()) else None
    try:
        bpy.app.timers.register(f, first_interval=0.1)
    except Exception:
        pass


def statusbar_draw(self, ctx):
    t = status_label()
    if t:
        self.layout.label(text=t, icon='IMPORT' if STATE.state == "downloading" else 'INFO')


def register():
    bpy.types.STATUSBAR_HT_header.append(statusbar_draw)


def unregister():
    try:
        bpy.types.STATUSBAR_HT_header.remove(statusbar_draw)
    except Exception:
        pass
