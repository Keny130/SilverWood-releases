"""SilverWood interface: sidebar panels, operators, viewport overlays (GPU + blf)."""
import base64
import json
import math
import os
import time

import blf
import bpy
import gpu
from bpy.props import BoolProperty, CollectionProperty, FloatVectorProperty, IntProperty, StringProperty
from bpy_extras.view3d_utils import location_3d_to_region_2d
from gpu_extras.batch import batch_for_shader
from mathutils import Vector

from . import inputs, sync, tunnel, update
from .sync import ERRORS, S, hex2rgb

STATUS = {
    "connected": ("Connected", "LINKED"),
    "connecting": ("Connecting", "SORTTIME"),
    "disconnected": ("Disconnected", "UNLINKED"),
    "error": ("Error", "ERROR"),
}


def _get_color(self):
    c = self.get("c")
    return tuple(c) if c is not None else (0.6, 0.6, 0.6)


class SW_Member(bpy.types.PropertyGroup):
    color: FloatVectorProperty(subtype='COLOR_GAMMA', size=3, min=0.0, max=1.0, get=_get_color)
    online: BoolProperty()
    host: BoolProperty()
    me: BoolProperty()
    activity: StringProperty()


class SW_OT_create_world(bpy.types.Operator):
    bl_idname, bl_label = "silverwood.create_world", "Host Worldwide"
    bl_description = ("This PC is the server (unlimited size) and a public tunnel makes it reachable anywhere. "
                      "Needs cloudflared or OpenSSH on the host only")

    def execute(self, ctx):
        try:
            sync.start("tunnel")
        except (ValueError, OSError) as e:
            self.report({'ERROR'}, str(e))
            return {'CANCELLED'}
        return {'FINISHED'}


class SW_OT_create(bpy.types.Operator):
    bl_idname, bl_label = "silverwood.create", "Host via Firebase"
    bl_description = "Host through the Firebase database (small scenes, short code)"

    def execute(self, ctx):
        try:
            sync.start("online")
        except (ValueError, OSError) as e:
            self.report({'ERROR'}, str(e))
            return {'CANCELLED'}
        return {'FINISHED'}


class SW_OT_create_local(bpy.types.Operator):
    bl_idname, bl_label = "silverwood.create_local", "Host on LAN / VPN"
    bl_description = "This PC becomes the server (LAN or VPN, no size limit). Friends join with the long code"

    def execute(self, ctx):
        try:
            sync.start("local")
        except (ValueError, OSError) as e:
            self.report({'ERROR'}, str(e))
            return {'CANCELLED'}
        return {'FINISHED'}


class SW_OT_join(bpy.types.Operator):
    bl_idname, bl_label = "silverwood.join", "Join Session"
    bl_description = "Join using the code typed above (any host type)"

    def execute(self, ctx):
        try:
            sync.start("join", ctx.window_manager.sw_join_id)
        except ValueError as e:
            self.report({'ERROR'}, str(e))
            return {'CANCELLED'}
        return {'FINISHED'}


class SW_OT_leave(bpy.types.Operator):
    bl_idname, bl_label = "silverwood.leave", "Leave Session"
    bl_description = "Disconnect from the session"

    wipe: BoolProperty(default=False, options={'HIDDEN', 'SKIP_SAVE'})

    def invoke(self, ctx, ev):
        # hosts keep their own scene; anyone who only joined has the scene wiped on leave
        self.wipe = bool(sync.S.worker is not None and sync.S.worker.mode == "join")
        return ctx.window_manager.invoke_props_dialog(self, width=380, title="Leave Session", confirm_text="Yes, Leave")

    def draw(self, ctx):
        c = self.layout.column()
        c.label(text="Are you sure you want to leave?")
        if self.wipe:
            c.separator()
            b = c.column(align=True)
            b.alert = True
            b.label(text="Your scene will be cleared first: every object", icon='ERROR')
            b.label(text="and model from this session is deleted from this file.")
            c.label(text="Save a copy first if you want to keep anything.")
        else:
            c.label(text="You are the host: your scene is kept.")

    def execute(self, ctx):
        wipe = self.wipe
        sync.stop()  # disconnect first so the clean-up is never broadcast to the others
        if wipe:
            sync.wipe_scene()
            self.report({'INFO'}, "Left the session and cleared the scene")
        return {'FINISHED'}


class SW_OT_refresh(bpy.types.Operator):
    bl_idname, bl_label = "silverwood.refresh", "Refresh"
    bl_description = "Re-download the shared scene state from the host (remote wins over older local edits)"

    def execute(self, ctx):
        if S.worker:
            S.worker.resync = True
        return {'FINISHED'}


class SW_OT_new_code(bpy.types.Operator):
    bl_idname, bl_label = "silverwood.new_code", "New Code"
    bl_description = "Generate a new private code for this file (use after copying a .blend, or to lock out old joiners)"

    def execute(self, ctx):
        sync.new_secret()
        return {'FINISHED'}


class SW_OT_copy_id(bpy.types.Operator):
    bl_idname, bl_label = "silverwood.copy_id", "Copy Code"
    bl_description = "Copy your private code"

    def execute(self, ctx):
        if S.tunnel is not None and not S.code:
            self.report({'WARNING'}, "Tunnel is still starting, try again in a few seconds")
            return {'CANCELLED'}
        ctx.window_manager.clipboard = S.code or sync.online_code()
        self.report({'INFO'}, "Code copied")
        return {'FINISHED'}


class SW_OT_copy_lan(bpy.types.Operator):
    bl_idname, bl_label = "silverwood.copy_lan", "Copy LAN/VPN Code"
    bl_description = "Copy the long code for 'Host on This PC'"

    def execute(self, ctx):
        ctx.window_manager.clipboard = sync.host_code()
        self.report({'INFO'}, "LAN/VPN code copied")
        return {'FINISHED'}


class SW_OT_setup_tunnel(bpy.types.Operator):
    bl_idname, bl_label = "silverwood.setup_tunnel", "One-Click Setup"
    bl_description = "Install the free tunnel tool (cloudflared) that lets Host Worldwide reach the internet"

    def execute(self, ctx):
        tunnel.setup()
        _poll_setup()
        return {'FINISHED'}


def _poll_setup():
    """Keep redrawing while the background setup runs."""
    def tick():
        sync.redraw()
        return 0.5 if tunnel.SETUP.state == "running" else None
    bpy.app.timers.register(tick, first_interval=0.3)


ACCENT, PURPLE, BG = (1.0, 0.53, 0.0), (0.42, 0.32, 0.60), (0.06, 0.06, 0.07)
_sp = {}
_tex = {}


def _logo():
    if "t" not in _tex:
        try:
            img = bpy.data.images.load(os.path.join(os.path.dirname(__file__), "logo.png"))
            _tex["t"], _tex["wh"] = gpu.texture.from_image(img), tuple(img.size)
            bpy.data.images.remove(img)
        except Exception:
            _tex["t"], _tex["wh"] = None, (1100, 474)
    return _tex["t"], _tex["wh"]


def _rect(x, y, w, h, col, outline=False):
    sh = gpu.shader.from_builtin('UNIFORM_COLOR')
    sh.bind()
    sh.uniform_float("color", col)
    batch_for_shader(sh, 'LINE_LOOP' if outline else 'TRI_FAN', {"pos": ((x, y), (x + w, y), (x + w, y + h), (x, y + h))}).draw(sh)


def _text(s, x, y, size, col, center_w=0):
    blf.size(0, size)
    blf.color(0, *col)
    if center_w:
        x += (center_w - blf.dimensions(0, s)[0]) / 2
    blf.position(0, x, y, 0)
    blf.draw(0, s)


VERSION = update.VERSION
PAGES = [
    ("Hosting a session", [
        "Host Worldwide: your PC is the server, no size limit, reachable from anywhere. Needs the free tunnel tool (One-Click Setup).",
        "Host via Firebase: short 8-character code, good for small scenes, no tunnel needed.",
        "Host on LAN / VPN: same Wi-Fi or VPN, no tunnel needed.",
        "After hosting press Copy Code and send it to your friends.",
        "Worldwide and LAN sessions end when the host closes Blender."]),
    ("Joining a session", [
        "Install SilverWood and open the same .blend file as the host.",
        "Open the SilverWood tab in the sidebar (press N), paste the code and press Join Session.",
        "The type of code is detected automatically.",
        "A wrong code or an unreachable host gives a clear message.",
        "Joiners need no extra setup."]),
    ("What gets shared", [
        "Mesh and empty objects: create, delete, duplicate, rename, move, rotate, scale, hide and parent.",
        "Mesh edits appear when the editor leaves Edit Mode.",
        "Other players' viewport cameras, 3D cursors and selections, drawn in their color.",
        "Pick your own color: click your swatch under Online Members. Everyone sees it.",
        "Rigs and skinning: vertex groups and weights, shape keys, constraints, bone settings and collections, drivers. Also materials and shader nodes.",
        "Joining never overwrites the host: your scene settings are only sent after you change them.",
        "Not shared yet: collections, group nodes, the current frame."]),
    ("Account and menu", [
        "Press Account on this screen, or the cube icon at the bottom left of the 3D viewport (click its arrow to open it).",
        "Display name: this only changes your SilverWood name. Your PC name is never touched. Blank = PC login name.",
        "Profile picture: shown next to your name in the viewport, only when the host runs the session on their PC. Firebase never shows pictures.",
        "Settings: camera opacity for everyone or per user, hide pictures, hide usernames.",
        "Host tools (sessions hosted on a PC): kick users, make users view-only, lock the session."]),
    ("Tips and fixes", [
        "Reinstalled the add-on? Close Blender completely and reopen it first.",
        "Tunnel did not start? Press One-Click Setup, or install cloudflared or OpenSSH.",
        "Press Refresh to re-download the scene from the host.",
        "New Code locks out anyone who had your old code.",
        "Anyone with a code has full access. Share it only with people you trust."]),
    ("About SilverWood", [
        f"SilverWood {VERSION} - Blender Co Op Addon.",
        "Real-time multiplayer for Blender scenes, built for Blender 4.4 and newer.",
        "Your PC can be the server, so scene size is not limited by a cloud database.",
        "Use the About / Setup button at the top of the SilverWood panel to open this screen again."]),
]


def _wrap(s, size, maxw):
    blf.size(0, size)
    lines, cur = [], ""
    for word in s.split():
        t = (cur + " " + word).strip()
        if cur and blf.dimensions(0, t)[0] > maxw:
            lines.append(cur)
            cur = word
        else:
            cur = t
    return lines + [cur]


def _btn(name, label, x, y, w, h, col, k):
    hov = _sp.get("hover") == name
    _rect(x, y, w, h, (*[c * (1.0 if hov else 0.55) for c in col], k))
    _text(label, x, y + 13, 16, (1, 1, 1, k) if hov else (0.92, 0.92, 0.92, k), w)
    _sp["btns"][name] = (x, y, w, h)


def draw_splash():
    r = bpy.context.region
    if not _sp or r is None or (r.x, r.y) != _sp["origin"]:
        return
    k = min(1.0, (time.time() - _sp["t0"]) / 0.35)
    page = _sp["page"]
    gpu.state.blend_set('ALPHA')
    _rect(0, 0, r.width, r.height, (0, 0, 0, 0.62 * k))
    w, h = min(820, r.width - 40), min(590, r.height - 40)
    x, y = (r.width - w) / 2, (r.height - h) / 2
    _rect(x, y, w, h, (*BG, k))
    _rect(x, y, w, h, (*PURPLE, k), outline=True)
    _rect(x, y + h - 4, w, 4, (*ACCENT, k))
    _sp["btns"] = {}
    bw, bh, gap = 190, 40, 14
    if page == 0:
        tex, (iw, ih) = _logo()
        lh = (w - 80) * ih / iw
        top = y + h - 24
        if tex:
            sh = gpu.shader.from_builtin('IMAGE')
            x0, y0 = x + 40, top - lh
            gpu.state.blend_set('ALPHA_PREMULT')
            sh.bind()
            sh.uniform_sampler("image", tex)
            batch_for_shader(sh, 'TRI_FAN', {"pos": ((x0, y0), (x0 + w - 80, y0), (x0 + w - 80, top), (x0, top)),
                                             "texCoord": ((0, 0), (1, 0), (1, 1), (0, 1))}).draw(sh)
            gpu.state.blend_set('ALPHA')
        else:
            _text("SilverWood", x, top - 60, 56, (0.8, 0.8, 0.8, k), w)
        ty = top - lh - 40
        name, wa = sync.my_name(), 0
        blf.size(0, 28)
        wa, wb = blf.dimensions(0, "Welcome, ")[0], blf.dimensions(0, name)[0]
        pic = bool(sync.MY["b64"])
        sx = x + (w - (wa + wb + (48 if pic else 0))) / 2
        if pic:
            _avatar_draw(sx, ty - 10, 38, sync.MY["b64"], "me", hex2rgb(S.color), name)
            sx += 48
        _text("Welcome, ", sx, ty, 28, (0.92, 0.92, 0.95, k))
        _text(name, sx + wa, ty, 28, (*ACCENT, k))
        _text("Blender Co Op Addon", x, ty - 30, 15, (0.75, 0.7, 0.85, k), w)
        txt, ok = tunnel.tool_status()
        st = tunnel.SETUP
        col = (1, 0.35, 0.35, k) if st.state == "error" else (0.55, 0.85, 0.55, k) if (ok or st.state == "done") else (1.0, 0.6, 0.3, k)
        _text(st.msg if st.state != "idle" else txt, x, ty - 62, 14, col, w)
        _text("Host Worldwide shares your scene with anyone, with unlimited size.", x, ty - 84, 13, (0.55, 0.55, 0.6, k), w)
        bw = 170
        bx, by = x + (w - 4 * bw - 3 * gap) / 2, y + 34
        _btn("setup", "Setup Running..." if st.state == "running" else "One-Click Setup" if not ok else "Re-check Setup", bx, by, bw, bh, ACCENT, k)
        _btn("account", "Account", bx + bw + gap, by, bw, bh, PURPLE, k)
        _btn("info", "Info", bx + 2 * (bw + gap), by, bw, bh, PURPLE, k)
        _btn("close", "Close", bx + 3 * (bw + gap), by, bw, bh, PURPLE, k)
        u = update.STATE
        pct = int(u.pct * 100)
        line, lcol = {
            "checking": ("Checking for updates...", (0.55, 0.55, 0.6, k)),
            "uptodate": (f"Version {VERSION} - up to date", (0.55, 0.85, 0.55, k)),
            "available": (f"Update available: {VERSION} -> {u.latest}", (*ACCENT, k)),
            "downloading": (f"Downloading {u.latest}... {pct}%", (*ACCENT, k)),
            "downloaded": (f"Update {u.latest} downloaded - ready to install", (0.55, 0.85, 0.55, k)),
            "installed": (f"Update {u.latest} installed - restart Blender", (0.55, 0.85, 0.55, k)),
            "error": (u.msg[:90], (1, 0.35, 0.35, k)),
        }.get(u.state, (f"Version {VERSION}", (0.55, 0.55, 0.6, k)))
        _text(line, x, y + 132, 15, lcol, w)
        if u.state in ("available", "downloaded", "downloading"):
            _btn("update", {"available": "Download Update", "downloaded": "Install Update"}.get(u.state, f"Downloading {pct}%"),
                 x + (w - 220) / 2, y + 84, 220, 36, ACCENT, k)
    else:
        title, bullets = PAGES[page - 1]
        _text(title, x + 40, y + h - 66, 26, (*ACCENT, k))
        _rect(x + 40, y + h - 80, w - 80, 1, (*PURPLE, k))
        ly, line_h, maxw = y + h - 112, 21, w - 120
        for b in bullets:
            lines = _wrap(b, 15, maxw)
            _rect(x + 40, ly + 4, 6, 6, (*ACCENT, k))
            for ln in lines:
                _text(ln, x + 60, ly, 15, (0.85, 0.85, 0.88, k))
                ly -= line_h
            ly -= 9
        last = page == len(PAGES)
        bx, by = x + (w - 3 * 160 - 2 * gap) / 2, y + 34
        _btn("back", "Home" if page == 1 else "< Back", bx, by, 160, bh, PURPLE, k)
        _btn("next", "Home" if last else "Next >", bx + 160 + gap, by, 160, bh, ACCENT, k)
        _btn("close", "Close", bx + 2 * (160 + gap), by, 160, bh, PURPLE, k)
    n = len(PAGES) + 1
    for p in range(n):
        _rect(x + (w - n * 16) / 2 + p * 16, y + 14, 8, 8, (*(ACCENT if p == page else PURPLE), k))
    gpu.state.blend_set('NONE')


class SW_OT_splash(bpy.types.Operator):
    bl_idname, bl_label = "silverwood.splash", "SilverWood"
    bl_description = "Show the SilverWood welcome, setup and info screen"
    page: IntProperty(default=0, min=0, max=len(PAGES))

    def invoke(self, ctx, ev):
        area = ctx.area if ctx.area and ctx.area.type == 'VIEW_3D' else next(
            (a for a in ctx.window.screen.areas if a.type == 'VIEW_3D'), None)
        reg = next((r for r in area.regions if r.type == 'WINDOW'), None) if area else None
        if _sp or reg is None:
            return {'CANCELLED'}
        _sp.update(t0=time.time(), origin=(reg.x, reg.y), hover=None, btns={}, page=self.page, ptr=area.as_pointer())
        self._h = bpy.types.SpaceView3D.draw_handler_add(draw_splash, (), 'WINDOW', 'POST_PIXEL')
        self._t = ctx.window_manager.event_timer_add(0.05, window=ctx.window)
        ctx.window_manager.modal_handler_add(self)
        return {'RUNNING_MODAL'}

    def _end(self, ctx):
        bpy.types.SpaceView3D.draw_handler_remove(self._h, 'WINDOW')
        ctx.window_manager.event_timer_remove(self._t)
        _sp.clear()
        sync.redraw()

    def modal(self, ctx, ev):
        if not _sp:
            self._end(ctx)
            return {'CANCELLED'}
        sync.redraw()
        n = len(PAGES)
        if ev.type in {'ESC', 'RIGHTMOUSE'} and ev.value == 'PRESS':
            self._end(ctx)
            return {'FINISHED'}
        if ev.type in {'RIGHT_ARROW', 'LEFT_ARROW'} and ev.value == 'PRESS':
            _sp["page"] = (_sp["page"] + (1 if ev.type == 'RIGHT_ARROW' else -1)) % (n + 1)
        if ev.type in {'MOUSEMOVE', 'LEFTMOUSE'}:
            mx, my = ev.mouse_x - _sp["origin"][0], ev.mouse_y - _sp["origin"][1]
            _sp["hover"] = next((nm for nm, (x, y, w, h) in _sp["btns"].items() if x <= mx <= x + w and y <= my <= y + h), None)
            if ev.type == 'LEFTMOUSE' and ev.value == 'PRESS':
                act, pg = _sp["hover"], _sp["page"]
                if act == "close":
                    self._end(ctx)
                    return {'FINISHED'}
                if act == "account":
                    ptr = _sp.get("ptr")
                    self._end(ctx)
                    open_menu("account", ptr)
                    return {'FINISHED'}
                if act == "update":
                    _update_action()
                elif act == "setup":
                    bpy.ops.silverwood.setup_tunnel()
                elif act == "info":
                    _sp["page"] = 1
                elif act == "back":
                    _sp["page"] = pg - 1
                elif act == "next":
                    _sp["page"] = 0 if pg == n else pg + 1
        return {'RUNNING_MODAL'}

    def cancel(self, ctx):
        if _sp:
            self._end(ctx)


def draw_inputs():
    inputs.draw(sync.my_name(), hex2rgb(S.color))


def _update_action():
    s = update.STATE
    if s.state in ("available", "error") and s.url:
        update.download()
    elif s.state == "downloaded":
        update.install()
    sync.redraw()


def draw_update_toast():
    r = bpy.context.region
    if r is None or not update.toast_active():
        return
    title, sub, frac = update.toast_text()
    w, h = 330, 66
    x, y = (r.width - w) / 2, r.height - h - 60
    gpu.state.blend_set('ALPHA')
    _rect(x, y, w, h, (*BG, 0.94))
    _rect(x, y, w, h, (*PURPLE, 1.0), outline=True)
    _rect(x, y + h - 3, w, 3, (*ACCENT, 1.0))
    _text(title, x + 14, y + h - 26, 16, (*ACCENT, 1.0))
    _text(sub, x + 14, y + 26, 13, (0.85, 0.85, 0.88, 1.0))
    if frac is not None:
        _rect(x + 14, y + 10, w - 28, 6, (*PURPLE, 0.5))
        _rect(x + 14, y + 10, (w - 28) * max(0.02, frac), 6, (*ACCENT, 1.0))
    gpu.state.blend_set('NONE')


class SW_OT_update_check(bpy.types.Operator):
    bl_idname, bl_label = "silverwood.update_check", "Check for Updates"
    bl_description = "Look for a newer SilverWood version"

    def execute(self, ctx):
        update.check(silent=False)
        return {'FINISHED'}


class SW_OT_update_action(bpy.types.Operator):
    bl_idname, bl_label = "silverwood.update_action", "SilverWood Update"
    bl_description = "Download the new SilverWood version, then install it"

    def execute(self, ctx):
        _update_action()
        return {'FINISHED'}


def show_splash():
    """Open the splash on the first 3D viewport found (safe to call from a timer)."""
    for w in bpy.context.window_manager.windows:
        for a in w.screen.areas:
            reg = next((r for r in a.regions if r.type == 'WINDOW'), None)
            if a.type == 'VIEW_3D' and reg:
                with bpy.context.temp_override(window=w, area=a, region=reg):
                    bpy.ops.silverwood.splash('INVOKE_DEFAULT')
                return


TEAL, RED = (0.30, 0.71, 0.67), (0.78, 0.28, 0.28)
_av, _av_imgs = {}, []
_uop, _uop_state = {}, {"loaded": False}


def _prefs():
    try:
        return bpy.context.preferences.addons[__package__].preferences
    except Exception:
        return None


def _user_op(name):
    """Camera opacity override for one user (by username); None = follows the global slider."""
    if not _uop_state["loaded"]:
        p = _prefs()
        if p is None:
            return None
        try:
            _uop.update({str(k): float(v) for k, v in json.loads(p.user_opacity).items()})
        except Exception:
            pass
        _uop_state["loaded"] = True
    return _uop.get(name)


def _reset_user_ops():
    _user_op("")
    _uop.clear()
    p = _prefs()
    if p is not None:
        p.user_opacity = "{}"


def _set_user_op(name, v):
    _user_op(name)
    _uop[name] = round(v, 2)
    p = _prefs()
    if p is not None:
        p.user_opacity = json.dumps(_uop)


def cam_alpha(name):
    p, v = _prefs(), _user_op(name)
    return max(0.0, min(1.0, v if v is not None else (p.cam_opacity if p else 1.0)))


def _avatar(key, b64, side=None):
    """GPU texture for a base64 square RGBA picture (cached per key, rebuilt when the picture changes)."""
    if not b64:
        return None
    side = side or sync.AV
    c = _av.get(key)
    if c and c[0] == b64:
        return c[1]
    tex, n = None, side * side * 4
    try:
        raw = base64.b64decode(b64)
        if len(raw) == n:
            px = [b / 255 for b in raw]
            try:
                tex = gpu.types.GPUTexture((side, side), format='RGBA8', data=gpu.types.Buffer('FLOAT', n, px))
            except Exception:
                im = bpy.data.images.new(".sw_av_" + key, side, side, alpha=True)
                im.pixels.foreach_set(px)
                im.update()
                _av_imgs.append(im)
                tex = gpu.texture.from_image(im)
    except Exception:
        tex = None
    _av[key] = (b64, tex)
    return tex


def _cursor_img(b64, key, x, y, size):
    tex = _avatar("c:" + key, b64, sync.CUR)
    if not tex:
        return False
    sh = gpu.shader.from_builtin('IMAGE')
    gpu.state.blend_set('ALPHA_PREMULT')
    sh.bind()
    sh.uniform_sampler("image", tex)
    batch_for_shader(sh, 'TRI_FAN', {"pos": ((x, y), (x + size, y), (x + size, y + size), (x, y + size)),
                                     "texCoord": ((0, 0), (1, 0), (1, 1), (0, 1))}).draw(sh)
    gpu.state.blend_set('ALPHA')
    return True


def _avatar_draw(x, y, size, b64, key, col, name):
    tex = _avatar(key, b64)
    if tex:
        sh = gpu.shader.from_builtin('IMAGE')
        gpu.state.blend_set('ALPHA_PREMULT')
        sh.bind()
        sh.uniform_sampler("image", tex)
        batch_for_shader(sh, 'TRI_FAN', {"pos": ((x, y), (x + size, y), (x + size, y + size), (x, y + size)),
                                         "texCoord": ((0, 0), (1, 0), (1, 1), (0, 1))}).draw(sh)
        gpu.state.blend_set('ALPHA')
    else:
        _rect(x, y, size, size, (*[c * 0.55 for c in col], 1.0))
        _text((name[:1] or "?").upper(), x, y + size * 0.28, max(10, int(size * 0.5)), (1, 1, 1, 1), size)
    _rect(x, y, size, size, (*col, 1.0), outline=True)


def _lines(pts, col, width=2.0):
    sh = gpu.shader.from_builtin('UNIFORM_COLOR')
    sh.bind()
    sh.uniform_float("color", col)
    gpu.state.line_width_set(width)
    batch_for_shader(sh, 'LINES', {"pos": pts}).draw(sh)
    gpu.state.line_width_set(1.0)


def _poly(pts, col):
    sh = gpu.shader.from_builtin('UNIFORM_COLOR')
    sh.bind()
    sh.uniform_float("color", col)
    batch_for_shader(sh, 'TRI_FAN', {"pos": pts}).draw(sh)


def _cube(cx, cy, s, k=1.0):
    """The SilverWood cube icon: three shaded faces of an isometric cube."""
    d = 0.87 * s
    top, ur, lr, bot, ll, ul, mid = (cx, cy + s), (cx + d, cy + s / 2), (cx + d, cy - s / 2), (cx, cy - s), \
        (cx - d, cy - s / 2), (cx - d, cy + s / 2), (cx, cy)
    _poly((top, ur, mid, ul), (*ACCENT, k))
    _poly((ul, mid, bot, ll), (*PURPLE, k))
    _poly((mid, ur, lr, bot), (*TEAL, k))


def _tw(s, size):
    blf.size(0, size)
    return blf.dimensions(0, s)[0]


def _fit(s, size, maxw):
    if _tw(s, size) <= maxw:
        return s
    while s and _tw(s + "...", size) > maxw:
        s = s[:-1]
    return s + "..."


_geo, _hits, _live, _cur, _tlive = {}, {}, {}, {"ptr": None}, {}
_ui = dict(open=False, tab="account", area=None, exp=None, hover=None, drag=None, edit=None, text="", scroll=0)
_run = {"on": False}
TABS = (("account", "Account"), ("general", "General"), ("cursors", "Cursors"), ("users", "Users"), ("host", "Host"))
GREY, LIGHT = (0.6, 0.6, 0.65, 1.0), (0.88, 0.88, 0.9, 1.0)


def _hit(name, kind, x, y, w, h, extra=None):
    _hits[_cur["ptr"]].append((name, kind, (x, y, w, h), extra))


def _hov(name):
    return _ui["hover"] == (_cur["ptr"], name)


def _button(name, label, x, y, w, h, col, size=15, lit=False):
    k = 1.0 if (lit or _hov(name)) else 0.6
    _rect(x, y, w, h, (*[c * k for c in col], 1.0))
    _text(_fit(label, size, w - 8), x, y + (h - size * 0.72) / 2, size, (1, 1, 1, 1), w)
    _hit(name, "btn", x, y, w, h)


def _toggle(name, label, on, x, y, w):
    _rect(x, y, 20, 20, (0.16, 0.16, 0.18, 1))
    _rect(x, y, 20, 20, (*(ACCENT if _hov(name) else PURPLE), 1), outline=True)
    if on:
        _rect(x + 4, y + 4, 12, 12, (*ACCENT, 1))
    _text(label, x + 30, y + 4, 15, (1, 1, 1, 1) if _hov(name) else LIGHT)
    _hit(name, "btn", x, y, w, 22)


def _slider(name, label, val, x, y, w):
    _text(label, x, y + 20, 14, LIGHT)
    pct = f"{round(val * 100)}%"
    _text(pct, x + w - _tw(pct, 14), y + 20, 14, (*ACCENT, 1))
    _rect(x, y + 4, w, 8, (0.17, 0.17, 0.2, 1))
    _rect(x, y + 4, w * val, 8, (*ACCENT, 1))
    _rect(x + w * val - 4, y, 8, 16, (1, 1, 1, 1) if (_hov(name) or (_ui["drag"] and _ui["drag"][1] == name)) else (0.85, 0.85, 0.88, 1))
    _hit(name, "slider", x, y - 4, w, 28, (x, w))


def _field(name, text, hint, x, y, w, h):
    ed = _ui["edit"] == name
    _rect(x, y, w, h, (0.14, 0.14, 0.16, 1))
    _rect(x, y, w, h, (*(ACCENT if ed else PURPLE), 1), outline=True)
    s = _ui["text"] + ("|" if int(time.time() * 2) % 2 == 0 else " ") if ed else text
    _text(_fit(s or hint, 16, w - 16), x + 8, y + (h - 11) / 2, 16, (1, 1, 1, 1) if s else (0.5, 0.5, 0.55, 1))
    _hit(name, "text", x, y, w, h)


def _note(s, x, y, w, size=13, col=GREY):
    """Wrapped paragraph; returns the y below it."""
    for ln in _wrap(s, size, w):
        _text(ln, x, y, size, col)
        y -= size + 5
    return y - 5


def _tab_account(x, top, bottom, w):
    p = _prefs()
    name = p.username.strip() if p else ""
    _avatar_draw(x, top - 84, 84, sync.MY["b64"], "me", hex2rgb(S.color), sync.my_name())
    bx = x + 104
    _text("Display name", bx, top - 12, 13, GREY)
    _field("field:name", name, f"{sync.my_name()}  (PC login name)", bx, top - 50, min(330, w - 104), 32)
    _button("pfp:pick", "Choose Picture", bx, top - 92, 150, 32, PURPLE)
    _button("pfp:clear", "Remove", bx + 158, top - 92, 100, 32, PURPLE)
    _rect(x, top - 132, 32, 32, (0.17, 0.17, 0.2, 1))
    if not _cursor_img(sync.MY["cur"], "me", x, top - 132, 32):
        _text("none", x, top - 120, 11, GREY, 32)
    _button("cur:pick", "Choose Cursor", x + 44, top - 132, 150, 32, PURPLE)
    _button("cur:clear", "Remove", x + 202, top - 132, 100, 32, PURPLE)
    y = top - 148
    y = _note("Custom cursor: a transparent image (PNG, WebP, TGA...) others see instead of the arrow, top-left corner = pointer tip. "
              "GIFs only work if Blender can open them, and are not animated.", x, y, w)
    y = _note("This only changes your SilverWood name. Your PC or Windows name is never touched. Leave it blank to use your PC login name.", x, y, w)
    y = _note("Name changes apply right away, also while a session is running.", x, y, w)
    _note("Pictures and custom cursors show only when the host runs the session on their PC "
          "(Host Worldwide or Host on LAN / VPN). Firebase sessions never show them.", x, y, w)


def _tab_general(x, top, bottom, w):
    p = _prefs()
    if p is None:
        return
    y = top - 26
    _slider("sl:cam", "Camera opacity (all users)", p.cam_opacity, x, y, w)
    y = _note("Lower it when someone's viewport camera is in your way. A value set for one person in the Users tab overrides it for them.", x, y - 20, w)
    y -= 6
    _toggle("tog:hide_pfps", "Hide profile pictures", p.hide_pfps, x, y, w)
    _toggle("tog:hide_names", "Hide usernames", p.hide_names, x, y - 34, w)
    _toggle("tog:splash", "Show the welcome screen on new files", p.show_splash, x, y - 68, w)
    _button("reset:ops", "Reset per-user opacity", x, y - 120, 220, 32, PURPLE)


def _tab_cursors(x, top, bottom, w):
    p = _prefs()
    if p is None:
        return
    y = top - 26
    for i, (nm, label, on) in enumerate((
            ("tog:cursors", "Show other users' cursors", p.show_cursors),
            ("tog:switch_msg", "Show workspace switch messages", p.show_switch_msgs),
            ("tog:cur_pfp", "Show profile pictures on cursors", p.cursor_pfps),
            ("tog:cur_name", "Show usernames on cursors", p.cursor_names),
            ("tog:cur_mine", "Use my custom cursor (set in Account)", p.use_custom_cursor),
            ("tog:cur_theirs", "Show other users' custom cursors", p.show_custom_cursors))):
        _toggle(nm, label, on, x, y - 4 - 32 * i, w)
    _slider("sl:cur_op", "Cursor opacity", p.cursor_opacity, x, y - 232, w)
    _slider("sl:cur_size", "Cursor size (50% = normal)", p.cursor_size, x, y - 280, w)


def _tab_users(x, top, bottom, w):
    if S.worker is None:
        _note("Host or join a session to see the other users here.", x, top - 16, w)
        return
    people = [q for q in S.people if not q.me]
    if not people:
        _note("Nobody else is in the session yet.", x, top - 16, w)
        return
    c = sync.ctl()
    rowh = 66
    vis = max(1, int((top - bottom - 16) / rowh))
    _ui["scroll"] = max(0, min(_ui["scroll"], max(0, len(people) - vis)))
    for i, q in enumerate(people[_ui["scroll"]:_ui["scroll"] + vis]):
        ry = top - (i + 1) * rowh + 8
        rh = rowh - 8
        _rect(x, ry, w, rh, (0.13, 0.13, 0.15, 1))
        _avatar_draw(x + 8, ry + (rh - 40) / 2, 40, S.pfps.get(q.uid) if S.local else None, q.uid, q.color, q.name)
        nx = x + 58
        tag = (" (host)" if q.host else "") + ("" if q.online else " - offline")
        _text(_fit(q.name + tag, 16, 160), nx, ry + rh - 24, 16, (*q.color, 1))
        if sync.role_of(q.uid) == "view":
            _text("VIEW ONLY", nx, ry + rh - 42, 12, (1, 0.45, 0.4, 1))
        mine_op = _user_op(q.name)
        _slider("sl:u:" + q.name, "Camera opacity" + (" (custom)" if mine_op is not None else ""),
                mine_op if mine_op is not None else _prefs().cam_opacity, x + 232, ry + 14, 132)
        if c is not None and not q.host:
            kx = x + w - 8 - 52
            _button("kick:" + q.uid, "Kick", kx, ry + 16, 52, 28, RED, 13)
            if sync.role_of(q.uid) == "view":
                _button("role:" + q.uid, "View only", kx - 6 - 84, ry + 16, 84, 28, RED, 13)
            else:
                _button("role:" + q.uid, "Can edit", kx - 6 - 84, ry + 16, 84, 28, TEAL, 13)
    if len(people) > vis:
        _text(f"{_ui['scroll'] + 1}-{min(len(people), _ui['scroll'] + vis)} of {len(people)}  (mouse wheel to scroll)", x, bottom - 2, 12, GREY)


def _tab_host(x, top, bottom, w):
    c = sync.ctl()
    if S.worker is None:
        _note("Start a session to use the host options.", x, top - 16, w)
    elif S.host != S.uid:
        _note("Only the host can use these options.", x, top - 16, w)
    elif c is None:
        _note("Host options need Host Worldwide or Host on LAN / VPN: the host PC is what enforces them. "
              "Firebase sessions have no server of yours, so they cannot kick or restrict anyone.", x, top - 16, w)
    else:
        locked, default, nkick = c.state()
        y = top - 24
        _toggle("host:lock", "Lock session (nobody new can join)", locked, x, y, w)
        _toggle("host:default", "Everyone is view-only by default (also new joiners)", default == "view", x, y - 34, w)
        y = _note("View-only users can look around, but their edits are not sent and are rolled back on their side. "
                  "Set one person at a time in the Users tab.", x, y - 66, w)
        y = _note("Kick removes someone and blocks that install from rejoining until you clear the list or end the session. "
                  "New Code locks out everyone who has the old code.", x, y, w)
        _button("host:unban", f"Clear kick list ({nkick})", x, y - 36, 220, 32, PURPLE)


def _panel(r):
    pw, ph = min(600, r.width - 40), min(450, r.height - 110)
    px, py = (r.width - pw) / 2, r.height - 62 - ph
    _rect(px, py, pw, ph, (*BG, 0.97))
    _rect(px, py, pw, ph, (*PURPLE, 1), outline=True)
    _rect(px, py + ph - 4, pw, 4, (*ACCENT, 1))
    _hit("bg", "bg", px, py, pw, ph)
    _text("SilverWood", px + 24, py + ph - 42, 22, (*ACCENT, 1))
    _text("Settings", px + 24 + _tw("SilverWood", 22) + 12, py + ph - 40, 15, GREY)
    _button("close", "X", px + pw - 58, py + ph - 48, 34, 28, PURPLE)
    tw = (pw - 48 - 24) / 5
    for i, (key, label) in enumerate(TABS):
        _button("tab:" + key, label, px + 24 + i * (tw + 6), py + ph - 88, tw, 30, ACCENT if _ui["tab"] == key else PURPLE,
                lit=_ui["tab"] == key)
    top, bottom, w = py + ph - 106, py + 18, pw - 48
    {"account": _tab_account, "general": _tab_general, "cursors": _tab_cursors, "users": _tab_users, "host": _tab_host}[_ui["tab"]](px + 24, top, bottom, w)


def draw_launcher():
    c = bpy.context
    r, a = c.region, c.area
    if r is None or a is None:
        return
    ptr = a.as_pointer()
    _cur["ptr"] = ptr
    _geo[ptr] = (r.x, r.y, r.width, r.height)
    _hits[ptr] = []
    if _sp or not _run["on"]:
        return
    gpu.state.blend_set('ALPHA')
    exp = _ui["exp"] == ptr
    items = (("launch:settings", "Settings"), ("launch:account", "Account"), ("launch:welcome", "Welcome"))
    cy, x0, bw = 28, 12, 50
    w = bw + (4 + len(items) * 68 if exp else 0)
    _rect(x0, cy - 15, w, 30, (*BG, 0.82))
    _rect(x0, cy - 15, w, 30, (*PURPLE, 0.9), outline=True)
    hov = _hov("launcher")
    d = -3 if exp else 3
    _lines([(x0 + 11 - d, cy + 5), (x0 + 11 + d, cy), (x0 + 11 + d, cy), (x0 + 11 - d, cy - 5)],
           (*(ACCENT if hov else (0.8, 0.8, 0.85)), 1.0), 2.0)
    _cube(x0 + 32, cy, 9)
    st = sync.status()
    dot = (0.3, 0.85, 0.4) if st == "connected" else (1.0, 0.6, 0.2) if st == "connecting" else (0.9, 0.3, 0.3) if st == "error" else (0.5, 0.5, 0.55)
    _rect(x0 + 38, cy - 11, 5, 5, (*dot, 1.0))
    _hit("launcher", "btn", x0, cy - 15, bw, 30)
    if exp:
        for i, (nm, label) in enumerate(items):
            _button(nm, label, x0 + bw + 4 + i * 68, cy - 11, 64, 22, ACCENT if nm == "launch:settings" else PURPLE, 12)
    if S.worker is not None and S.worker.role == "view":
        _text("VIEW ONLY - the host turned your editing off", x0, cy + 22, 13, (1, 0.45, 0.4, 1), w)
    if _ui["open"] and _ui["area"] == ptr:
        _panel(r)
    gpu.state.blend_set('NONE')


def open_menu(tab="account", ptr=None):
    """Open the GPU settings menu on a tab (used by the welcome screen and the sidebar)."""
    if ptr is None:
        for w in bpy.context.window_manager.windows:
            for a in w.screen.areas:
                if a.type == 'VIEW_3D':
                    ptr = a.as_pointer()
                    break
            if ptr:
                break
    if ptr is None:
        return
    _ensure()
    _ui.update(open=True, tab=tab, area=ptr, exp=ptr, edit=None, text="", scroll=0)
    sync.redraw()


def _ensure():
    """Keep one launcher modal alive per 3D view (also after loading another .blend)."""
    try:
        now = time.time()
        for w in bpy.context.window_manager.windows:
            te = _tlive.get(w.as_pointer())
            if (te is None or now - te[1] > 3.0) and len(w.screen.areas):
                try:
                    a0 = w.screen.areas[0]
                    with bpy.context.temp_override(window=w, area=a0, region=a0.regions[0]):
                        bpy.ops.silverwood.track('INVOKE_DEFAULT')
                except Exception:
                    pass
            for a in w.screen.areas:
                reg = next((r for r in a.regions if r.type == 'WINDOW'), None) if a.type == 'VIEW_3D' else None
                ent = _live.get(a.as_pointer())
                if reg and (ent is None or now - ent[1] > 3.0):
                    with bpy.context.temp_override(window=w, area=a, region=reg):
                        bpy.ops.silverwood.launcher('INVOKE_DEFAULT')
        for k in [k for k, v in _live.items() if now - v[1] > 30]:
            del _live[k]
        for k in [k for k, v in _tlive.items() if now - v[1] > 30]:
            del _tlive[k]
    except Exception:
        pass
    return 2.0


def _hit_at(ptr, mx, my):
    for h in reversed(_hits.get(ptr, ())):
        x, y, w, hh = h[2]
        if x <= mx <= x + w and y <= my <= y + hh:
            return h
    return None


def _slide(name, mx, x, w):
    v = max(0.0, min(1.0, (mx - x) / w))
    if name == "sl:cam":
        p = _prefs()
        if p is not None:
            p.cam_opacity = v
    elif name in ("sl:cur_op", "sl:cur_size"):
        p = _prefs()
        if p is not None:
            setattr(p, "cursor_opacity" if name == "sl:cur_op" else "cursor_size", v)
    elif name.startswith("sl:u:"):
        _set_user_op(name[5:], v)


def _commit():
    if _ui["edit"] == "field:name":
        sync.set_my_name(_ui["text"])
    _ui["edit"] = None


def _click(name):
    p = _prefs()
    if name == "launcher":
        _ui["exp"] = None if _ui["exp"] == _ui["hover"][0] else _ui["hover"][0]
        if _ui["exp"] is None:
            _ui["open"] = False
    elif name == "launch:welcome":
        _ui.update(open=False, edit=None)
        show_splash()
    elif name.startswith("launch:"):
        _ui.update(open=True, tab="account" if name.endswith("account") else "general", area=_ui["hover"][0], scroll=0, edit=None)
    elif name == "close":
        _ui.update(open=False, edit=None)
    elif name.startswith("tab:"):
        _ui.update(tab=name[4:], scroll=0)
    elif name == "field:name":
        _ui.update(edit="field:name", text=p.username.strip() if p else "")
    elif name == "pfp:pick":
        try:
            bpy.ops.silverwood.pick_pfp('INVOKE_DEFAULT')
        except Exception:
            pass
    elif name == "pfp:clear":
        sync.set_my_pfp("")
    elif name == "cur:pick":
        try:
            bpy.ops.silverwood.pick_cursor('INVOKE_DEFAULT')
        except Exception:
            pass
    elif name == "cur:clear":
        sync.set_my_cursor("")
    elif name.startswith("tog:") and p is not None:
        key = {"tog:hide_pfps": "hide_pfps", "tog:hide_names": "hide_names", "tog:splash": "show_splash",
               "tog:cursors": "show_cursors", "tog:switch_msg": "show_switch_msgs",
               "tog:cur_pfp": "cursor_pfps", "tog:cur_name": "cursor_names", "tog:cur_mine": "use_custom_cursor",
               "tog:cur_theirs": "show_custom_cursors"}[name]
        setattr(p, key, not getattr(p, key))
        if key == "use_custom_cursor":
            sync.push_blob()
    elif name == "reset:ops":
        _reset_user_ops()
    elif name == "host:lock":
        sync.host_do("lock", arg=not sync.ctl().state()[0]) if sync.ctl() else None
    elif name == "host:default":
        sync.host_do("default", arg="edit" if sync.ctl().state()[1] == "view" else "view") if sync.ctl() else None
    elif name == "host:unban":
        sync.host_do("unban")
    elif name.startswith("role:"):
        uid = name[5:]
        sync.host_do("role", uid, "edit" if sync.role_of(uid) == "view" else "view")
    elif name.startswith("kick:"):
        sync.host_do("kick", name[5:])


class SW_OT_launcher(bpy.types.Operator):
    """Always-on modal behind the launcher icon and menu. Everything it does not use is passed through to Blender."""
    bl_idname, bl_label, bl_options = "silverwood.launcher", "SilverWood Menu", {'INTERNAL'}

    def invoke(self, ctx, ev):
        if ctx.area is None or ctx.area.type != 'VIEW_3D':
            return {'CANCELLED'}
        self.ptr, self.tok, self.eat = ctx.area.as_pointer(), os.urandom(4).hex(), False
        _live[self.ptr] = (self.tok, time.time())
        self.timer = ctx.window_manager.event_timer_add(0.5, window=ctx.window)
        ctx.window_manager.modal_handler_add(self)
        return {'RUNNING_MODAL'}

    def _end(self, ctx):
        try:
            ctx.window_manager.event_timer_remove(self.timer)
        except Exception:
            pass
        if _live.get(self.ptr, (None,))[0] == self.tok:
            del _live[self.ptr]
        return {'CANCELLED'}

    def cancel(self, ctx):
        self._end(ctx)

    def modal(self, ctx, ev):
        if not _run["on"] or _live.get(self.ptr, (None,))[0] != self.tok:
            return self._end(ctx)
        _live[self.ptr] = (self.tok, time.time())
        t, g = ev.type, _geo.get(self.ptr)
        mine = _ui["area"] == self.ptr and _ui["open"]
        if t.startswith('TIMER'):
            if mine and _ui["edit"]:
                sync.redraw()
            return {'PASS_THROUGH'}
        if _sp or g is None:
            return {'PASS_THROUGH'}
        if mine and _ui["edit"] and t not in _MOUSE and not t.startswith(('WINDOW', 'NDOF', 'ACTIONZONE', 'EVT_')):
            if ev.value == 'PRESS':
                if t == 'ESC':
                    _ui["edit"] = None
                elif t in {'RET', 'NUMPAD_ENTER'}:
                    _commit()
                elif t == 'BACK_SPACE':
                    _ui["text"] = _ui["text"][:-1]
                elif t == 'V' and (ev.ctrl or ev.oskey):
                    _ui["text"] = (_ui["text"] + ctx.window_manager.clipboard.replace("\n", " ").strip())[:32]
                elif ev.unicode and ev.unicode.isprintable():
                    _ui["text"] = (_ui["text"] + ev.unicode)[:32]
            sync.redraw()
            return {'RUNNING_MODAL'}
        mx, my = ev.mouse_x - g[0], ev.mouse_y - g[1]
        over = _hit_at(self.ptr, mx, my)
        if t in {'MOUSEMOVE', 'INBETWEEN_MOUSEMOVE'}:
            d = _ui["drag"]
            if d and d[0] == self.ptr:
                _slide(d[1], mx, d[2], d[3])
                sync.redraw()
                return {'RUNNING_MODAL'}
            hv = (self.ptr, over[0]) if over and over[1] != "bg" else None
            if hv != _ui["hover"]:
                _ui["hover"] = hv
                sync.redraw()
            return {'PASS_THROUGH'}
        if t == 'LEFTMOUSE':
            if ev.value in {'PRESS', 'DOUBLE_CLICK'}:
                if over is None:
                    if mine and _ui["edit"]:
                        _commit()
                        sync.redraw()
                    return {'PASS_THROUGH'}
                self.eat = True
                _ui["hover"] = (self.ptr, over[0]) if over[1] != "bg" else None
                if over[1] == "slider":
                    _ui["drag"] = (self.ptr, over[0], *over[3])
                    _slide(over[0], mx, *over[3])
                else:
                    if _ui["edit"] and over[0] != "field:name":
                        _commit()
                    if over[1] != "bg":
                        _click(over[0])
                sync.redraw()
                return {'RUNNING_MODAL'}
            if ev.value == 'RELEASE':
                _ui["drag"] = None
                if self.eat:
                    self.eat = False
                    return {'RUNNING_MODAL'}
            return {'PASS_THROUGH'}
        if t in _WHEEL and over is not None and mine and _ui["tab"] == "users":
            _ui["scroll"] += 1 if t == 'WHEELDOWNMOUSE' else -1
            sync.redraw()
            return {'RUNNING_MODAL'}
        return {'PASS_THROUGH'}


_MOUSE = {'MOUSEMOVE', 'INBETWEEN_MOUSEMOVE', 'LEFTMOUSE', 'RIGHTMOUSE', 'MIDDLEMOUSE',
          'WHEELUPMOUSE', 'WHEELDOWNMOUSE', 'WHEELINMOUSE', 'WHEELOUTMOUSE'}
_WHEEL = {'WHEELUPMOUSE', 'WHEELDOWNMOUSE'}


class SW_OT_track(bpy.types.Operator):
    bl_idname, bl_label, bl_options = "silverwood.track", "SilverWood Cursor", {'INTERNAL'}

    def invoke(self, ctx, ev):
        self.wp, self.tok = ctx.window.as_pointer(), os.urandom(4).hex()
        _tlive[self.wp] = (self.tok, time.time())
        self.timer = ctx.window_manager.event_timer_add(0.5, window=ctx.window)
        ctx.window_manager.modal_handler_add(self)
        return {'RUNNING_MODAL'}

    def _end(self, ctx):
        try:
            ctx.window_manager.event_timer_remove(self.timer)
        except Exception:
            pass
        if _tlive.get(self.wp, (None,))[0] == self.tok:
            del _tlive[self.wp]
        return {'CANCELLED'}

    def cancel(self, ctx):
        self._end(ctx)

    def modal(self, ctx, ev):
        if not _run["on"] or _tlive.get(self.wp, (None,))[0] != self.tok:
            return self._end(ctx)
        _tlive[self.wp] = (self.tok, time.time())
        t, win = ev.type, ctx.window
        if t not in {'MOUSEMOVE', 'INBETWEEN_MOUSEMOVE'} and not t.startswith('TIMER'):
            inputs.feed(ev)
        if S.worker is None or win is None or t.startswith('TIMER'):
            return {'PASS_THROUGH'}
        if t == 'LEFTMOUSE':
            S.mouse_dn = ev.value == 'PRESS'
        elif t not in {'MOUSEMOVE', 'INBETWEEN_MOUSEMOVE'}:
            return {'PASS_THROUGH'}
        wins = ctx.window_manager.windows
        if wins and win.as_pointer() == wins[0].as_pointer():
            mx, my = ev.mouse_x, ev.mouse_y
            for i, a in enumerate(win.screen.areas):
                if a.x <= mx < a.x + a.width and a.y <= my < a.y + a.height:
                    S.mouse = (win.workspace.name, i, a.type, round((mx - a.x) / a.width, 4),
                               round((my - a.y) / a.height, 4), S.mouse_dn, time.time())
                    break
        return {'PASS_THROUGH'}


class SW_OT_open_menu(bpy.types.Operator):
    bl_idname, bl_label = "silverwood.open_menu", "Settings Menu"
    bl_description = "Open the SilverWood settings menu in the 3D viewport (also: the cube icon at the bottom left of the viewport)"
    tab: StringProperty(default="general")

    def execute(self, ctx):
        open_menu(self.tab, ctx.area.as_pointer() if ctx.area and ctx.area.type == 'VIEW_3D' else None)
        return {'FINISHED'}


class SW_OT_pick_pfp(bpy.types.Operator):
    bl_idname, bl_label = "silverwood.pick_pfp", "Choose Profile Picture"
    bl_description = "Pick an image. Others see it next to your name only when the host runs the session on their PC"
    filepath: StringProperty(subtype='FILE_PATH')
    filter_glob: StringProperty(default="*.png;*.jpg;*.jpeg;*.bmp;*.tga;*.webp", options={'HIDDEN'})

    def invoke(self, ctx, ev):
        ctx.window_manager.fileselect_add(self)
        return {'RUNNING_MODAL'}

    def execute(self, ctx):
        try:
            sync.set_my_pfp(self.filepath)
        except Exception as e:
            self.report({'ERROR'}, f"Could not load that picture: {e}")
            return {'CANCELLED'}
        return {'FINISHED'}


class SW_OT_pick_cursor(bpy.types.Operator):
    bl_idname, bl_label = "silverwood.pick_cursor", "Choose Custom Cursor"
    bl_description = "Pick a transparent image to use as your cursor. Others see it only when the host runs the session on their PC"
    filepath: StringProperty(subtype='FILE_PATH')
    filter_glob: StringProperty(default="*.png;*.gif;*.webp;*.tga;*.bmp;*.tif;*.tiff", options={'HIDDEN'})

    def invoke(self, ctx, ev):
        ctx.window_manager.fileselect_add(self)
        return {'RUNNING_MODAL'}

    def execute(self, ctx):
        try:
            sync.set_my_cursor(self.filepath)
        except Exception as e:
            self.report({'ERROR'}, f"Could not load that image: {e}")
            return {'CANCELLED'}
        return {'FINISHED'}


class SW_PT_main(bpy.types.Panel):
    bl_idname, bl_label = "SW_PT_main", "SilverWood"
    bl_space_type, bl_region_type, bl_category = 'VIEW_3D', 'UI', "SilverWood"
    bl_options = {'HIDE_HEADER'}

    def draw(self, ctx):
        l, st = self.layout, sync.status()
        box = l.box()
        r = box.row()
        r.scale_y = 1.6
        r.label(text="SilverWood", icon='OUTLINER_COLLECTION')
        r = box.row()
        r.scale_y = 0.6
        r.enabled = False
        r.label(text="Blender Co Op Addon")
        u = update.STATE
        if u.state in ("available", "downloading", "downloaded", "installed"):
            ub = l.box()
            ub.alert = u.state == "available"
            ub.label(text=update.status_label().replace("SilverWood: ", ""), icon='IMPORT')
            if u.state in ("available", "downloaded"):
                ub.operator("silverwood.update_action", icon='IMPORT',
                            text="Download Update" if u.state == "available" else "Install Update")
        label, icon = STATUS[st]
        r = l.row()
        r.alert = st == "error"
        r.label(text=label, icon=icon)
        col = l.column(align=True)
        col.label(text=f"Project: {S.project or 'None'}", icon='FILE_BLEND')
        col.operator("silverwood.splash", text="About / Setup", icon='INFO')
        col.operator("silverwood.open_menu", text="Settings Menu", icon='PREFERENCES')
        col.operator("silverwood.update_check", text=f"v{VERSION} - Check for Updates", icon='FILE_REFRESH')
        col.label(text="Private code:", icon='USER')
        col.label(text=S.code or ("Starting tunnel..." if S.tunnel else sync.online_code() or "..."))
        col.label(text=("Hosting" if S.worker.mode == "create" else "Joined") if S.worker
                  else "Share it, then host", icon='INFO')


class SW_PT_session(bpy.types.Panel):
    bl_idname, bl_label, bl_parent_id = "SW_PT_session", "Session", "SW_PT_main"
    bl_space_type, bl_region_type, bl_category = 'VIEW_3D', 'UI', "SilverWood"

    def draw(self, ctx):
        l, wm, active = self.layout, ctx.window_manager, S.worker is not None
        c = l.column(align=True)
        c.enabled = not active
        c.operator("silverwood.create_world", icon='WORLD')
        c.operator("silverwood.create", icon='URL')
        c.operator("silverwood.create_local", icon='PLUS')
        r = c.row(align=True)
        r.prop(wm, "sw_join_id", text="")
        r.operator("silverwood.join", icon='IMPORT')
        txt, ok = tunnel.tool_status()
        b = l.box()
        b.label(text=tunnel.SETUP.msg if tunnel.SETUP.state != "idle" else txt, icon='CHECKMARK' if ok else 'ERROR')
        if not ok or tunnel.SETUP.state == "running":
            b.operator("silverwood.setup_tunnel", icon='IMPORT')
        c = l.column(align=True)
        c.enabled = active
        c.operator("silverwood.leave", icon='CANCEL')
        r = c.row(align=True)
        r.operator("silverwood.refresh", icon='FILE_REFRESH')
        r.operator("silverwood.copy_id", icon='COPYDOWN')
        r = c.row(align=True)
        r.enabled = not active
        r.operator("silverwood.copy_lan", icon='COPYDOWN')
        r = l.row()
        r.enabled = not active
        r.operator("silverwood.new_code", icon='FILE_REFRESH')


class SW_PT_members(bpy.types.Panel):
    bl_idname, bl_label, bl_parent_id = "SW_PT_members", "Online Members", "SW_PT_main"
    bl_space_type, bl_region_type, bl_category = 'VIEW_3D', 'UI', "SilverWood"

    def draw(self, ctx):
        l = self.layout
        if not ctx.window_manager.sw_members:
            l.label(text="No session")
        for m in ctx.window_manager.sw_members:
            c = l.column(align=True)
            r = c.row(align=True)
            sw = r.row()
            sw.ui_units_x = 1.5
            if m.me:
                sw.prop(ctx.window_manager, "sw_my_color", text="")
            else:
                sw.prop(m, "color", text="")
            tag = (" (host)" if m.host else "") + (" (you)" if m.me else "")
            r.label(text=m.name + tag, icon='RADIOBUT_ON' if m.online else 'RADIOBUT_OFF')
            r = c.row()
            r.scale_y = 0.7
            r.enabled = False
            r.label(text=m.activity if m.online else "Offline")


class SW_PT_sync(bpy.types.Panel):
    bl_idname, bl_label, bl_parent_id = "SW_PT_sync", "Synchronization", "SW_PT_main"
    bl_space_type, bl_region_type, bl_category = 'VIEW_3D', 'UI', "SilverWood"

    def draw(self, ctx):
        l, w = self.layout, S.worker
        c = l.column(align=True)
        c.label(text=f"Latency: {w.latency} ms" if w else "Latency: -", icon='TIME')
        ago = f"{time.time() - S.last_sync:.0f} s ago" if S.last_sync else "never"
        c.label(text=f"Last sync: {ago}", icon='FILE_REFRESH')
        pend = (len(w.pending) + w.outbox.qsize() + len(S.deferred)) if w else 0
        c.label(text=f"Pending updates: {pend}", icon='SORTTIME')
        if ERRORS:
            b = l.box()
            b.alert = True
            for e in ERRORS:
                b.label(text=e[:70], icon='ERROR')


_EDGES = ((0, 1), (1, 2), (2, 3), (3, 0), (4, 5), (5, 6), (6, 7), (7, 4), (0, 4), (1, 5), (2, 6), (3, 7))
_handles = []


def _bbox(o):
    pts = [o.matrix_world @ Vector(c) for c in o.bound_box]
    return [pts[i] for e in _EDGES for i in e]


def cam_lines(loc, quat, s):
    """Blender-style camera (pyramid + up-triangle + look arrow + empty axes) in the user's view pose.
    Camera space: looks down -Z, up is +Y. s = size."""
    z, hw, hh = -1.5 * s, 0.8 * s, 0.45 * s
    c = [(-hw, -hh, z), (hw, -hh, z), (hw, hh, z), (-hw, hh, z)]
    o = (0, 0, 0)
    seg = [(o, p) for p in c] + [(c[i], c[(i + 1) % 4]) for i in range(4)]
    seg += [((-0.4 * s, hh + 0.05 * s, z), (0.4 * s, hh + 0.05 * s, z)),
            ((-0.4 * s, hh + 0.05 * s, z), (0, hh + 0.4 * s, z)), ((0.4 * s, hh + 0.05 * s, z), (0, hh + 0.4 * s, z))]
    tip, h = (0, 0, -3.2 * s), 0.25 * s
    seg += [(o, tip), (tip, (h, 0, -2.6 * s)), (tip, (-h, 0, -2.6 * s)), (tip, (0, h, -2.6 * s)), (tip, (0, -h, -2.6 * s))]
    a = 0.25 * s
    seg += [((-a, 0, 0), (a, 0, 0)), ((0, -a, 0), (0, a, 0)), ((0, 0, -a), (0, 0, a))]
    return [loc + quat @ Vector(p) for ab in seg for p in ab]


def draw_3d():
    if not S.remote:
        return
    shader = gpu.shader.from_builtin('UNIFORM_COLOR')
    gpu.state.blend_set('ALPHA')
    gpu.state.depth_test_set('NONE')
    gpu.state.line_width_set(2.0)
    for r in S.remote.values():
        if not r.online:
            continue
        pts, cam, a = [], [], cam_alpha(r.name)
        for i in r.sel:
            o = sync.find(i)
            if o is not None:
                pts += _bbox(o)
        if r.cam_s and a > 0.01:
            rv = bpy.context.region_data
            cam = cam_lines(r.cam_s[0], r.cam_s[1], max(0.1, 0.05 * rv.view_distance) if rv else 0.3)
        if r.cur:
            x, y, z = r.cur
            d = 0.3
            pts += [(x - d, y, z), (x + d, y, z), (x, y - d, z), (x, y + d, z), (x, y, z - d), (x, y, z + d)]
        for lines, alpha in ((pts, 1.0), (cam, a)):
            if lines:
                shader.bind()
                shader.uniform_float("color", (*r.color, alpha))
                batch_for_shader(shader, 'LINES', {"pos": lines}).draw(shader)
    gpu.state.line_width_set(1.0)
    gpu.state.blend_set('NONE')


def draw_labels():
    c = bpy.context
    if not S.remote or c.region_data is None:
        return
    p = _prefs()
    show_name, show_pic = not (p and p.hide_names), S.local and not (p and p.hide_pfps)
    gpu.state.blend_set('ALPHA')
    for r in S.remote.values():
        if not r.online:
            continue
        anchors = [Vector(r.cur)] if r.cur else []
        if r.cam_s:
            anchors.append(r.cam_s[0])
        for i in r.sel[:3]:
            o = sync.find(i)
            if o is not None:
                anchors.append(o.matrix_world.translation)
        pic = S.pfps.get(r.uid) if show_pic else None
        for a in anchors:
            pt = location_3d_to_region_2d(c.region, c.region_data, a)
            if pt:
                ox = pt.x + 8
                if pic:
                    _avatar_draw(ox, pt.y + 4, 18, pic, r.uid, r.color, r.name)
                    ox += 24
                if show_name:
                    blf.size(0, 13)
                    blf.color(0, *r.color, 1.0)
                    blf.position(0, ox, pt.y + 8, 0)
                    blf.draw(0, r.name)
    gpu.state.blend_set('NONE')


_RTYPES = ('WINDOW', 'HEADER', 'TOOL_HEADER', 'FOOTER', 'UI', 'TOOLS', 'TOOL_PROPS', 'CHANNELS', 'NAVIGATION_BAR')
_ORDER = {t: i for i, t in enumerate(('HEADER', 'TOOL_HEADER', 'FOOTER', 'UI', 'TOOLS', 'TOOL_PROPS', 'CHANNELS', 'NAVIGATION_BAR', 'WINDOW'))}
_SPACES = ("SpaceView3D", "SpaceProperties", "SpaceOutliner", "SpaceTextEditor", "SpaceNodeEditor", "SpaceImageEditor",
           "SpaceSequenceEditor", "SpaceDopeSheetEditor", "SpaceGraphEditor", "SpaceNLA", "SpaceFileBrowser",
           "SpaceClipEditor", "SpaceConsole", "SpaceInfo", "SpacePreferences", "SpaceSpreadsheet", "SpaceTopBar",
           "SpaceStatusBar")
_ch = []


def _spot(screen, ai, at, fx, fy):
    areas = screen.areas
    a = areas[ai] if 0 <= ai < len(areas) and areas[ai].type == at else next((x for x in areas if x.type == at), None)
    if a is None:
        return None
    x, y = a.x + fx * a.width, a.y + fy * a.height
    regs = [r for r in a.regions if r.width > 1 and r.height > 1 and r.x <= x <= r.x + r.width and r.y <= y <= r.y + r.height]
    return (a, min(regs, key=lambda r: _ORDER.get(r.type, 99)), x, y) if regs else None


def _cursor(x, y, col, al, label, pic, uid, name, dn, s, rw, rh, cur=None):
    sh = gpu.shader.from_builtin('UNIFORM_COLOR')
    body = ((x, y), (x, y - 17 * s), (x + 4.5 * s, y - 13 * s), (x + 12 * s, y - 12 * s))
    if not (cur and _cursor_img(cur, uid, x, y - 28 * s, 28 * s)):
        sh.bind()
        sh.uniform_float("color", (*col, al))
        batch_for_shader(sh, 'TRI_FAN', {"pos": body}).draw(sh)
        sh.uniform_float("color", (0, 0, 0, al))
        batch_for_shader(sh, 'LINE_LOOP', {"pos": body}).draw(sh)
    sh = gpu.shader.from_builtin('UNIFORM_COLOR')
    sh.bind()
    if dn:
        ring = [(x + 9 * s * math.cos(k * math.pi / 10), y + 9 * s * math.sin(k * math.pi / 10)) for k in range(20)]
        sh.uniform_float("color", (*col, al))
        gpu.state.line_width_set(2.0)
        batch_for_shader(sh, 'LINE_LOOP', {"pos": ring}).draw(sh)
        gpu.state.line_width_set(1.0)
    if label:
        fs, ex = max(9, round(12 * s)), 20 if pic else 0
        blf.size(0, fs)
        while blf.dimensions(0, label)[0] + 10 + ex > rw - 4 and len(label) > 3:
            label = label[:-4] + ".."
        tw = blf.dimensions(0, label)[0] + 10 + ex
        bh = fs + 6
        px = x + 14 * s
        if px + tw > rw - 2:
            px = x - 6 - tw
        px = max(2, min(px, rw - tw - 2))
        py = max(2, min(y - 33 * s, rh - bh - 2))
        _rect(px, py, tw, bh, (*[c * 0.45 for c in col], 0.85 * al))
        if pic:
            _avatar_draw(px + 1, py + 1, bh - 2, pic, uid, col, name)
        _text(label, px + 5 + ex, py + 4, fs, (1, 1, 1, al))


def draw_cursors():
    c = bpy.context
    a, rg, scr = c.area, c.region, c.screen
    if a is None or rg is None or scr is None or not (S.remote or S.ghosts):
        return
    ws, p, now = sync.my_ws(), _prefs(), time.time()
    if p and not p.show_cursors:
        return
    show_name, show_pic = not (p and not p.cursor_names), S.local and not (p and not p.cursor_pfps)
    show_cur = S.local and not (p and not p.show_custom_cursors)
    op, sc = (p.cursor_opacity, 0.5 + p.cursor_size) if p else (1.0, 1.0)
    items = [(r.pos_s, r.color, op, r.name if show_name else "", S.pfps.get(r.uid) if show_pic else None, r.uid, r.name, r.pos.dn,
              S.curs.get(r.uid) if show_cur else None)
             for r in S.remote.values() if r.online and r.pos and r.pos_s and r.ws == ws]
    if not p or p.show_switch_msgs:
        items += [(g["pos"], g["color"], op * (1.0 - (now - g["t0"]) / 2.5), g["text"], None, "", g["name"], False, None)
                  for g in S.ghosts if g["ws"] == ws and now - g["t0"] < 2.5]
    gpu.state.blend_set('ALPHA')
    for pos, col, al, label, pic, uid, name, dn, cur in items:
        hit = _spot(scr, pos[0], pos[1], pos[2], pos[3])
        if hit and hit[0].as_pointer() == a.as_pointer() and hit[1].as_pointer() == rg.as_pointer():
            _cursor(hit[2] - rg.x, hit[3] - rg.y, col, al, label, pic, uid, name, dn, sc, rg.width, rg.height, cur)
    gpu.state.blend_set('NONE')


class SW_PT_input(bpy.types.Panel):
    bl_idname, bl_label, bl_parent_id = "SW_PT_input", "Keys & Clicks", "SW_PT_main"
    bl_space_type, bl_region_type, bl_category = 'VIEW_3D', 'UI', "SilverWood"
    bl_options = {'DEFAULT_CLOSED'}

    def draw(self, ctx):
        draw_input_settings(self.layout, _prefs())


def draw_input_settings(l, p):
    c = l.column()
    c.prop(p, "input_show")
    c.prop(p, "input_share")
    b = c.column()
    b.active = p.input_show
    b.prop(p, "input_own")
    b.prop(p, "input_others")
    b.prop(p, "input_corner")
    r = b.row(align=True)
    r.prop(p, "input_x")
    r.prop(p, "input_y")
    b.prop(p, "input_scale")
    b.prop(p, "input_opacity")
    b.prop(p, "input_key_time")


classes = (SW_Member, SW_OT_track, SW_OT_launcher, SW_OT_open_menu, SW_OT_pick_pfp, SW_OT_pick_cursor, SW_OT_setup_tunnel, SW_OT_splash, SW_OT_update_check, SW_OT_update_action, SW_OT_create_world, SW_OT_create, SW_OT_create_local, SW_OT_copy_lan, SW_OT_join, SW_OT_leave, SW_OT_refresh, SW_OT_new_code, SW_OT_copy_id,
           SW_PT_main, SW_PT_session, SW_PT_members, SW_PT_sync, SW_PT_input)


def register():
    update.register()
    for c in classes:
        bpy.utils.register_class(c)
    bpy.types.WindowManager.sw_members = CollectionProperty(type=SW_Member)
    bpy.types.WindowManager.sw_my_color = FloatVectorProperty(
        name="My Color", description="Your color. Everyone in the session sees it", subtype='COLOR_GAMMA',
        size=3, min=0.0, max=1.0, default=(1.0, 0.53, 0.0), update=lambda self, ctx: sync.set_my_color(self.sw_my_color))
    bpy.types.WindowManager.sw_join_id = StringProperty(name="Code", description="Host's private code")
    sv = bpy.types.SpaceView3D
    _handles.append(sv.draw_handler_add(draw_3d, (), 'WINDOW', 'POST_VIEW'))
    _handles.append(sv.draw_handler_add(draw_labels, (), 'WINDOW', 'POST_PIXEL'))
    _handles.append(sv.draw_handler_add(draw_launcher, (), 'WINDOW', 'POST_PIXEL'))
    _handles.append(sv.draw_handler_add(draw_update_toast, (), 'WINDOW', 'POST_PIXEL'))
    _handles.append(sv.draw_handler_add(draw_inputs, (), 'WINDOW', 'POST_PIXEL'))
    inputs.register()
    for nm in _SPACES:
        cls = getattr(bpy.types, nm, None)
        for rt in _RTYPES if cls else ():
            try:
                _ch.append((cls, cls.draw_handler_add(draw_cursors, (), rt, 'POST_PIXEL'), rt))
            except Exception:
                pass
    _run["on"] = True
    bpy.app.timers.register(_ensure, first_interval=1.0, persistent=True)


def unregister():
    update.unregister()
    inputs.unregister()
    _run["on"] = False
    if bpy.app.timers.is_registered(_ensure):
        bpy.app.timers.unregister(_ensure)
    _live.clear()
    _tlive.clear()
    _hits.clear()
    for cls, h, rt in _ch:
        try:
            cls.draw_handler_remove(h, rt)
        except Exception:
            pass
    _ch.clear()
    _ui.update(open=False, exp=None, area=None, edit=None, drag=None, hover=None)
    for im in _av_imgs:
        try:
            bpy.data.images.remove(im)
        except Exception:
            pass
    _av_imgs.clear()
    _av.clear()
    if _sp:
        _sp.clear()
    for h in _handles:
        bpy.types.SpaceView3D.draw_handler_remove(h, 'WINDOW')
    _handles.clear()
    del bpy.types.WindowManager.sw_my_color
    del bpy.types.WindowManager.sw_join_id
    del bpy.types.WindowManager.sw_members
    for c in reversed(classes):
        bpy.utils.unregister_class(c)
