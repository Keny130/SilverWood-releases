"""SilverWood - Blender Co Op Addon. Real-time multi-user scene collaboration; the host's PC is the data server."""
import logging

import bpy

from . import sync, ui, update

DEFAULT_URL = "https://silverwood-blnd-1f81f-default-rtdb.europe-west1.firebasedatabase.app"

_log = logging.getLogger("SilverWood")
_h = logging.StreamHandler()


class SW_Preferences(bpy.types.AddonPreferences):
    bl_idname = __package__
    username: bpy.props.StringProperty(name="Username", description="Shown to other members (blank = OS login name)")
    database_url: bpy.props.StringProperty(name="Database URL", default=DEFAULT_URL,
                                           description="Firebase Realtime Database used by Host Online")
    auth_token: bpy.props.StringProperty(name="Auth Token", subtype='PASSWORD',
                                         description="Optional Firebase ID token / secret (sent as ?auth=)")
    color_hex: bpy.props.StringProperty(default="", options={'HIDDEN'})
    show_splash: bpy.props.BoolProperty(name="Show welcome screen on new files", default=True)
    input_show: bpy.props.BoolProperty(name="Show Keys & Clicks Display", default=False,
                                       description="Draw a small mouse and the keys you press on screen (and other people's, if they share)")
    input_share: bpy.props.BoolProperty(name="Share My Keys & Clicks", default=False,
                                        description="Everyone in the session sees your key presses and mouse clicks, e.g. for classes. Everything you press in Blender is shown, so switch it off when not presenting")
    input_own: bpy.props.BoolProperty(name="Show My Own", default=True)
    input_others: bpy.props.BoolProperty(name="Show Other People's", default=True)
    input_corner: bpy.props.EnumProperty(name="Corner", default='BR', items=(
        ('BR', "Bottom Right", ""), ('BL', "Bottom Left", ""), ('TR', "Top Right", ""), ('TL', "Top Left", "")))
    input_x: bpy.props.IntProperty(name="X", default=30, min=0, max=4000, subtype='PIXEL', description="Distance from the side")
    input_y: bpy.props.IntProperty(name="Y", default=60, min=0, max=4000, subtype='PIXEL', description="Distance from the top/bottom")
    input_scale: bpy.props.FloatProperty(name="Size", default=1.0, min=0.4, max=3.0)
    input_opacity: bpy.props.FloatProperty(name="Opacity", default=0.9, min=0.1, max=1.0, subtype='FACTOR')
    input_key_time: bpy.props.FloatProperty(name="Key Text Time", default=1.5, min=0.5, max=5.0, unit='TIME',
                                            description="Seconds the key text stays on screen")
    check_updates: bpy.props.BoolProperty(name="Check for Updates on Startup", default=True)
    update_url: bpy.props.StringProperty(name="Update URL", default="",
                                         description="JSON with the latest version (Firebase node or extension index.json). Blank = <Database URL>/updates/silverwood.json")
    welcomed: bpy.props.BoolProperty(default=False, options={'HIDDEN'})
    pfp_path: bpy.props.StringProperty(name="Profile Picture", subtype='FILE_PATH',
                                       description="Image shown next to your name for others. Only visible when the host runs the session on their PC")
    cam_opacity: bpy.props.FloatProperty(name="Camera Opacity", default=1.0, min=0.0, max=1.0, subtype='FACTOR',
                                         description="Opacity of other users' viewport cameras (override per user in the SilverWood menu)")
    show_cursors: bpy.props.BoolProperty(name="Show Other Users' Cursors", default=True)
    show_switch_msgs: bpy.props.BoolProperty(name="Show Workspace Switch Messages", default=True)
    cursor_opacity: bpy.props.FloatProperty(name="Cursor Opacity", default=1.0, min=0.0, max=1.0, subtype='FACTOR')
    cursor_size: bpy.props.FloatProperty(name="Cursor Size", default=0.5, min=0.0, max=1.0, subtype='FACTOR',
                                         description="0.5 = normal size")
    cursor_pfps: bpy.props.BoolProperty(name="Profile Pictures On Cursors", default=True)
    cursor_names: bpy.props.BoolProperty(name="Usernames On Cursors", default=True)
    use_custom_cursor: bpy.props.BoolProperty(name="Use My Custom Cursor", default=True,
                                              description="Others see your custom cursor image instead of the arrow")
    show_custom_cursors: bpy.props.BoolProperty(name="Show Others' Custom Cursors", default=True)
    cursor_path: bpy.props.StringProperty(name="Custom Cursor", subtype='FILE_PATH',
                                          description="Transparent image used as your cursor. Only visible when the host runs the session on their PC")
    hide_pfps: bpy.props.BoolProperty(name="Hide Profile Pictures", default=False)
    hide_names: bpy.props.BoolProperty(name="Hide Usernames", default=False)
    user_opacity: bpy.props.StringProperty(default="{}", options={'HIDDEN'})
    client_id: bpy.props.StringProperty(default="", options={'HIDDEN'})
    port: bpy.props.IntProperty(name="Host Port", default=8765, min=1024, max=65535,
                                description="TCP port the host's server listens on")
    address: bpy.props.StringProperty(
        name="Advertised IPv4", description="Address friends use to reach you. Blank = LAN address. "
        "Over the internet: your public IP (with port forwarding) or a VPN address (Tailscale/ZeroTier)")

    def draw(self, ctx):
        c = self.layout.column()
        c.prop(self, "username")
        c.prop(self, "pfp_path")
        c.prop(self, "show_splash")
        c.prop(self, "check_updates")
        ui.draw_input_settings(c.box(), self)
        c.prop(self, "update_url")
        c.prop(self, "cam_opacity")
        c.prop(self, "show_cursors")
        c.prop(self, "show_switch_msgs")
        c.prop(self, "cursor_pfps")
        c.prop(self, "cursor_names")
        c.prop(self, "use_custom_cursor")
        c.prop(self, "show_custom_cursors")
        c.prop(self, "cursor_path")
        c.prop(self, "cursor_opacity")
        c.prop(self, "cursor_size")
        c.prop(self, "hide_pfps")
        c.prop(self, "hide_names")
        c.prop(self, "database_url")
        c.prop(self, "auth_token")
        c.prop(self, "port")
        c.prop(self, "address")


_armed = [False]


def _arm():
    _armed[0] = True


def _show_new():
    try:
        if bpy.context.preferences.addons[__package__].preferences.show_splash:
            ui.show_splash()
    except Exception:
        _log.exception("splash failed")
    return None


@bpy.app.handlers.persistent
def _on_new(*_):
    if _armed[0] and not bpy.data.filepath:
        bpy.app.timers.register(_show_new, first_interval=0.5)


def _startup_splash():
    try:
        sync.init_profile()
    except Exception:
        _log.exception("profile init failed")
    try:
        p = bpy.context.preferences.addons[__package__].preferences
        if not p.welcomed:
            p.welcomed = True
            ui.show_splash()
    except Exception:
        _log.exception("splash failed")
    try:
        if bpy.context.preferences.addons[__package__].preferences.check_updates:
            update.check()
    except Exception:
        _log.exception("update check failed")
    bpy.app.timers.register(_arm, first_interval=5.0)
    return None


def register():
    _h.setFormatter(logging.Formatter("[SilverWood] %(levelname)s %(name)s: %(message)s"))
    _log.addHandler(_h)
    _log.setLevel(logging.INFO)
    bpy.utils.register_class(SW_Preferences)
    ui.register()
    bpy.app.handlers.depsgraph_update_post.append(sync.on_depsgraph)
    bpy.app.handlers.load_pre.append(sync.on_load)
    bpy.app.handlers.load_post.append(_on_new)
    bpy.app.timers.register(sync.tick, first_interval=0.5, persistent=True)
    bpy.app.timers.register(sync.anim_tick, first_interval=0.5, persistent=True)
    bpy.app.timers.register(_startup_splash, first_interval=1.5)


def unregister():
    _armed[0] = False
    if _on_new in bpy.app.handlers.load_post:
        bpy.app.handlers.load_post.remove(_on_new)
    if bpy.app.timers.is_registered(_startup_splash):
        bpy.app.timers.unregister(_startup_splash)
    if bpy.app.timers.is_registered(sync.anim_tick):
        bpy.app.timers.unregister(sync.anim_tick)
    if bpy.app.timers.is_registered(sync.tick):
        bpy.app.timers.unregister(sync.tick)
    for lst, fn in ((bpy.app.handlers.depsgraph_update_post, sync.on_depsgraph),
                    (bpy.app.handlers.load_pre, sync.on_load)):
        if fn in lst:
            lst.remove(fn)
    sync.stop(join=True)
    ui.unregister()
    bpy.utils.unregister_class(SW_Preferences)
    _log.removeHandler(_h)
